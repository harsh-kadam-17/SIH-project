# Terra Tech Setup Guide

## Getting Started

Terra Tech is a comprehensive AI-powered agricultural advisory platform that provides expert guidance on agriculture, food technology, and rural development.

## Features

- **Multi-page Application**: Home, Agriculture, Food Technology, Rural Development, Resources, About, Contact
- **Authentication System**: Login page with user session management
- **Context-Aware AI Chatbots**: Specialized AI assistants for each domain
- **Image Analysis**: Upload and analyze agricultural images
- **Multi-modal Queries**: Combine text and images for comprehensive analysis
- **Professional UI**: Modern, responsive design with Tailwind CSS
- **Expert Resources**: Comprehensive knowledge base and learning materials

## OpenAI API Setup

To enable the AI functionality, you need to set up OpenAI API access:

### 1. Get OpenAI API Key
1. Visit [OpenAI Platform](https://platform.openai.com/)
2. Create an account or log in
3. Navigate to API Keys section
4. Create a new API key
5. Copy the API key (it starts with 'sk-')

### 2. Configure API Key
Replace `YOUR_OPENAI_API_KEY` in the following files with your actual API key:

```javascript
// In /components/ChatBot.tsx (line ~140)
'Authorization': `Bearer YOUR_ACTUAL_API_KEY_HERE`
```

### 3. Environment Variables (Recommended)
For production deployments, use environment variables:

```bash
# Create .env.local file in your project root
REACT_APP_OPENAI_API_KEY=your_actual_api_key_here
```

## AI Context Configuration

The application includes context-aware AI assistants:

### Agriculture AI Assistant
- **Context**: Agriculture, farming, crops, soil, pests, irrigation
- **Scope**: Only responds to agriculture-related queries
- **Features**: Image analysis for crop diseases, soil health, pest identification

### Food Technology AI Assistant  
- **Context**: Food processing, safety, quality control, preservation
- **Scope**: Only responds to food technology-related queries
- **Features**: Product analysis, safety protocols, processing optimization

### Rural Development AI Assistant
- **Context**: Community development, infrastructure, livelihoods
- **Scope**: Only responds to rural development-related queries  
- **Features**: Community needs assessment, project planning, capacity building

## Key Components

### 1. Authentication Flow
```
LoginPage → MainApp → Individual Pages
```

### 2. Page Structure
- **HomePage**: Overview and navigation to specialized services
- **AgriculturePage**: Crop management, soil health, pest control
- **FoodTechnologyPage**: Food processing, safety, quality control
- **RuralDevelopmentPage**: Community development, infrastructure
- **ResourcesPage**: Learning materials, webinars, certifications
- **AboutPage**: Company information, team, mission
- **ContactPage**: Multi-channel contact form and information

### 3. AI Integration
- Context-aware responses based on current page
- Multi-modal input (text + images)
- Specialized knowledge base for each domain
- Error handling and fallback responses

## Customization

### Adding New Services
1. Create new page component in `/components/pages/`
2. Add navigation entry in `Header.tsx`
3. Add route in `MainApp.tsx`
4. Create specialized ChatBot context if needed

### Modifying AI Behavior
1. Update context prompts in `ChatBot.tsx`
2. Modify the `getContextPrompt()` function
3. Adjust response filtering logic
4. Update demo responses for offline mode

### Styling Customization
- Uses Tailwind CSS with custom color scheme
- Green primary color for agriculture theme
- Blue accents for technology elements
- Purple highlights for community/development

## Demo Mode

When OpenAI API is not available, the application falls back to demo mode with:
- Simulated AI responses
- Context-appropriate sample answers
- Full UI functionality maintained
- User interaction preserved

## Best Practices

1. **API Key Security**: Never commit API keys to version control
2. **Error Handling**: Graceful fallbacks when API is unavailable
3. **Context Awareness**: AI responses tailored to specific domains
4. **User Experience**: Clear loading states and error messages
5. **Responsive Design**: Works across all device sizes

## Support

For technical support or questions about implementation:
- Check the component documentation in each file
- Review the context-specific AI prompts
- Test with demo mode first before adding API keys
- Ensure proper error handling for production use

## Security Notes

- API keys should be stored securely
- Consider rate limiting for production deployments
- Implement proper user authentication for sensitive data
- Validate and sanitize all user inputs
- Use HTTPS for all API communications