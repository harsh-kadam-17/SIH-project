import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Leaf, Tractor, Users, FlaskConical } from 'lucide-react';

interface User {
  email: string;
  name: string;
  id: number;
}

interface LoginPageProps {
  onLogin: (user: User) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate authentication delay
    setTimeout(() => {
      // For demo purposes, accept any email/password
      if (formData.email && formData.password) {
        onLogin({
          email: formData.email,
          name: formData.email.split('@')[0],
          id: Date.now()
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1708794666324-85ad91989d20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHxhZ3JpY3VsdHVyYWwlMjB0ZWNobm9sb2d5JTIwbG9naW4lMjBwcm9mZXNzaW9uYWwlMjBtb2Rlcm4lMjBmYXJtfGVufDF8fHx8MTc1NzUxNTE3Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Modern Agricultural Technology"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute inset-0 bg-gradient-to-br from-green-600/20 to-emerald-600/20"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* Left side - Branding */}
          <div className="text-center lg:text-left space-y-8">
            <div className="flex items-center justify-center lg:justify-start gap-3 mb-8">
              <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center shadow-lg">
                <Leaf className="w-7 h-7 text-white" />
              </div>
              <h1 className="text-4xl font-bold text-white drop-shadow-lg">Terra Tech</h1>
            </div>
            
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl font-bold text-white leading-tight drop-shadow-lg">
                AI-Powered Advisory for Sustainable Agriculture
              </h2>
              <p className="text-lg text-green-100 leading-relaxed drop-shadow-md">
                Empowering farmers with expert insights on agriculture, food technology, and rural development through advanced AI solutions.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-12">
              <div className="flex flex-col items-center text-center p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <div className="w-16 h-16 bg-green-500/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-3 border border-green-300/30">
                  <Tractor className="w-8 h-8 text-green-200" />
                </div>
                <h3 className="font-semibold text-white">Agriculture</h3>
                <p className="text-sm text-green-100 mt-1">Smart farming solutions</p>
              </div>
              
              <div className="flex flex-col items-center text-center p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <div className="w-16 h-16 bg-blue-500/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-3 border border-blue-300/30">
                  <FlaskConical className="w-8 h-8 text-blue-200" />
                </div>
                <h3 className="font-semibold text-white">Food Tech</h3>
                <p className="text-sm text-blue-100 mt-1">Innovation in food processing</p>
              </div>
              
              <div className="flex flex-col items-center text-center p-4 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <div className="w-16 h-16 bg-purple-500/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-3 border border-purple-300/30">
                  <Users className="w-8 h-8 text-purple-200" />
                </div>
                <h3 className="font-semibold text-white">Rural Development</h3>
                <p className="text-sm text-purple-100 mt-1">Community empowerment</p>
              </div>
            </div>
          </div>

          {/* Right side - Login Form */}
          <div className="flex justify-center lg:justify-end">
            <Card className="w-full max-w-md shadow-2xl border-0 bg-white/95 backdrop-blur-sm">
            <CardHeader className="space-y-2 text-center">
              <CardTitle className="text-2xl font-bold text-gray-800">Welcome Back</CardTitle>
              <CardDescription className="text-gray-600">
                Sign in to access your Terra Tech dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="h-11"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleInputChange}
                    required
                    className="h-11"
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full h-11 bg-green-600 hover:bg-green-700 text-white"
                  disabled={isLoading}
                >
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
              </form>

                <div className="text-center text-sm text-gray-500">
                  Demo credentials: Any email and password will work
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}