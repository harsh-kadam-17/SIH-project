import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Target, 
  Eye, 
  Heart, 
  Users, 
  Award,
  Globe,
  TrendingUp,
  Lightbulb,
  Shield,
  Leaf
} from 'lucide-react';

export function AboutPage() {
  const stats = [
    { label: 'Years of Experience', value: '15+', icon: Award },
    { label: 'Farmers Served', value: '50,000+', icon: Users },
    { label: 'Success Rate', value: '95%', icon: TrendingUp },
    { label: 'Countries Served', value: '25+', icon: Globe }
  ];

  const values = [
    {
      icon: Leaf,
      title: 'Sustainability',
      description: 'Committed to environmentally responsible agricultural practices that preserve our planet for future generations.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation',
      description: 'Leveraging cutting-edge AI technology to solve traditional agricultural challenges with modern solutions.'
    },
    {
      icon: Heart,
      title: 'Community',
      description: 'Building strong relationships with farming communities and supporting their growth and development.'
    },
    {
      icon: Shield,
      title: 'Reliability',
      description: 'Providing accurate, tested, and dependable advice backed by scientific research and expert knowledge.'
    }
  ];

  const team = [
    {
      name: 'Dr. Rajesh Kumar',
      role: 'Chief Agricultural Scientist',
      specialization: 'Crop Management & Soil Science',
      experience: '20+ years',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face'
    },
    {
      name: 'Dr. Priya Sharma',
      role: 'Food Technology Director',
      specialization: 'Food Safety & Processing',
      experience: '15+ years',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b47c?w=400&h=400&fit=crop&crop=face'
    },
    {
      name: 'Mr. Suresh Patel',
      role: 'Rural Development Head',
      specialization: 'Community Development',
      experience: '18+ years',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'
    },
    {
      name: 'Dr. Anita Singh',
      role: 'AI Technology Lead',
      specialization: 'Machine Learning & Data Science',
      experience: '12+ years',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face'
    }
  ];

  const milestones = [
    {
      year: '2009',
      title: 'Company Founded',
      description: 'Terra Tech was established with a vision to revolutionize agriculture through technology.'
    },
    {
      year: '2012',
      title: 'First AI Implementation',
      description: 'Launched our first AI-powered crop analysis system, serving 1,000+ farmers.'
    },
    {
      year: '2015',
      title: 'International Expansion',
      description: 'Expanded operations to serve farmers across 10 countries in Asia and Africa.'
    },
    {
      year: '2018',
      title: 'Food Technology Division',
      description: 'Added comprehensive food technology advisory services to our portfolio.'
    },
    {
      year: '2020',
      title: 'Rural Development Program',
      description: 'Launched dedicated rural development initiatives supporting community growth.'
    },
    {
      year: '2024',
      title: 'Next-Gen AI Platform',
      description: 'Introduced advanced multimodal AI system with 98% accuracy in agricultural diagnosis.'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-6 mb-16">
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
              About Terra Tech
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Transforming Agriculture Through Innovation
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
              For over 15 years, Terra Tech has been at the forefront of agricultural innovation, 
              combining expert knowledge with cutting-edge AI technology to empower farmers and 
              strengthen rural communities worldwide.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center border-0 bg-white shadow-lg">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">0</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="border-0 shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 leading-relaxed">
                  To democratize access to expert agricultural knowledge by leveraging artificial intelligence 
                  and making sustainable farming practices accessible to every farmer, regardless of their 
                  location or resources.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 leading-relaxed">
                  A world where technology and traditional wisdom converge to create sustainable, 
                  profitable, and resilient agricultural systems that feed the growing global population 
                  while protecting our environment.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 px-4 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These principles guide every decision we make and every solution we develop
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center border-0 bg-white shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-8 h-8 text-green-600" />
                  </div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}


      {/* Timeline */}
      <section className="py-16 px-4 bg-gradient-to-br from-green-50 to-emerald-50">

      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-green-600">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <h2 className="text-3xl font-bold text-white">
            Ready to Join Our Mission?
          </h2>
          <p className="text-lg text-green-100 max-w-2xl mx-auto">
            Whether you're a farmer looking for solutions, a researcher interested in collaboration, 
            or someone passionate about sustainable agriculture, we'd love to hear from you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Partner With Us
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-green-600 transition-colors">
              Contact Our Team
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}