import React from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { 
  Tractor, 
  FlaskConical, 
  Users, 
  Leaf, 
  TrendingUp, 
  Shield, 
  Lightbulb,
  ArrowRight,
  CheckCircle
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const services = [
    {
      id: 'agriculture',
      icon: Tractor,
      title: 'Agriculture Advisory',
      description: 'Expert guidance on crop management, soil health, pest control, and sustainable farming practices.',
      features: ['Crop Planning', 'Soil Analysis', 'Pest Management', 'Irrigation Optimization'],
      color: 'bg-green-500',
      hoverColor: 'hover:bg-green-600'
    },
    {
      id: 'food-technology',
      icon: FlaskConical,
      title: 'Food Technology',
      description: 'Innovation in food processing, preservation, quality control, and nutritional enhancement.',
      features: ['Food Processing', 'Quality Control', 'Preservation Techniques', 'Nutritional Analysis'],
      color: 'bg-blue-500',
      hoverColor: 'hover:bg-blue-600'
    },
    {
      id: 'rural-development',
      icon: Users,
      title: 'Rural Development',
      description: 'Community empowerment, infrastructure development, and sustainable livelihood solutions.',
      features: ['Community Programs', 'Infrastructure', 'Livelihood Support', 'Capacity Building'],
      color: 'bg-purple-500',
      hoverColor: 'hover:bg-purple-600'
    }
  ];

  const stats = [
    { label: 'Farmers Served', value: '50,000+', icon: Users },
    { label: 'Success Rate', value: '95%', icon: TrendingUp },
    { label: 'Crop Yield Increase', value: '40%', icon: Leaf },
    { label: 'AI Accuracy', value: '98%', icon: Shield }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4 bg-gradient-to-br from-green-50 via-emerald-50 to-blue-50 overflow-hidden">
        <div className="absolute inset-0 bg-white/60"></div>
        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                  AI-Powered Solutions
                </Badge>
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Empowering Agriculture with 
                  <span className="text-green-600"> Smart Technology</span>
                </h1>
                <p className="text-lg text-gray-600 leading-relaxed max-w-xl">
                  Transform your farming with our AI-powered advisory platform. Get expert insights on agriculture, 
                  food technology, and rural development to maximize your yield and sustainability.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 text-lg"
                  onClick={() => onNavigate('agriculture')}
                >
                  Get Started
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-green-600 text-green-600 hover:bg-green-50 px-8 py-6 text-lg"
                  onClick={() => onNavigate('about')}
                >
                  Learn More
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 pt-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center space-y-2">
                    <div className="flex justify-center">
                      <stat.icon className="w-8 h-8 text-green-600" />
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{index === 3 ? '97%' : '0'}</div>
                    <div className="text-sm text-gray-600">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:pl-8">
              <div className="relative">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1702529590335-3c6dae4ffe02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzdXN0YWluYWJsZSUyMGFncmljdWx0dXJlJTIwZmFybSUyMGxhbmRzY2FwZSUyMGdyZWVuJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTc1MTUxNzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Sustainable Agriculture Technology"
                  className="w-full h-[500px] object-cover rounded-2xl shadow-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
              Our Services
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
              Comprehensive Agricultural Solutions
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              From traditional farming to cutting-edge food technology, we provide specialized advisory 
              services to help you succeed in every aspect of agricultural development.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Card 
                key={service.id} 
                className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-gradient-to-br from-white to-gray-50"
                onClick={() => onNavigate(service.id)}
              >
                <CardHeader className="space-y-4">
                  <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-green-600 transition-colors">
                      {service.title}
                    </CardTitle>
                    <CardDescription className="text-gray-600 mt-2">
                      {service.description}
                    </CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    {service.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <Button 
                    className={`w-full ${service.color} ${service.hoverColor} text-white mt-6`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate(service.id);
                    }}
                  >
                    Explore Service
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-green-50 to-emerald-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
                  Why Choose Terra Tech
                </Badge>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
                  Advanced AI Technology Meets Agricultural Expertise
                </h2>
                <p className="text-lg text-gray-600">
                  Our platform combines cutting-edge artificial intelligence with decades of agricultural 
                  expertise to deliver personalized solutions for your farming challenges.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Lightbulb className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">AI-Powered Insights</h3>
                    <p className="text-gray-600">Get personalized recommendations based on advanced machine learning algorithms and real-time data analysis.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Expert Validation</h3>
                    <p className="text-gray-600">All AI recommendations are validated by our team of agricultural experts and agronomists.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Proven Results</h3>
                    <p className="text-gray-600">Join thousands of farmers who have increased their yield and reduced costs with our solutions.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:pl-8">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1715199281917-5e5b20d5c038?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMGZhcm1pbmclMjB0ZWNobm9sb2d5JTIwcHJlY2lzaW9uJTIwYWdyaWN1bHR1cmUlMjBkcm9uZXN8ZW58MXx8fHwxNzU3NTE1MTcwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Precision Agriculture Technology"
                className="w-full h-[400px] object-cover rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-green-600">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-white">
            Ready to Transform Your Agricultural Journey?
          </h2>
          <p className="text-lg text-green-100 max-w-2xl mx-auto">
            Join thousands of farmers who trust Terra Tech for their agricultural advisory needs. 
            Start your journey towards sustainable and profitable farming today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-6 text-lg"
              onClick={() => onNavigate('agriculture')}
            >
              Start Free Consultation
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-6 text-lg"
              onClick={() => onNavigate('contact')}
            >
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}