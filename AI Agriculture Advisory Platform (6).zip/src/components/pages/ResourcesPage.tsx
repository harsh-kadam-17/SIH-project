import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  BookOpen, 
  FileText, 
  Video, 
  Download, 
  ExternalLink,
  Users,
  Globe
} from 'lucide-react';

export function ResourcesPage() {
  const resourceCategories = [
    {
      title: 'Agriculture Resources',
      icon: BookOpen,
      color: 'bg-green-500',
      resources: [
        {
          title: 'Crop Management Guide',
          type: 'PDF',
          description: 'Comprehensive guide to crop planning and management',
          size: '2.5 MB',
          downloads: '1,245'
        },
        {
          title: 'Soil Health Assessment',
          type: 'Video',
          description: 'Video tutorial on soil testing and analysis',
          duration: '15 min',
          views: '3,456'
        },
        {
          title: 'Pest Control Handbook',
          type: 'PDF',
          description: 'Integrated pest management strategies',
          size: '1.8 MB',
          downloads: '892'
        }
      ]
    },
    {
      title: 'Food Technology Resources',
      icon: FileText,
      color: 'bg-blue-500',
      resources: [
        {
          title: 'Food Safety Standards',
          type: 'PDF',
          description: 'HACCP implementation and food safety protocols',
          size: '3.2 MB',
          downloads: '678'
        },
        {
          title: 'Processing Techniques',
          type: 'Video',
          description: 'Modern food processing methods and equipment',
          duration: '22 min',
          views: '2,134'
        },
        {
          title: 'Quality Control Checklist',
          type: 'PDF',
          description: 'Quality assurance and control procedures',
          size: '1.2 MB',
          downloads: '543'
        }
      ]
    },
    {
      title: 'Rural Development Resources',
      icon: Users,
      color: 'bg-purple-500',
      resources: [
        {
          title: 'Community Planning Toolkit',
          type: 'PDF',
          description: 'Participatory planning and development strategies',
          size: '4.1 MB',
          downloads: '456'
        },
        {
          title: 'Livelihood Programs',
          type: 'Video',
          description: 'Successful rural livelihood enhancement cases',
          duration: '18 min',
          views: '1,789'
        },
        {
          title: 'Infrastructure Development',
          type: 'PDF',
          description: 'Rural infrastructure planning and implementation',
          size: '2.9 MB',
          downloads: '321'
        }
      ]
    }
  ];

  const externalResources = [
    {
      title: 'FAO Sustainable Agriculture',
      description: 'Food and Agriculture Organization resources on sustainable practices',
      url: 'https://www.fao.org/sustainable-agriculture/en/',
      organization: 'FAO'
    },
    {
      title: 'ICAR Research Portal',
      description: 'Indian Council of Agricultural Research publications',
      url: 'https://www.icar.org.in/',
      organization: 'ICAR'
    },
    {
      title: 'Agriculture.com',
      description: 'Latest agricultural news, trends, and technology updates',
      url: 'https://www.agriculture.com/',
      organization: 'Agriculture.com'
    },
    {
      title: 'World Bank Rural Development',
      description: 'Rural development strategies and best practices',
      url: 'https://www.worldbank.org/en/topic/rural-development',
      organization: 'World Bank'
    },
    {
      title: 'USDA Food Safety',
      description: 'Food safety guidelines and regulations',
      url: 'https://www.fsis.usda.gov/',
      organization: 'USDA'
    }
  ];



  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center space-y-6 mb-16">
          <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
            Knowledge Resources
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
            Learning Resources & Tools
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Access comprehensive resources and guides to enhance your 
            knowledge in agriculture, food technology, and rural development.
          </p>
        </div>

        {/* Resource Categories */}
        <div className="space-y-12 mb-16">
          {resourceCategories.map((category, index) => (
            <div key={index}>
              <div className="flex items-center gap-3 mb-6">
                <div className={`w-10 h-10 ${category.color} rounded-lg flex items-center justify-center`}>
                  <category.icon className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">{category.title}</h2>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.resources.map((resource, resourceIndex) => (
                  <Card key={resourceIndex} className="hover:shadow-lg transition-shadow border-0">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-2">{resource.title}</CardTitle>
                          <CardDescription>{resource.description}</CardDescription>
                        </div>
                        <Badge variant="outline" className="ml-2">
                          {resource.type}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        {resource.type === 'PDF' ? (
                          <>
                            <span>Size: {resource.size}</span>
                            <span>{resource.downloads} downloads</span>
                          </>
                        ) : (
                          <>
                            <span>Duration: {resource.duration}</span>
                            <span>{resource.views} views</span>
                          </>
                        )}
                      </div>
                      <Button className="w-full" variant="outline">
                        {resource.type === 'PDF' ? (
                          <>
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </>
                        ) : (
                          <>
                            <Video className="w-4 h-4 mr-2" />
                            Watch
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* External Resources */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <Globe className="w-6 h-6 text-blue-600" />
            External Resources
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {externalResources.map((resource, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow border-0">
                <CardHeader>
                  <CardTitle className="text-lg">{resource.title}</CardTitle>
                  <CardDescription>{resource.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary">{resource.organization}</Badge>
                    <Button size="sm" variant="outline" asChild>
                      <a href={resource.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Visit
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>


      </div>
    </div>
  );
}