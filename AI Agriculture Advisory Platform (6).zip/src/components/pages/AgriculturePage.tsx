import React, { useState, useRef } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ChatBot } from '../ChatBot';
import { QuotaExceededNotice } from '../QuotaExceededNotice';
import { createOpenAI, formatResponse } from '../utils/openai-ai-system';
import { 
  Tractor, 
  Leaf, 
  Droplets, 
  Bug, 
  Calendar,
  TrendingUp,
  Shield,
  Upload,
  Search,
  FileText,
  BarChart3,
  AlertTriangle,
  Loader,
  CheckCircle,
  XCircle,
  Key,
  Camera,
  Smartphone,
  ImageIcon
} from 'lucide-react';

export function AgriculturePage() {
  const [selectedQueryType, setSelectedQueryType] = useState('text');
  const [textQuery, setTextQuery] = useState('');
  const [selectedImages, setSelectedImages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState(null);
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [hasSubmittedQuestion, setHasSubmittedQuestion] = useState(false);
  
  // Initialize OpenAI system
  const [openaiSystem] = useState(() => createOpenAI('agriculture'));
  
  // Refs for file inputs
  const fileInputRef = useRef(null);
  const combinedFileInputRef = useRef(null);

  const services = [
    {
      icon: Leaf,
      title: 'Crop Management',
      description: 'Optimize your crop planning, variety selection, and growth monitoring with AI-powered insights.',
      features: ['Crop Planning', 'Variety Selection', 'Growth Monitoring', 'Harvest Timing'],
      color: 'bg-green-500'
    },
    {
      icon: Droplets,
      title: 'Soil Health Analysis',
      description: 'Comprehensive soil testing and analysis to improve fertility and crop yields.',
      features: ['Soil Testing', 'Nutrient Analysis', 'pH Management', 'Organic Matter'],
      color: 'bg-blue-500'
    },
    {
      icon: Bug,
      title: 'Pest & Disease Control',
      description: 'Early detection and treatment recommendations for pests and diseases.',
      features: ['Disease Detection', 'Pest Identification', 'Treatment Plans', 'Prevention Tips'],
      color: 'bg-red-500'
    },
    {
      icon: Droplets,
      title: 'Irrigation Management',
      description: 'Optimize water usage with smart irrigation scheduling and techniques.',
      features: ['Water Scheduling', 'Drip Systems', 'Moisture Monitoring', 'Conservation'],
      color: 'bg-cyan-500'
    }
  ];

  const queryTypes = [
    {
      id: 'text',
      title: 'Text Query',
      description: 'Ask your farming questions in text',
      icon: FileText
    },
    {
      id: 'image',
      title: 'AI Vision Analysis',
      description: 'Upload images for AI analysis',
      icon: Upload
    },
    {
      id: 'combined',
      title: 'Vision + Text',
      description: 'Combine questions with image analysis',
      icon: BarChart3
    }
  ];

  // Function to handle starting a new question
  const handleStartNewQuestion = () => {
    setHasSubmittedQuestion(false);
    setAiResponse(null);
  };

  const processFiles = (files) => {
    const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    // Limit to 4 images for performance
    if (selectedImages.length + imageFiles.length > 4) {
      alert('Maximum 4 images allowed for analysis. Please remove some images first.');
      return;
    }
    
    imageFiles.forEach(file => {
      // Check file size (max 10MB per image)
      if (file.size > 10 * 1024 * 1024) {
        alert(`Image "${file.name}" is too large. Maximum size is 10MB per image.

Tip: Try compressing the image or taking a new photo.`);
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = {
          file,
          dataUrl: e.target.result,
          name: file.name,
          size: file.size,
          type: file.type
        };
        setSelectedImages(prev => [...prev, imageData]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleImageUpload = (e) => {
    if (hasSubmittedQuestion) {
      handleStartNewQuestion();
    }
    processFiles(e.target.files);
    // Clear the input so the same file can be uploaded again
    e.target.value = '';
  };

  // Drag and drop handlers
  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(files);
    }
  };

  const removeImage = (index) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitQuery = async () => {
    if (!textQuery.trim() && selectedImages.length === 0) {
      alert('Please enter a question or upload images for analysis.');
      return;
    }

    setIsLoading(true);
    setAiResponse(null);
    setHasSubmittedQuestion(true);

    try {
      let finalQuery = textQuery.trim();
      
      if (selectedQueryType === 'image' && selectedImages.length > 0) {
        finalQuery = `Please analyze these agricultural images in detail. Identify:
- Crop type and growth stage
- Any diseases, pests, or issues visible
- Soil conditions if visible
- Nutrient deficiencies or plant stress
- Specific treatment recommendations
- Preventive measures

Provide detailed, actionable advice for improving the agricultural conditions shown.`;
      } else if (selectedQueryType === 'combined' && selectedImages.length > 0) {
        finalQuery = `${finalQuery}

I have also uploaded ${selectedImages.length} supporting image(s) for analysis. Please:
1. Answer my specific question: "${textQuery}"
2. Analyze the uploaded images for additional context
3. Provide comprehensive recommendations based on both the question and visual analysis
4. Give specific, actionable steps I can take

Please integrate both the text question and image analysis in your response.`;
      }

      // Ensure we have some query text for image-only analysis
      if (!finalQuery && selectedImages.length > 0) {
        finalQuery = "Please analyze these agricultural images and provide expert recommendations.";
      }

      console.log('🚀 AgriculturePage: Sending query to OpenAI:', {
        queryType: selectedQueryType,
        hasText: !!finalQuery,
        queryLength: finalQuery.length,
        imageCount: selectedImages.length,
        images: selectedImages.map((img, idx) => ({
          index: idx,
          name: img.name,
          type: img.type,
          size: img.size,
          hasDataUrl: !!img.dataUrl,
          dataUrlStart: img.dataUrl ? img.dataUrl.substring(0, 30) + '...' : 'N/A'
        }))
      });

      const response = await openaiSystem.generateResponse(finalQuery, selectedImages);
      setAiResponse(response);

      // Only clear inputs on successful response from AI
      if (response.type === 'success') {
        setTextQuery('');
        setSelectedImages([]);
      }
    } catch (error) {
      console.error('Error generating response:', error);
      setAiResponse({
        content: `Error: Failed to get AI response. ${error.message || 'Please check your API key and internet connection.'}`,
        type: 'error',
        confidence: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetApiKey = () => {
    if (apiKey.trim()) {
      openaiSystem.setApiKey(apiKey.trim());
      setApiKey('');
      setShowApiKeyInput(false);
      setAiResponse({
        content: `API Key Set Successfully!

You can now ask agricultural questions and get expert AI-powered responses.`,
        type: 'success',
        confidence: 1
      });
    }
  };

  // Helper function to get button text for analysis
  const getAnalysisButtonText = () => {
    if (selectedImages.length === 0) return 'Get Complete Analysis';
    const photoText = selectedImages.length === 1 ? 'photo' : 'photos';
    return `Get Complete Analysis (${selectedImages.length} ${photoText})`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-6 mb-16">
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
              Agriculture Advisory
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Smart Agriculture Solutions
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Get expert AI-powered advice with <strong>real image analysis</strong> using OpenAI Vision API. Upload photos of crops, diseases, pests, or soil conditions for instant diagnosis and treatment recommendations.
            </p>
          </div>

          {/* AI Query Interface */}
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Tractor className="w-6 h-6 text-green-600" />
                  Terra Tech Agriculture AI Assistant
                </CardTitle>
                <CardDescription>
                  Choose how you'd like to ask your farming question
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Query Type Selection */}
                <Tabs value={selectedQueryType} onValueChange={(value) => {
                  setSelectedQueryType(value);
                  handleStartNewQuestion();
                }}>
                  <TabsList className="grid w-full grid-cols-3">
                    {queryTypes.map((type) => (
                      <TabsTrigger 
                        key={type.id} 
                        value={type.id}
                        className="flex items-center gap-2"
                      >
                        <type.icon className="w-4 h-4" />
                        {type.title}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  <TabsContent value="text" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Ask Your Farming Question</h3>
                      <Textarea
                        placeholder="e.g., My tomato leaves are turning yellow, what could be the cause? How can I improve my soil fertility?"
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[120px] resize-none"
                        rows={5}
                      />
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={!textQuery.trim() || isLoading}
                      className="w-full bg-green-600 hover:bg-green-700 py-6 text-lg font-semibold"
                    >
                      {isLoading ? (
                        <>
                          <Loader className="w-5 h-5 mr-3 animate-spin" />
                          Getting expert farming advice...
                        </>
                      ) : (
                        <>
                          <Search className="w-5 h-5 mr-3" />
                          Get Expert Agricultural Advice
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  <TabsContent value="image" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-3">Upload Your Farm Images</h3>
                      <div 
                        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-green-500 bg-green-50 scale-105' 
                            : 'border-green-300 hover:border-green-400 hover:bg-green-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-4">
                          <div className="flex items-center space-x-4">
                            <Camera className="w-12 h-12 text-green-500" />
                            <Upload className="w-12 h-12 text-green-500" />
                            <ImageIcon className="w-12 h-12 text-green-500" />
                          </div>
                          
                          <div className="space-y-2">
                            <p className="text-lg font-medium text-gray-800">
                              {dragActive ? 'Drop your images here!' : 'Show me your farming issue'}
                            </p>
                            <p className="text-sm text-gray-600">
                              Take photos of: crops, leaves, diseases, pests, soil, or any farm problems<br/>
                              Works with phone camera • Drag & drop • Browse files
                            </p>
                          </div>

                          <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-xs text-green-800 max-w-md">
                            <strong>Photography Tips for Best Results:</strong><br/>
                            • Take clear, well-lit photos<br/>
                            • Include close-ups of affected areas<br/>
                            • Show overall plant/field context<br/>
                            • Capture different angles if possible
                          </div>

                          <div className="flex flex-col sm:flex-row gap-3">
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="image-upload"
                              capture="environment"
                            />
                            <label htmlFor="image-upload">
                              <Button variant="outline" className="cursor-pointer border-green-500 text-green-700 hover:bg-green-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take/Choose Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                            
                            <Button
                              variant="outline"
                              className="border-blue-500 text-blue-700 hover:bg-blue-50"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              <Upload className="w-4 h-4 mr-2" />
                              Browse Files
                            </Button>
                          </div>

                          <p className="text-xs text-gray-500">
                            Max 4 images • 10MB each • JPG/PNG formats
                          </p>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-green-800">Photos Ready for AI Analysis:</h4>
                            <Badge variant="secondary" className="bg-green-100 text-green-800">
                              {selectedImages.length}/4 images
                            </Badge>
                          </div>
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                            {selectedImages.map((image, index) => (
                              <div key={`image-${index}-${image.name}`} className="relative group">
                                <div className="relative aspect-square w-full overflow-hidden rounded-lg border-2 border-green-200 shadow-sm bg-gray-50">
                                  <img
                                    src={image.dataUrl}
                                    alt={`Agricultural image ${index + 1}: ${image.name}`}
                                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                    onError={(e) => {
                                      console.error('Image failed to load:', image.name);
                                      e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2VlZSIvPjx0ZXh0IHg9IjUwJSIgeT0iNTAlIiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiIGZpbGw9IiM5OTkiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj5JbWFnZSBFcnJvcjwvdGV4dD48L3N2Zz4=';
                                    }}
                                    loading="lazy"
                                  />
                                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-all duration-200" />
                                  
                                  {/* Image controls overlay */}
                                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                    <Button
                                      size="sm"
                                      variant="destructive"
                                      className="w-6 h-6 p-0 rounded-full shadow-lg hover:scale-110 transition-transform"
                                      onClick={() => removeImage(index)}
                                      title={`Remove ${image.name}`}
                                      aria-label={`Remove image ${index + 1}`}
                                    >
                                      ×
                                    </Button>
                                  </div>
                                  
                                  {/* Image metadata overlay */}
                                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent p-2 rounded-b-lg">
                                    <div className="text-white text-xs space-y-1">
                                      <div className="truncate font-medium">
                                        {image.name}
                                      </div>
                                      <div className="flex items-center justify-between text-white/80">
                                        <span>{(image.size / (1024 * 1024)).toFixed(1)} MB</span>
                                        <span className="bg-green-500 text-white px-2 py-0.5 rounded text-xs font-medium">
                                          #{index + 1}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                  
                                  {/* Loading indicator for slow images */}
                                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-lg opacity-0 group-hover:opacity-0">
                                    <div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin"></div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div className="flex items-start gap-3">
                              <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                                <span className="text-white text-xs">AI</span>
                              </div>
                              <div className="text-sm text-green-800 space-y-1">
                                <div className="font-semibold">OpenAI Vision Analysis will identify:</div>
                                <div className="text-green-700">
                                  • Crop types and growth stages • Plant diseases and symptoms<br/>
                                  • Pest identification and damage • Soil conditions and deficiencies<br/>
                                  • Nutrient problems and solutions • Treatment recommendations
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={selectedImages.length === 0 || isLoading}
                      className="w-full bg-green-600 hover:bg-green-700 py-6 text-lg font-semibold"
                    >
                      {isLoading ? (
                        <>
                          <Loader className="w-5 h-5 mr-3 animate-spin" />
                          🔍 OpenAI Vision API analyzing your farm images...
                        </>
                      ) : (
                        <>
                          <Search className="w-5 h-5 mr-3" />
                          Get Expert Diagnosis for {selectedImages.length} Photo{selectedImages.length !== 1 ? 's' : ''}
                        </>
                      )}
                    </Button>
                  </TabsContent>

                  <TabsContent value="combined" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Describe Your Issue</h3>
                      <Textarea
                        placeholder="Describe what you're seeing in the images and your specific question... e.g., These are my tomato plants, the leaves look strange - what's wrong?"
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[100px] resize-none"
                        rows={4}
                      />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-3">Add Supporting Photos</h3>
                      <div 
                        className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-blue-500 bg-blue-50 scale-105' 
                            : 'border-blue-300 hover:border-blue-400 hover:bg-blue-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-3">
                          <div className="flex items-center space-x-3">
                            <Camera className="w-8 h-8 text-blue-500" />
                            <Upload className="w-8 h-8 text-blue-500" />
                          </div>
                          
                          <p className="text-gray-700 font-medium">
                            {dragActive ? 'Drop supporting images here!' : 'Add photos to help explain your issue'}
                          </p>
                          <p className="text-xs text-gray-600 max-w-sm">
                            Upload images that show the problem you described above
                          </p>

                          <div className="flex gap-2">
                            <input
                              ref={combinedFileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="combined-upload"
                              capture="environment"
                            />
                            <label htmlFor="combined-upload">
                              <Button variant="outline" className="cursor-pointer border-blue-500 text-blue-700 hover:bg-blue-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                          </div>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-blue-800">Supporting Images:</h4>
                          <div className="grid grid-cols-3 gap-3">
                            {selectedImages.map((image, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={image.dataUrl}
                                  alt={image.name}
                                  className="w-full h-24 object-cover rounded-lg border-2 border-blue-200"
                                />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  className="absolute -top-1 -right-1 w-6 h-6 p-0 rounded-full text-xs opacity-80 hover:opacity-100"
                                  onClick={() => removeImage(index)}
                                  title="Remove image"
                                >
                                  ×
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={(!textQuery.trim() && selectedImages.length === 0) || isLoading}
                      className="w-full bg-green-600 hover:bg-green-700 py-6 text-lg font-semibold"
                    >
                      {isLoading ? (
                        <>
                          <Loader className="w-5 h-5 mr-3 animate-spin" />
                          🔍 OpenAI Vision API analyzing your question + photos...
                        </>
                      ) : (
                        <>
                          <Search className="w-5 h-5 mr-3" />
                          {getAnalysisButtonText()}
                        </>
                      )}
                    </Button>
                  </TabsContent>
                </Tabs>

                {/* API Key Setup */}
                {!openaiSystem.hasApiKey() && !showApiKeyInput && (
                  <div className="hidden mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Key className="w-5 h-5 text-yellow-600" />
                      <div className="flex-1">
                        <h4 className="font-semibold text-yellow-800">OpenAI API Key Required</h4>
                        <p className="text-sm text-yellow-700">Set your OpenAI API key to get AI-powered agricultural advice</p>
                      </div>
                      <Button 
                        onClick={() => setShowApiKeyInput(true)}
                        variant="outline"
                        size="sm"
                        className="border-yellow-300 text-yellow-800 hover:bg-yellow-100"
                      >
                        <Key className="w-4 h-4 mr-2" />
                        Set API Key
                      </Button>
                    </div>
                  </div>
                )}

                {showApiKeyInput && (
                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-3">Enter Your OpenAI API Key</h4>
                    <div className="flex gap-3">
                      <Input
                        type="password"
                        placeholder="sk-..."
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        className="flex-1"
                      />
                      <Button 
                        onClick={handleSetApiKey}
                        disabled={!apiKey.trim()}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Save
                      </Button>
                      <Button 
                        onClick={() => setShowApiKeyInput(false)}
                        variant="outline"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Photography Tips for Farmers */}
          <div className="max-w-4xl mx-auto mb-16">
            {(selectedQueryType === 'image' || selectedQueryType === 'combined') && (
            <Card className="border-0 bg-gradient-to-r from-green-50 to-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <Camera className="w-6 h-6" />
                  Photography Tips for Better AI Analysis
                </CardTitle>
                <CardDescription>
                  Follow these simple tips to get the most accurate diagnosis from our AI vision system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-green-600 font-bold text-sm">1</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Clear, Well-Lit Photos</h4>
                        <p className="text-sm text-gray-600">Take photos in natural daylight, avoid shadows, and ensure the subject is clearly visible</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-green-600 font-bold text-sm">2</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Close-Up Details</h4>
                        <p className="text-sm text-gray-600">Capture close-ups of affected leaves, stems, fruits, or problem areas</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-green-600 font-bold text-sm">3</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Overall Context</h4>
                        <p className="text-sm text-gray-600">Include wider shots showing the entire plant or field area for context</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">4</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Multiple Angles</h4>
                        <p className="text-sm text-gray-600">Take photos from different angles - top, bottom, sides of leaves or plants</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">5</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Include Soil</h4>
                        <p className="text-sm text-gray-600">For plant health issues, include soil conditions around the plant base</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">6</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Size Reference</h4>
                        <p className="text-sm text-gray-600">Include your hand, a coin, or ruler for size reference when showing damage</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mt-0.5">
                      <span className="text-yellow-600 text-sm">💡</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-yellow-800 mb-1">Best Results:</h4>
                      <p className="text-sm text-yellow-700">
                        Upload 2-4 images showing both the problem area in detail and the overall plant/field context. 
                        This helps our AI provide the most accurate diagnosis and treatment recommendations.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            )}
          </div>

          {/* AI Response Display */}
          {aiResponse && (
            <div className="max-w-4xl mx-auto mb-16">
              {/* Special handling for quota exceeded errors */}
              {aiResponse.type === 'error' && 
               aiResponse.content.includes('temporarily limited') ||
               aiResponse.content.includes('quota') ||
               aiResponse.content.includes('Quota Exceeded') ? (
                <QuotaExceededNotice 
                  context="agriculture"
                  onRetry={async () => {
                    setIsLoading(true);
                    try {
                      // Retry the last query
                      const response = await openaiSystem.generateResponse(textQuery, selectedImages);
                      setAiResponse(response);
                    } catch (error) {
                      console.error('Retry failed:', error);
                    } finally {
                      setIsLoading(false);
                    }
                  }}
                  isRetrying={isLoading}
                />
              ) : (
                <Card className="shadow-xl border-0">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {aiResponse.type === 'success' && <CheckCircle className="w-6 h-6 text-green-600" />}
                      {aiResponse.type === 'error' && <XCircle className="w-6 h-6 text-red-600" />}
                      {aiResponse.type === 'suggestion' && <AlertTriangle className="w-6 h-6 text-yellow-600" />}
                      {aiResponse.type === 'redirect' && <AlertTriangle className="w-6 h-6 text-orange-600" />}
                      {aiResponse.type === 'quota_exceeded' && <AlertTriangle className="w-6 h-6 text-orange-600" />}
                      AI Agricultural Advisor Response
                    </CardTitle>
                    <CardDescription>
                      {aiResponse.type === 'success' && 'Expert agricultural guidance powered by OpenAI Vision'}
                      {aiResponse.type === 'error' && 'There was an issue processing your request'}
                      {aiResponse.type === 'suggestion' && 'Helpful guidance and suggestions'}
                      {aiResponse.type === 'redirect' && 'Query redirection recommended'}
                      {aiResponse.type === 'quota_exceeded' && 'API usage limit reached - please try again later'}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Error Details for Image Analysis Issues */}
                    {aiResponse.type === 'error' && aiResponse.errorCode && (
                      <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <XCircle className="w-5 h-5 text-red-600" />
                          <span className="font-medium text-red-800">
                            {aiResponse.errorCode === 'INVALID_API_KEY' && 'API Key Issue'}
                            {aiResponse.errorCode === 'IMAGE_TOO_LARGE' && 'Image Size Issue'}
                            {aiResponse.errorCode === 'UNSUPPORTED_FORMAT' && 'Image Format Issue'}
                            {aiResponse.errorCode === 'NETWORK_ERROR' && 'Connection Issue'}
                            {aiResponse.errorCode === 'RATE_LIMIT' && 'Rate Limit Exceeded'}
                            {aiResponse.errorCode === 'VISION_ERROR' && 'Vision Analysis Failed'}
                            {!['INVALID_API_KEY', 'IMAGE_TOO_LARGE', 'UNSUPPORTED_FORMAT', 'NETWORK_ERROR', 'RATE_LIMIT', 'VISION_ERROR'].includes(aiResponse.errorCode) && 'Analysis Error'}
                          </span>
                        </div>
                        <div className="text-sm text-red-700 space-y-2">
                          {aiResponse.errorCode === 'IMAGE_TOO_LARGE' && (
                            <>
                              <p>Your images are too large for processing. Please:</p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Reduce image size to under 10MB each</li>
                                <li>Use JPG format for better compression</li>
                                <li>Try uploading fewer images at once</li>
                              </ul>
                            </>
                          )}
                          {aiResponse.errorCode === 'UNSUPPORTED_FORMAT' && (
                            <>
                              <p>Image format not supported. Please use:</p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>JPG/JPEG images</li>
                                <li>PNG images</li>
                                <li>Avoid GIF, BMP, or other formats</li>
                              </ul>
                            </>
                          )}
                          {aiResponse.errorCode === 'VISION_ERROR' && (
                            <>
                              <p>OpenAI Vision analysis failed. This could be due to:</p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Images that are too dark or blurry</li>
                                <li>Images without clear agricultural content</li>
                                <li>Temporary OpenAI service issues</li>
                              </ul>
                            </>
                          )}
                          {aiResponse.errorCode === 'RATE_LIMIT' && (
                            <>
                              <p>Too many requests. Please:</p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Wait a few moments before trying again</li>
                                <li>Reduce the number of images</li>
                                <li>Contact support if issue persists</li>
                              </ul>
                            </>
                          )}
                          {aiResponse.errorCode === 'NETWORK_ERROR' && (
                            <>
                              <p>Connection problem. Please:</p>
                              <ul className="list-disc list-inside ml-2 space-y-1">
                                <li>Check your internet connection</li>
                                <li>Refresh the page and try again</li>
                                <li>Contact support if issue persists</li>
                              </ul>
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    <div 
                      className="prose prose-sm max-w-none"
                      dangerouslySetInnerHTML={{ 
                        __html: formatResponse(aiResponse.content) 
                      }}
                    />
                    
                    {/* Success Details for Image Analysis */}
                    {aiResponse.type === 'success' && (
                      <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2 text-sm text-green-700">
                          <CheckCircle className="w-4 h-4" />
                          <span>
                            {aiResponse.analysisType === 'vision' && 'Vision Analysis Complete'}
                            {aiResponse.analysisType === 'text' && 'Text Analysis Complete'}
                            {aiResponse.analysisType === 'combined' && 'Combined Vision + Text Analysis'}
                            {!aiResponse.analysisType && 'Analysis Complete'}
                          </span>
                          {aiResponse.confidence && (
                            <span className="ml-2">• Confidence: {Math.round(aiResponse.confidence * 100)}%</span>
                          )}
                          <span className="ml-auto">
                            {aiResponse.analysisType === 'vision' || aiResponse.analysisType === 'combined' 
                              ? 'Powered by OpenAI GPT-4o Vision' 
                              : 'Powered by OpenAI GPT-4o Mini'
                            }
                          </span>
                        </div>
                        {aiResponse.imageCount && (
                          <div className="mt-2 text-xs text-green-600">
                            ✓ Analyzed {aiResponse.imageCount} image{aiResponse.imageCount > 1 ? 's' : ''} successfully
                          </div>
                        )}
                      </div>
                    )}

                    {/* Quota Exceeded Notice */}
                    {aiResponse.type === 'quota_exceeded' && (
                      <div className="mt-4">
                        <QuotaExceededNotice />
                      </div>
                    )}

                    {/* Action Buttons */}
                    {(aiResponse.type === 'success' || aiResponse.type === 'error') && (
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button 
                          onClick={() => setAiResponse(null)}
                          variant="outline"
                          size="sm"
                        >
                          Ask Another Question
                        </Button>
                        <Button 
                          onClick={() => {
                            setTextQuery('');
                            setSelectedImages([]);
                            setAiResponse(null);
                            setHasSubmittedQuestion(false);
                          }}
                          variant="outline"
                          size="sm"
                        >
                          Start Over
                        </Button>
                        {aiResponse.type === 'error' && (
                          <Button 
                            onClick={() => {
                              // Retry with current images and text
                              console.log('Retrying analysis with current data...');
                              setAiResponse(null);
                            }}
                            variant="outline"
                            size="sm"
                            className="text-blue-600 border-blue-200 hover:bg-blue-50"
                          >
                            Retry Analysis
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Featured Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-900">
                Advanced Crop Analysis with AI
              </h2>
              <p className="text-gray-600 leading-relaxed">
                Our AI system can analyze crop images to detect diseases, nutrient deficiencies, 
                pest infestations, and growth abnormalities. Get instant diagnosis and treatment 
                recommendations based on the latest agricultural research and expert knowledge.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                    <Shield className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Disease Detection</h3>
                    <p className="text-sm text-gray-600">Early identification of plant diseases with 95% accuracy</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Yield Optimization</h3>
                    <p className="text-sm text-gray-600">Data-driven recommendations to maximize crop yields</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                    <AlertTriangle className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Risk Assessment</h3>
                    <p className="text-sm text-gray-600">Proactive identification of potential agricultural risks</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-100 to-emerald-100 p-8 rounded-2xl">
              <div className="text-center space-y-4">
                <div className="flex justify-center space-x-4">
                  <div className="w-16 h-16 bg-green-500 rounded-xl flex items-center justify-center">
                    <Leaf className="w-8 h-8 text-white" />
                  </div>
                  <div className="w-16 h-16 bg-blue-500 rounded-xl flex items-center justify-center">
                    <Droplets className="w-8 h-8 text-white" />
                  </div>
                  <div className="w-16 h-16 bg-orange-500 rounded-xl flex items-center justify-center">
                    <Bug className="w-8 h-8 text-white" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900">AI Vision Analysis</h3>
                <p className="text-gray-700">
                  Upload photos of your crops, soil, or farming issues and get instant expert analysis 
                  powered by advanced computer vision and agricultural AI models.
                </p>
                <div className="bg-white p-4 rounded-lg border-2 border-green-200">
                  <p className="text-sm text-green-800 font-medium">
                    Supports: Crop diseases, pest identification, soil analysis, nutrient deficiencies
                  </p>
                </div>
              </div>
            </div>
          </div>
          </div>
        </section>

        {/* Context-Aware ChatBot */}
        <ChatBot context="agriculture" />
      </div>
  );
}