import React from 'react';
import { UserProfile } from '../UserProfile';
import { Button } from '../ui/button';
import { ArrowLeft } from 'lucide-react';

interface ProfilePageProps {
  user: {
    email: string;
    name: string;
    id: number;
  };
  onNavigate: (page: string) => void;
}

export function ProfilePage({ user, onNavigate }: ProfilePageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-blue-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                onClick={() => onNavigate('home')}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Dashboard
              </Button>
              <div className="w-px h-6 bg-gray-300"></div>
              <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Profile Content */}
      <div className="py-8">
        <UserProfile user={user} />
      </div>
    </div>
  );
}