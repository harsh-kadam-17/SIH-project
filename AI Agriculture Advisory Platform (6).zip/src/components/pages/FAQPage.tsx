import React from 'react';
import { Badge } from '../ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '../ui/accordion';
import { Button } from '../ui/button';
import { 
  HelpCircle,
  ArrowRight,
  Sprout,
  Beaker,
  Building2
} from 'lucide-react';

export function FAQPage({ onNavigate }) {
  const faqData = [
    {
      category: 'Agriculture',
      icon: Sprout,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      questions: [
        {
          question: 'How does AI help optimize crop yields?',
          answer: 'Our AI analyzes soil conditions, weather patterns, and historical data to provide personalized recommendations for planting schedules, irrigation timing, and fertilizer application, typically resulting in 30-40% yield improvements.'
        },
        {
          question: 'What crops and farming methods does Terra Tech support?',
          answer: 'We support all major crops including cereals, vegetables, fruits, and cash crops. Our platform works with traditional farming, precision agriculture, organic farming, and hydroponic systems.'
        },
        {
          question: 'How accurate are your soil health assessments?',
          answer: 'Our soil analysis combines satellite imagery, IoT sensors, and lab data with 98% accuracy. We provide detailed reports on nutrient levels, pH, moisture content, and organic matter composition.'
        },
        {
          question: 'Can your platform help with pest and disease management?',
          answer: 'Yes, our AI identifies pest and disease patterns early through image recognition and environmental monitoring, providing targeted treatment recommendations that reduce pesticide use by up to 50%.'
        },
        {
          question: 'Do you provide weather forecasting and climate advice?',
          answer: 'Our platform integrates real-time weather data and long-term climate projections to help farmers make informed decisions about planting, harvesting, and crop protection strategies.'
        },
        {
          question: 'How can I integrate IoT sensors with your platform?',
          answer: 'We support integration with various IoT devices including soil moisture sensors, weather stations, and crop monitoring cameras. Our API allows seamless data synchronization for comprehensive farm management.'
        }
      ]
    },
    {
      category: 'Food Technology',
      icon: Beaker,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      questions: [
        {
          question: 'What food processing innovations does Terra Tech offer?',
          answer: 'We provide guidance on modern preservation techniques, packaging optimization, nutritional enhancement, and quality control systems that extend shelf life and improve food safety standards.'
        },
        {
          question: 'How do you ensure food safety and quality control?',
          answer: 'Our platform integrates HACCP principles, real-time monitoring systems, and predictive analytics to identify potential contamination risks and maintain consistent quality throughout the production chain.'
        },
        {
          question: 'Can you help with food product development and formulation?',
          answer: 'Absolutely! We assist with recipe optimization, nutritional profiling, texture analysis, and shelf-life testing to develop products that meet market demands and regulatory requirements.'
        },
        {
          question: 'What sustainable packaging solutions do you recommend?',
          answer: 'We advise on biodegradable materials, minimal packaging designs, and smart packaging technologies that reduce environmental impact while maintaining product integrity and consumer appeal.'
        },
        {
          question: 'How do you help with food waste reduction?',
          answer: 'Our AI algorithms analyze production patterns, predict spoilage, and optimize inventory management to minimize food waste throughout the supply chain, typically reducing waste by 25-35%.'
        },
        {
          question: 'Do you provide nutritional analysis and labeling support?',
          answer: 'Yes, we offer comprehensive nutritional analysis, allergen identification, and regulatory compliance support to ensure accurate labeling and meet food safety standards across different markets.'
        }
      ]
    },
    {
      category: 'Rural Development',
      icon: Building2,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
      questions: [
        {
          question: 'How does Terra Tech support community empowerment programs?',
          answer: 'We design comprehensive programs that include farmer training, cooperative formation, market linkage development, and capacity building initiatives that strengthen rural communities economically and socially.'
        },
        {
          question: 'What infrastructure development services do you provide?',
          answer: 'Our services include planning for irrigation systems, storage facilities, transportation networks, and digital connectivity solutions that improve agricultural productivity and market access.'
        },
        {
          question: 'How do you help farmers access better markets and pricing?',
          answer: 'We facilitate direct market connections, help establish farmer producer organizations, provide market intelligence, and develop value chains that ensure fair pricing and reduced intermediary costs.'
        },
        {
          question: 'What training and education programs are available?',
          answer: 'We offer technical training on modern farming practices, financial literacy programs, digital skills development, and leadership training for rural entrepreneurs and community leaders.'
        },
        {
          question: 'How do you support women farmers and rural entrepreneurs?',
          answer: 'We have specialized programs focusing on women\'s economic empowerment, including access to credit, skill development, market linkages, and leadership training tailored for women in agriculture.'
        },
        {
          question: 'Can you help with microfinance and agricultural lending?',
          answer: 'We partner with financial institutions to facilitate access to credit, help farmers understand loan products, and provide financial literacy training to improve creditworthiness and financial management.'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-green-50 via-emerald-50 to-blue-50">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center">
              <HelpCircle className="w-8 h-8 text-white" />
            </div>
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200 text-lg px-6 py-3">
              Frequently Asked Questions
            </Badge>
          </div>
          
          <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
            Everything You Need to Know About 
            <span className="text-green-600"> Terra Tech</span>
          </h1>
          
          <p className="text-xl text-gray-600 leading-relaxed max-w-3xl mx-auto">
            Get comprehensive answers about our AI-powered agricultural advisory services across 
            agriculture, food technology, and rural development domains.
          </p>
        </div>
      </section>

      {/* FAQ Sections */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {faqData.map((category, categoryIndex) => (
              <div key={categoryIndex} className="space-y-8">
                {/* Category Header */}
                <div className={`${category.bgColor} rounded-2xl p-8 text-center border-2 ${category.borderColor}`}>
                  <div className="flex items-center justify-center mb-6">
                    <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center shadow-lg">
                      <category.icon className={`w-10 h-10 ${category.color}`} />
                    </div>
                  </div>
                  <h2 className={`text-3xl font-bold ${category.color} mb-4`}>
                    {category.category}
                  </h2>
                  <p className="text-gray-600 text-lg">
                    {category.category === 'Agriculture' && 'Smart farming solutions and crop optimization strategies'}
                    {category.category === 'Food Technology' && 'Innovation in food processing, safety, and sustainability'}
                    {category.category === 'Rural Development' && 'Community empowerment and sustainable infrastructure'}
                  </p>
                  <Button
                    className={`mt-6 ${category.color.replace('text-', 'bg-').replace('-600', '-600')} hover:${category.color.replace('text-', 'bg-').replace('-600', '-700')} text-white`}
                    onClick={() => onNavigate && onNavigate(category.category.toLowerCase().replace(' ', '-'))}
                  >
                    Explore {category.category}
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>

                {/* FAQ Questions */}
                <div className="space-y-4">
                  <Accordion type="single" collapsible className="space-y-4">
                    {category.questions.map((faq, faqIndex) => (
                      <AccordionItem 
                        key={faqIndex} 
                        value={`${categoryIndex}-${faqIndex}`}
                        className="border rounded-xl px-6 bg-white shadow-sm hover:shadow-md transition-all duration-200"
                      >
                        <AccordionTrigger className="text-left hover:no-underline py-6">
                          <span className="font-semibold text-gray-900 pr-4 text-base leading-relaxed">
                            {faq.question}
                          </span>
                        </AccordionTrigger>
                        <AccordionContent className="pb-6 text-gray-600 leading-relaxed text-base">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-green-600">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h2 className="text-3xl lg:text-4xl font-bold text-white">
            Still Have Questions?
          </h2>
          <p className="text-lg text-green-100 max-w-2xl mx-auto leading-relaxed">
            Our team of agricultural experts and technical specialists are here to provide 
            personalized answers to your specific needs and challenges.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-white text-green-600 hover:bg-gray-100 px-8 py-6 text-lg"
              onClick={() => onNavigate && onNavigate('contact')}
            >
              Contact Our Experts
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-green-600 px-8 py-6 text-lg"
              onClick={() => onNavigate && onNavigate('agriculture')}
            >
              Try Our AI Assistant
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}