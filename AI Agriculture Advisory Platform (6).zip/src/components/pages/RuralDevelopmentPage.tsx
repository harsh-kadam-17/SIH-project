import React, { useState, useRef } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ChatBot } from '../ChatBot';
import { QuotaExceededNotice } from '../QuotaExceededNotice';
import { createOpenAI, formatResponse } from '../utils/openai-ai-system';
import { 
  Users, 
  Building, 
  GraduationCap, 
  DollarSign, 
  Heart,
  Lightbulb,
  TrendingUp,
  MapPin,
  Upload,
  Search,
  FileText,
  BarChart3,
  HandHeart,
  Briefcase,
  Loader,
  CheckCircle,
  XCircle,
  Key,
  AlertTriangle,
  Camera,
  ImageIcon
} from 'lucide-react';

export function RuralDevelopmentPage() {
  const [selectedQueryType, setSelectedQueryType] = useState('text');
  const [textQuery, setTextQuery] = useState('');
  const [selectedImages, setSelectedImages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState(null);
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [hasSubmittedQuestion, setHasSubmittedQuestion] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  
  // Initialize OpenAI system
  const [openaiSystem] = useState(() => createOpenAI('rural-development'));
  
  // Refs for file inputs
  const fileInputRef = useRef(null);
  const combinedFileInputRef = useRef(null);

  const services = [
    {
      icon: Users,
      title: 'Community Development',
      description: 'Strengthen communities through participatory development and social programs.',
      features: ['Community Mobilization', 'Participatory Planning', 'Social Cohesion', 'Leadership Development'],
      color: 'bg-purple-500'
    },
    {
      icon: Building,
      title: 'Infrastructure Development',
      description: 'Essential infrastructure for sustainable rural growth and connectivity.',
      features: ['Water Systems', 'Road Connectivity', 'Digital Infrastructure', 'Energy Access'],
      color: 'bg-orange-500'
    },
    {
      icon: GraduationCap,
      title: 'Capacity Building',
      description: 'Skills training and education programs for sustainable development.',
      features: ['Skill Training', 'Education Programs', 'Technical Training', 'Leadership Skills'],
      color: 'bg-blue-500'
    },
    {
      icon: DollarSign,
      title: 'Economic Development',
      description: 'Livelihood enhancement and entrepreneurship support for rural communities.',
      features: ['Microfinance', 'Entrepreneurship', 'Market Linkages', 'Value Addition'],
      color: 'bg-green-500'
    }
  ];

  const queryTypes = [
    {
      id: 'text',
      title: 'Text Query',
      description: 'Ask rural development questions',
      icon: FileText
    },
    {
      id: 'image',
      title: 'Community Analysis',
      description: 'Upload community/project images',
      icon: Upload
    },
    {
      id: 'combined',
      title: 'Project Assessment',
      description: 'Combine text with project images',
      icon: BarChart3
    }
  ];

  // Function to handle starting a new question
  const handleStartNewQuestion = () => {
    setHasSubmittedQuestion(false);
    setAiResponse(null);
  };

  const processFiles = (files) => {
    const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    // Limit to 4 images for performance
    if (selectedImages.length + imageFiles.length > 4) {
      alert('Maximum 4 images allowed for analysis. Please remove some images first.');
      return;
    }
    
    imageFiles.forEach(file => {
      // Check file size (max 10MB per image)
      if (file.size > 10 * 1024 * 1024) {
        alert(`Image "${file.name}" is too large. Maximum size is 10MB per image.

Tip: Try compressing the image or taking a new photo.`);
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = {
          file,
          dataUrl: e.target.result,
          name: file.name,
          size: file.size,
          type: file.type
        };
        setSelectedImages(prev => [...prev, imageData]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleImageUpload = (e) => {
    if (hasSubmittedQuestion) {
      handleStartNewQuestion();
    }
    processFiles(e.target.files);
    // Clear the input so the same file can be uploaded again
    e.target.value = '';
  };

  // Drag and drop handlers
  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(files);
    }
  };

  const removeImage = (index) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitQuery = async () => {
    if (!textQuery.trim() && selectedImages.length === 0) {
      alert('Please enter a question or upload images for analysis.');
      return;
    }

    setIsLoading(true);
    setAiResponse(null);
    setHasSubmittedQuestion(true);

    try {
      let finalQuery = textQuery.trim();
      
      if (selectedQueryType === 'image' && selectedImages.length > 0) {
        finalQuery = `Please analyze these rural development images in detail. Identify:
- Community infrastructure and development needs
- Current living conditions and facilities
- Agricultural and livelihood opportunities
- Infrastructure gaps and challenges
- Social and economic indicators
- Specific development recommendations
- Community engagement opportunities

Provide detailed, actionable rural development advice for improving the conditions shown.`;
      } else if (selectedQueryType === 'combined' && selectedImages.length > 0) {
        finalQuery = `${finalQuery}

I have also uploaded ${selectedImages.length} supporting image(s) for analysis. Please:
1. Answer my specific question: "${textQuery}"
2. Analyze the uploaded images for additional context
3. Provide comprehensive rural development recommendations based on both the question and visual analysis
4. Give specific, actionable steps for community development

Please integrate both the text question and image analysis in your response.`;
      }

      // Ensure we have some query text for image-only analysis
      if (!finalQuery && selectedImages.length > 0) {
        finalQuery = "Please analyze these rural community images and provide expert development recommendations.";
      }

      console.log('Sending query to OpenAI:', {
        queryType: selectedQueryType,
        hasText: !!finalQuery,
        imageCount: selectedImages.length
      });

      const response = await openaiSystem.generateResponse(finalQuery, selectedImages);
      setAiResponse(response);

      // Only clear inputs on successful response from AI
      if (response.type === 'success') {
        setTextQuery('');
        setSelectedImages([]);
      }
    } catch (error) {
      console.error('Error generating response:', error);
      setAiResponse({
        content: `Error: Failed to get AI response. ${error.message || 'Please check your API key and internet connection.'}`,
        type: 'error',
        confidence: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetApiKey = () => {
    if (apiKey.trim()) {
      openaiSystem.setApiKey(apiKey.trim());
      setApiKey('');
      setShowApiKeyInput(false);
      setAiResponse({
        content: `API Key Set Successfully!

You can now ask rural development questions and get expert AI-powered responses.`,
        type: 'success',
        confidence: 1
      });
    }
  };

  const programs = [
    {
      icon: HandHeart,
      title: 'Community Welfare',
      description: 'Health, education and social welfare programs'
    },
    {
      icon: Briefcase,
      title: 'Livelihood Support',
      description: 'Income generation and employment opportunities'
    },
    {
      icon: Lightbulb,
      title: 'Innovation Hubs',
      description: 'Technology and innovation centers for rural areas'
    },
    {
      icon: MapPin,
      title: 'Geographical Planning',
      description: 'Spatial planning and resource mapping'
    }
  ];

  const impacts = [
    { label: 'Communities Served', value: '0', icon: Users },
    { label: 'Jobs Created', value: '0', icon: Briefcase },
    { label: 'Training Programs', value: '0', icon: GraduationCap },
    { label: 'Infrastructure Projects', value: '0', icon: Building }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-6 mb-16">
            <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-200">
              Rural Development Advisory
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Empowering Rural Communities
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Comprehensive rural development solutions focusing on community empowerment, infrastructure development, 
              capacity building, and sustainable livelihood enhancement for thriving rural economies.
            </p>
          </div>

          {/* Impact Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {impacts.map((impact, index) => (
              <Card key={index} className="text-center border-0 bg-white shadow-lg">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <impact.icon className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-2">{impact.value}</div>
                  <div className="text-sm text-gray-600">{impact.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* AI Query Interface */}
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-6 h-6 text-purple-600" />
                  Terra Tech Rural Development AI Assistant
                </CardTitle>
                <CardDescription>
                  Get expert guidance on community development, infrastructure, and rural programs
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Tabs value={selectedQueryType} onValueChange={(value) => {
                  setSelectedQueryType(value);
                  handleStartNewQuestion();
                }}>
                  <TabsList className="grid w-full grid-cols-3">
                    {queryTypes.map((type) => (
                      <TabsTrigger 
                        key={type.id} 
                        value={type.id}
                        className="flex items-center gap-2"
                      >
                        <type.icon className="w-4 h-4" />
                        {type.title}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  <TabsContent value="text" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Ask Your Rural Development Question</h3>
                      <Textarea
                        placeholder="e.g., How can we improve water access in our rural community of 500 people? What infrastructure development is most needed in our area?"
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[120px] resize-none"
                        rows={5}
                      />
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={!textQuery.trim() || isLoading}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Getting Development Strategy...' : 'Get Development Strategy'}
                    </Button>
                  </TabsContent>

                  <TabsContent value="image" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-3">Upload Your Community/Project Images</h3>
                      <div 
                        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-purple-500 bg-purple-50 scale-105' 
                            : 'border-purple-300 hover:border-purple-400 hover:bg-purple-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-4">
                          <div className="flex items-center space-x-4">
                            <Camera className="w-12 h-12 text-purple-500" />
                            <Upload className="w-12 h-12 text-purple-500" />
                            <ImageIcon className="w-12 h-12 text-purple-500" />
                          </div>
                          
                          <div className="space-y-2">
                            <p className="text-lg font-medium text-gray-800">
                              {dragActive ? 'Drop your images here!' : 'Upload your community/project images'}
                            </p>
                            <p className="text-sm text-gray-600">
                              Infrastructure, community areas, development projects, or challenges<br/>
                              Works with phone camera • Drag & drop • Browse files
                            </p>
                          </div>

                          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-xs text-purple-800 max-w-md">
                            <strong>Photography Tips for Best Results:</strong><br/>
                            • Clear shots of infrastructure and facilities<br/>
                            • Show community areas and living conditions<br/>
                            • Capture development challenges or needs<br/>
                            • Include context and scale references
                          </div>

                          <div className="flex flex-col sm:flex-row gap-3">
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="rural-image-upload"
                              capture="environment"
                            />
                            <label htmlFor="rural-image-upload">
                              <Button variant="outline" className="cursor-pointer border-purple-500 text-purple-700 hover:bg-purple-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take/Choose Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                            
                            <Button
                              variant="outline"
                              className="border-indigo-500 text-indigo-700 hover:bg-indigo-50"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              <Upload className="w-4 h-4 mr-2" />
                              Browse Files
                            </Button>
                          </div>

                          <p className="text-xs text-gray-500">
                            Max 4 images • 10MB each • JPG/PNG formats
                          </p>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-purple-800">Images Ready for AI Analysis:</h4>
                            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                              {selectedImages.length}/4 images
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {selectedImages.map((image, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={image.dataUrl}
                                  alt={image.name}
                                  className="w-full h-32 object-cover rounded-lg border-2 border-purple-200 shadow-sm"
                                />
                                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-all" />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  className="absolute -top-2 -right-2 w-7 h-7 p-0 rounded-full opacity-80 hover:opacity-100 shadow-lg"
                                  onClick={() => removeImage(index)}
                                  title="Remove this image"
                                >
                                  ×
                                </Button>
                                <div className="absolute bottom-1 left-1 right-1 bg-black bg-opacity-70 text-white text-xs p-1 rounded truncate">
                                  {image.name}
                                </div>
                                <div className="absolute top-1 left-1 bg-purple-500 text-white text-xs px-2 py-1 rounded">
                                  #{index + 1}
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm text-purple-800">
                            <strong>AI will analyze:</strong> Infrastructure needs, community development opportunities, resource gaps, development planning, and improvement recommendations.
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={selectedImages.length === 0 || isLoading}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Analyzing Community...' : 'Analyze Community Needs'}
                    </Button>
                  </TabsContent>

                  <TabsContent value="combined" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Describe Your Development Challenge</h3>
                      <Textarea
                        placeholder="Describe your community development challenge or project needs... e.g., Our rural community lacks clean water access and needs infrastructure development, as shown in the uploaded images."
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[100px] resize-none"
                        rows={4}
                      />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-3">Add Supporting Photos</h3>
                      <div 
                        className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-indigo-500 bg-indigo-50 scale-105' 
                            : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-3">
                          <div className="flex items-center space-x-3">
                            <Camera className="w-8 h-8 text-indigo-500" />
                            <Upload className="w-8 h-8 text-indigo-500" />
                          </div>
                          
                          <p className="text-gray-700 font-medium">
                            {dragActive ? 'Drop supporting images here!' : 'Add photos to help explain your challenge'}
                          </p>
                          <p className="text-xs text-gray-600 max-w-sm">
                            Upload images that show the development challenge you described above
                          </p>

                          <div className="flex gap-2">
                            <input
                              ref={combinedFileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="combined-rural-upload"
                              capture="environment"
                            />
                            <label htmlFor="combined-rural-upload">
                              <Button variant="outline" className="cursor-pointer border-indigo-500 text-indigo-700 hover:bg-indigo-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                          </div>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-indigo-800">Supporting Images:</h4>
                          <div className="grid grid-cols-3 gap-3">
                            {selectedImages.map((image, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={image.dataUrl}
                                  alt={image.name}
                                  className="w-full h-24 object-cover rounded-lg border-2 border-indigo-200"
                                />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  className="absolute -top-1 -right-1 w-6 h-6 p-0 rounded-full text-xs opacity-80 hover:opacity-100"
                                  onClick={() => removeImage(index)}
                                  title="Remove image"
                                >
                                  ×
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={(!textQuery.trim() && selectedImages.length === 0) || isLoading}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Getting Assessment...' : 'Get Comprehensive Assessment'}
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            {/* Photography Tips for Rural Development */}
            {(selectedQueryType === 'image' || selectedQueryType === 'combined') && (
            <Card className="border-0 bg-gradient-to-r from-purple-50 to-pink-50 mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-purple-800">
                  <Camera className="w-6 h-6" />
                  Photography Tips for Community Development Analysis
                </CardTitle>
                <CardDescription>
                  Follow these guidelines to get the most accurate development analysis from our AI vision system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-purple-600 font-bold text-sm">1</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Infrastructure Overview</h4>
                        <p className="text-sm text-gray-600">Capture wide shots of community infrastructure, roads, buildings, and facilities</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-purple-600 font-bold text-sm">2</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Living Conditions</h4>
                        <p className="text-sm text-gray-600">Show housing conditions, sanitation facilities, and community living spaces</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-purple-600 font-bold text-sm">3</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Development Needs</h4>
                        <p className="text-sm text-gray-600">Document areas that need improvement, missing infrastructure, or development gaps</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-pink-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-pink-600 font-bold text-sm">4</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Community Assets</h4>
                        <p className="text-sm text-gray-600">Include existing resources, community centers, markets, and successful projects</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-pink-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-pink-600 font-bold text-sm">5</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Geographic Context</h4>
                        <p className="text-sm text-gray-600">Show the broader area, terrain, natural resources, and geographic constraints</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-pink-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-pink-600 font-bold text-sm">6</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Population & Scale</h4>
                        <p className="text-sm text-gray-600">Include people and activities to show community size and usage patterns</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mt-0.5">
                      <span className="text-yellow-600 text-sm">💡</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-yellow-800 mb-1">Best Results:</h4>
                      <p className="text-sm text-yellow-700">
                        Upload 2-4 images showing both current conditions and development needs. 
                        This helps our AI provide comprehensive community development strategies, infrastructure planning, and implementation recommendations.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            )}

            {/* AI Response Display */}
            {aiResponse && (
              <div className="max-w-4xl mx-auto mt-6 mb-16">
                {/* Special handling for quota exceeded errors */}
                {aiResponse.type === 'error' && (
                  aiResponse.content.includes('temporarily limited') ||
                  aiResponse.content.includes('quota') ||
                  aiResponse.content.includes('Quota Exceeded')
                ) ? (
                  <QuotaExceededNotice 
                    context="rural-development"
                    onRetry={async () => {
                      setIsLoading(true);
                      try {
                        // Retry the last query
                        const response = await openaiSystem.generateResponse(textQuery, selectedImages);
                        setAiResponse(response);
                      } catch (error) {
                        console.error('Retry failed:', error);
                      } finally {
                        setIsLoading(false);
                      }
                    }}
                    isRetrying={isLoading}
                  />
                ) : (
                  <Card className="shadow-xl border-0">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        {aiResponse.type === 'success' && <CheckCircle className="w-6 h-6 text-green-600" />}
                        {aiResponse.type === 'error' && <XCircle className="w-6 h-6 text-red-600" />}
                        {aiResponse.type === 'suggestion' && <Key className="w-6 h-6 text-yellow-600" />}
                        {aiResponse.type === 'redirect' && <AlertTriangle className="w-6 h-6 text-orange-600" />}
                        AI Rural Development Advisor Response
                      </CardTitle>
                      <CardDescription>
                        {aiResponse.type === 'success' && 'Expert rural development guidance powered by OpenAI'}
                        {aiResponse.type === 'error' && 'There was an issue processing your request'}
                        {aiResponse.type === 'suggestion' && 'Setup required to continue'}
                        {aiResponse.type === 'redirect' && 'Query redirection recommended'}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div 
                        className="prose prose-sm max-w-none"
                        dangerouslySetInnerHTML={{ 
                          __html: formatResponse(aiResponse.content) 
                        }}
                      />
                      
                      {aiResponse.type === 'success' && (
                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center gap-2 text-sm text-green-700">
                            <CheckCircle className="w-4 h-4" />
                            <span>Confidence: {Math.round(aiResponse.confidence * 100)}%</span>
                            <span className="ml-auto">Powered by OpenAI GPT-4o Mini</span>
                          </div>
                        </div>
                      )}

                      {aiResponse.type === 'success' && (
                        <div className="mt-4 flex gap-2">
                          <Button 
                            onClick={() => setAiResponse(null)}
                            variant="outline"
                            size="sm"
                          >
                            Ask Another Question
                          </Button>
                          <Button 
                            onClick={() => {
                              setTextQuery('');
                              setSelectedImages([]);
                              setAiResponse(null);
                              setHasSubmittedQuestion(false);
                            }}
                            variant="outline"
                            size="sm"
                          >
                            Start Over
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Development Programs */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Development Programs
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Comprehensive programs designed to address specific rural development challenges and opportunities
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {programs.map((program, index) => (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow border-0 bg-white">
                  <CardHeader>
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <program.icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <CardTitle className="text-base">{program.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">{program.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Featured Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-900">
                Sustainable Community Development
              </h2>
              <p className="text-gray-600 leading-relaxed">
                Our approach to rural development focuses on community-driven initiatives that ensure long-term 
                sustainability and local ownership. We work with communities to identify their unique needs and 
                develop tailored solutions that leverage local resources and capabilities.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                    <Users className="w-4 h-4 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Community Participation</h3>
                    <p className="text-sm text-gray-600">Active involvement of community members in planning and implementation</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Economic Growth</h3>
                    <p className="text-sm text-gray-600">Sustainable income generation and livelihood enhancement</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                    <Heart className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Social Impact</h3>
                    <p className="text-sm text-gray-600">Improved quality of life and social cohesion in rural areas</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1756074870752-c75311dc0695?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXJhbCUyMGNvbW11bml0eSUyMGRldmVsb3BtZW50JTIwaW5mcmFzdHJ1Y3R1cmV8ZW58MXx8fHwxNzU3NTE0MTEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Rural Community Infrastructure"
                className="w-full h-64 object-cover rounded-xl shadow-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1745169921509-ceb2b517dd9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXJhbCUyMGxpdmVsaWhvb2QlMjBwcm9ncmFtcyUyMHRyYWluaW5nfGVufDF8fHx8MTc1NzUxNDExNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Rural Livelihood Training Programs"
                className="w-full h-64 object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Context-Aware ChatBot */}
      <ChatBot context="rural-development" />
    </div>
  );
}