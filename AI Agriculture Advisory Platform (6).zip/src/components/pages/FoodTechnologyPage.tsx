import React, { useState, useRef } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ChatBot } from '../ChatBot';
import { QuotaExceededNotice } from '../QuotaExceededNotice';
import { createOpenAI, formatResponse } from '../utils/openai-ai-system';
import { 
  FlaskConical, 
  Shield, 
  Package, 
  BarChart3, 
  Microscope,
  ThermometerSun,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Upload,
  Search,
  FileText,
  Loader,
  CheckCircle,
  XCircle,
  Key,
  Camera,
  ImageIcon
} from 'lucide-react';

export function FoodTechnologyPage() {
  const [selectedQueryType, setSelectedQueryType] = useState('text');
  const [textQuery, setTextQuery] = useState('');
  const [selectedImages, setSelectedImages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState(null);
  const [showApiKeyInput, setShowApiKeyInput] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [hasSubmittedQuestion, setHasSubmittedQuestion] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  
  // Initialize OpenAI system
  const [openaiSystem] = useState(() => createOpenAI('food-technology'));
  
  // Refs for file inputs
  const fileInputRef = useRef(null);
  const combinedFileInputRef = useRef(null);

  const services = [
    {
      icon: FlaskConical,
      title: 'Food Processing',
      description: 'Advanced processing techniques for enhanced nutrition and shelf life.',
      features: ['Processing Optimization', 'Nutritional Enhancement', 'Texture Analysis', 'Flavor Development'],
      color: 'bg-blue-500'
    },
    {
      icon: Shield,
      title: 'Food Safety & Quality',
      description: 'Comprehensive safety protocols and quality assurance systems.',
      features: ['HACCP Implementation', 'Contamination Testing', 'Safety Protocols', 'Quality Standards'],
      color: 'bg-red-500'
    },
    {
      icon: Package,
      title: 'Preservation & Packaging',
      description: 'Innovative preservation methods and smart packaging solutions.',
      features: ['Preservation Methods', 'Smart Packaging', 'Shelf Life Extension', 'Storage Solutions'],
      color: 'bg-green-500'
    },
    {
      icon: BarChart3,
      title: 'Nutritional Analysis',
      description: 'Detailed nutritional profiling and enhancement strategies.',
      features: ['Nutrient Profiling', 'Fortification', 'Bioavailability', 'Health Claims'],
      color: 'bg-purple-500'
    }
  ];

  const queryTypes = [
    {
      id: 'text',
      title: 'Text Query',
      description: 'Ask food technology questions',
      icon: FileText
    },
    {
      id: 'image',
      title: 'Product Analysis',
      description: 'Upload food product images',
      icon: Upload
    },
    {
      id: 'combined',
      title: 'Complete Analysis',
      description: 'Combine text with product images',
      icon: BarChart3
    }
  ];

  // Function to handle starting a new question
  const handleStartNewQuestion = () => {
    setHasSubmittedQuestion(false);
    setAiResponse(null);
  };

  const processFiles = (files) => {
    const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    // Limit to 4 images for performance
    if (selectedImages.length + imageFiles.length > 4) {
      alert('Maximum 4 images allowed for analysis. Please remove some images first.');
      return;
    }
    
    imageFiles.forEach(file => {
      // Check file size (max 10MB per image)
      if (file.size > 10 * 1024 * 1024) {
        alert(`Image "${file.name}" is too large. Maximum size is 10MB per image.

Tip: Try compressing the image or taking a new photo.`);
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = {
          file,
          dataUrl: e.target.result,
          name: file.name,
          size: file.size,
          type: file.type
        };
        setSelectedImages(prev => [...prev, imageData]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleImageUpload = (e) => {
    if (hasSubmittedQuestion) {
      handleStartNewQuestion();
    }
    processFiles(e.target.files);
    // Clear the input so the same file can be uploaded again
    e.target.value = '';
  };

  // Drag and drop handlers
  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(files);
    }
  };

  const removeImage = (index) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitQuery = async () => {
    if (!textQuery.trim() && selectedImages.length === 0) {
      alert('Please enter a question or upload images for analysis.');
      return;
    }

    setIsLoading(true);
    setAiResponse(null);
    setHasSubmittedQuestion(true);

    try {
      // Prepare query based on type
      let finalQuery = textQuery;
      
      if (selectedQueryType === 'image' && selectedImages.length > 0) {
        finalQuery = `I have uploaded ${selectedImages.length} food product image(s) for analysis. Please help me with food technology analysis, safety assessment, quality evaluation, or processing recommendations based on what you would expect to see in food product images.`;
      } else if (selectedQueryType === 'combined') {
        finalQuery = `${textQuery}\n\nI have also uploaded ${selectedImages.length} food product image(s) for better context.`;
      }

      // Get AI response
      const response = await openaiSystem.generateResponse(finalQuery, selectedImages);
      setAiResponse(response);

      // Reset form after successful submission
      if (response.type === 'success') {
        setTextQuery('');
        setSelectedImages([]);
      }
    } catch (error) {
      console.error('Error generating response:', error);
      setAiResponse({
        content: `⚠️ **Error**: Failed to get AI response. Please check your API key and internet connection.`,
        type: 'error',
        confidence: 0
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetApiKey = () => {
    if (apiKey.trim()) {
      openaiSystem.setApiKey(apiKey.trim());
      setApiKey('');
      setShowApiKeyInput(false);
      // Show success message
      setAiResponse({
        content: `✅ **API Key Set Successfully!**\n\nYou can now ask food technology questions and get expert AI-powered responses. Your API key is stored locally and secure.`,
        type: 'success',
        confidence: 1
      });
    }
  };

  const processes = [
    {
      icon: ThermometerSun,
      title: 'Thermal Processing',
      description: 'Heat treatment optimization for safety and quality'
    },
    {
      icon: Clock,
      title: 'Fermentation',
      description: 'Controlled fermentation for enhanced products'
    },
    {
      icon: Microscope,
      title: 'Microencapsulation',
      description: 'Advanced ingredient protection and delivery'
    },
    {
      icon: Package,
      title: 'Modified Atmosphere',
      description: 'Gas composition control for preservation'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center space-y-6 mb-16">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
              Food Technology Advisory
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900">
              Advanced Food Technology Solutions
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Get expert guidance on food processing, safety protocols, quality control, and innovative preservation techniques. 
              Our AI analyzes your food products and processes to provide optimized solutions.
            </p>
          </div>

          {/* AI Query Interface */}
          <div className="max-w-4xl mx-auto mb-16">
            <Card className="shadow-xl border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FlaskConical className="w-6 h-6 text-blue-600" />
                  Terra Tech Food Technology AI Assistant
                </CardTitle>
                <CardDescription>
                  Get expert advice on food processing, safety, and quality control
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Tabs value={selectedQueryType} onValueChange={(value) => {
                  setSelectedQueryType(value);
                  handleStartNewQuestion();
                }}>
                  <TabsList className="grid w-full grid-cols-3">
                    {queryTypes.map((type) => (
                      <TabsTrigger 
                        key={type.id} 
                        value={type.id}
                        className="flex items-center gap-2"
                      >
                        <type.icon className="w-4 h-4" />
                        {type.title}
                      </TabsTrigger>
                    ))}
                  </TabsList>

                  <TabsContent value="text" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Ask Your Food Technology Question</h3>
                      <Textarea
                        placeholder="e.g., How can I extend the shelf life of my dairy product without affecting taste? What processing methods would work best for my new sauce product?"
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[120px] resize-none"
                        rows={5}
                      />
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={!textQuery.trim() || isLoading}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Getting Expert Advice...' : 'Get Expert Advice'}
                    </Button>
                  </TabsContent>

                  <TabsContent value="image" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-3">Upload Your Food Product Images</h3>
                      <div 
                        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-blue-500 bg-blue-50 scale-105' 
                            : 'border-blue-300 hover:border-blue-400 hover:bg-blue-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-4">
                          <div className="flex items-center space-x-4">
                            <Camera className="w-12 h-12 text-blue-500" />
                            <Upload className="w-12 h-12 text-blue-500" />
                            <ImageIcon className="w-12 h-12 text-blue-500" />
                          </div>
                          
                          <div className="space-y-2">
                            <p className="text-lg font-medium text-gray-800">
                              {dragActive ? 'Drop your images here!' : 'Upload your food product images'}
                            </p>
                            <p className="text-sm text-gray-600">
                              Products, packaging, processing equipment, quality issues, or ingredients<br/>
                              Works with phone camera • Drag & drop • Browse files
                            </p>
                          </div>

                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-800 max-w-md">
                            <strong>Photography Tips for Best Results:</strong><br/>
                            • Clear, well-lit product photos<br/>
                            • Include labels and ingredients<br/>
                            • Show different angles and details<br/>
                            • Capture any quality concerns
                          </div>

                          <div className="flex flex-col sm:flex-row gap-3">
                            <input
                              ref={fileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="food-image-upload"
                              capture="environment"
                            />
                            <label htmlFor="food-image-upload">
                              <Button variant="outline" className="cursor-pointer border-blue-500 text-blue-700 hover:bg-blue-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take/Choose Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                            
                            <Button
                              variant="outline"
                              className="border-indigo-500 text-indigo-700 hover:bg-indigo-50"
                              onClick={() => fileInputRef.current?.click()}
                            >
                              <Upload className="w-4 h-4 mr-2" />
                              Browse Files
                            </Button>
                          </div>

                          <p className="text-xs text-gray-500">
                            Max 4 images • 10MB each • JPG/PNG formats
                          </p>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium text-blue-800">Images Ready for AI Analysis:</h4>
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              {selectedImages.length}/4 images
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            {selectedImages.map((image, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={image.dataUrl}
                                  alt={image.name}
                                  className="w-full h-32 object-cover rounded-lg border-2 border-blue-200 shadow-sm"
                                />
                                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-all" />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  className="absolute -top-2 -right-2 w-7 h-7 p-0 rounded-full opacity-80 hover:opacity-100 shadow-lg"
                                  onClick={() => removeImage(index)}
                                  title="Remove this image"
                                >
                                  ×
                                </Button>
                                <div className="absolute bottom-1 left-1 right-1 bg-black bg-opacity-70 text-white text-xs p-1 rounded truncate">
                                  {image.name}
                                </div>
                                <div className="absolute top-1 left-1 bg-blue-500 text-white text-xs px-2 py-1 rounded">
                                  #{index + 1}
                                </div>
                              </div>
                            ))}
                          </div>
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
                            <strong>AI will analyze:</strong> Food safety, quality assessment, processing recommendations, nutritional content, packaging evaluation, and improvement suggestions.
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={selectedImages.length === 0 || isLoading}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Analyzing Product...' : 'Analyze Product'}
                    </Button>
                  </TabsContent>

                  <TabsContent value="combined" className="space-y-4">
                    <div>
                      <h3 className="font-semibold mb-2">Describe Your Food Technology Challenge</h3>
                      <Textarea
                        placeholder="Describe your processing challenge or quality concern... e.g., I'm having issues with texture consistency in my product, as shown in the uploaded images."
                        value={textQuery}
                        onChange={(e) => {
                          setTextQuery(e.target.value);
                          if (hasSubmittedQuestion && e.target.value.trim()) {
                            handleStartNewQuestion();
                          }
                        }}
                        className="min-h-[100px] resize-none"
                        rows={4}
                      />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-3">Add Supporting Photos</h3>
                      <div 
                        className={`border-2 border-dashed rounded-lg p-6 text-center transition-all duration-200 ${
                          dragActive 
                            ? 'border-indigo-500 bg-indigo-50 scale-105' 
                            : 'border-indigo-300 hover:border-indigo-400 hover:bg-indigo-50'
                        }`}
                        onDragEnter={handleDragEnter}
                        onDragLeave={handleDragLeave}
                        onDragOver={handleDragOver}
                        onDrop={handleDrop}
                      >
                        <div className="flex flex-col items-center space-y-3">
                          <div className="flex items-center space-x-3">
                            <Camera className="w-8 h-8 text-indigo-500" />
                            <Upload className="w-8 h-8 text-indigo-500" />
                          </div>
                          
                          <p className="text-gray-700 font-medium">
                            {dragActive ? 'Drop supporting images here!' : 'Add photos to help explain your challenge'}
                          </p>
                          <p className="text-xs text-gray-600 max-w-sm">
                            Upload images that show the problem you described above
                          </p>

                          <div className="flex gap-2">
                            <input
                              ref={combinedFileInputRef}
                              type="file"
                              accept="image/jpeg,image/jpg,image/png,image/webp"
                              multiple
                              onChange={handleImageUpload}
                              className="hidden"
                              id="combined-food-upload"
                              capture="environment"
                            />
                            <label htmlFor="combined-food-upload">
                              <Button variant="outline" className="cursor-pointer border-indigo-500 text-indigo-700 hover:bg-indigo-50">
                                <Camera className="w-4 h-4 mr-2" />
                                Take Photos ({selectedImages.length}/4)
                              </Button>
                            </label>
                          </div>
                        </div>
                      </div>
                      {selectedImages.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-medium text-indigo-800">Supporting Images:</h4>
                          <div className="grid grid-cols-3 gap-3">
                            {selectedImages.map((image, index) => (
                              <div key={index} className="relative group">
                                <img
                                  src={image.dataUrl}
                                  alt={image.name}
                                  className="w-full h-24 object-cover rounded-lg border-2 border-indigo-200"
                                />
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  className="absolute -top-1 -right-1 w-6 h-6 p-0 rounded-full text-xs opacity-80 hover:opacity-100"
                                  onClick={() => removeImage(index)}
                                  title="Remove image"
                                >
                                  ×
                                </Button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <Button 
                      onClick={handleSubmitQuery}
                      disabled={(!textQuery.trim() && selectedImages.length === 0) || isLoading}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                    >
                      {isLoading ? (
                        <Loader className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Search className="w-4 h-4 mr-2" />
                      )}
                      {isLoading ? 'Getting Analysis...' : 'Get Complete Analysis'}
                    </Button>
                  </TabsContent>
                </Tabs>

                {/* API Key Setup */}
                {!openaiSystem.hasApiKey() && !showApiKeyInput && (
                  <div className="hidden mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Key className="w-5 h-5 text-yellow-600" />
                      <div className="flex-1">
                        <h4 className="font-semibold text-yellow-800">OpenAI API Key Required</h4>
                        <p className="text-sm text-yellow-700">Set your OpenAI API key to get AI-powered food technology advice</p>
                      </div>
                      <Button 
                        onClick={() => setShowApiKeyInput(true)}
                        variant="outline"
                        size="sm"
                        className="border-yellow-300 text-yellow-800 hover:bg-yellow-100"
                      >
                        <Key className="w-4 h-4 mr-2" />
                        Set API Key
                      </Button>
                    </div>
                  </div>
                )}

                {showApiKeyInput && (
                  <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-3">Enter Your OpenAI API Key</h4>
                    <div className="flex gap-3">
                      <Input
                        type="password"
                        placeholder="sk-..."
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        className="flex-1"
                      />
                      <Button 
                        onClick={handleSetApiKey}
                        disabled={!apiKey.trim()}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        Save
                      </Button>
                      <Button 
                        onClick={() => setShowApiKeyInput(false)}
                        variant="outline"
                      >
                        Cancel
                      </Button>
                    </div>
                    <p className="text-xs text-blue-600 mt-2">
                      Your API key is stored locally and never shared. Get your key from{' '}
                      <a href="https://platform.openai.com/" target="_blank" rel="noopener noreferrer" className="underline">
                        platform.openai.com
                      </a>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Photography Tips for Food Technology */}
            {((selectedQueryType === 'image' || selectedQueryType === 'combined') || hasSubmittedQuestion) && (
            <Card className="border-0 bg-gradient-to-r from-blue-50 to-indigo-50 mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                  <Camera className="w-6 h-6" />
                  Photography Tips for Food Product Analysis
                </CardTitle>
                <CardDescription>
                  Follow these guidelines to get the most accurate analysis from our AI vision system
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">1</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Good Lighting & Focus</h4>
                        <p className="text-sm text-gray-600">Use natural light when possible, ensure products are clearly focused and well-lit</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">2</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Product Details</h4>
                        <p className="text-sm text-gray-600">Capture close-ups of textures, colors, packaging, and any visible defects or issues</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-blue-600 font-bold text-sm">3</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Multiple Angles</h4>
                        <p className="text-sm text-gray-600">Show different perspectives - front, back, sides, and cross-sections if applicable</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-indigo-600 font-bold text-sm">4</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Context & Scale</h4>
                        <p className="text-sm text-gray-600">Include size references and show the processing environment or packaging context</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-indigo-600 font-bold text-sm">5</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Labels & Ingredients</h4>
                        <p className="text-sm text-gray-600">Capture ingredient lists, nutritional labels, and processing information when relevant</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mt-1">
                        <span className="text-indigo-600 font-bold text-sm">6</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">Quality Issues</h4>
                        <p className="text-sm text-gray-600">Highlight any contamination, discoloration, texture problems, or safety concerns</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-yellow-100 rounded-full flex items-center justify-center mt-0.5">
                      <span className="text-yellow-600 text-sm">💡</span>
                    </div>
                    <div>
                      <h4 className="font-semibold text-yellow-800 mb-1">Best Results:</h4>
                      <p className="text-sm text-yellow-700">
                        Upload 2-4 images showing different aspects of your food product or processing challenge. 
                        This helps our AI provide comprehensive analysis covering safety, quality, processing, and improvement recommendations.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            )}

            {/* AI Response Display */}
            {aiResponse && (
              <div className="mt-6">
                {/* Special handling for quota exceeded errors */}
                {aiResponse.type === 'error' && (
                  aiResponse.content.includes('temporarily limited') ||
                  aiResponse.content.includes('quota') ||
                  aiResponse.content.includes('Quota Exceeded')
                ) ? (
                  <QuotaExceededNotice 
                    context="food-technology"
                    onRetry={async () => {
                      setIsLoading(true);
                      try {
                        // Retry the last query
                        const response = await openaiSystem.generateResponse(textQuery, selectedImages);
                        setAiResponse(response);
                      } catch (error) {
                        console.error('Retry failed:', error);
                      } finally {
                        setIsLoading(false);
                      }
                    }}
                    isRetrying={isLoading}
                  />
                ) : (
                  <Card className="shadow-xl border-0">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        {aiResponse.type === 'success' && <CheckCircle className="w-6 h-6 text-green-600" />}
                        {aiResponse.type === 'error' && <XCircle className="w-6 h-6 text-red-600" />}
                        {aiResponse.type === 'suggestion' && <Key className="w-6 h-6 text-yellow-600" />}
                        {aiResponse.type === 'redirect' && <AlertTriangle className="w-6 h-6 text-orange-600" />}
                        AI Food Technology Advisor Response
                      </CardTitle>
                      <CardDescription>
                        {aiResponse.type === 'success' && 'Expert food technology guidance powered by OpenAI'}
                        {aiResponse.type === 'error' && 'There was an issue processing your request'}
                        {aiResponse.type === 'suggestion' && 'Setup required to continue'}
                        {aiResponse.type === 'redirect' && 'Query redirection recommended'}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div 
                        className="prose prose-sm max-w-none"
                        dangerouslySetInnerHTML={{ 
                          __html: formatResponse(aiResponse.content) 
                        }}
                      />
                      
                      {aiResponse.type === 'success' && (
                        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                          <div className="flex items-center gap-2 text-sm text-green-700">
                            <CheckCircle className="w-4 h-4" />
                            <span>Confidence: {Math.round(aiResponse.confidence * 100)}%</span>
                            <span className="ml-auto">Powered by OpenAI GPT-4o Mini</span>
                          </div>
                        </div>
                      )}

                      {aiResponse.type === 'success' && (
                        <div className="mt-4 flex gap-2">
                          <Button 
                            onClick={() => setAiResponse(null)}
                            variant="outline"
                            size="sm"
                          >
                            Ask Another Question
                          </Button>
                          <Button 
                            onClick={() => {
                              setTextQuery('');
                              setSelectedImages([]);
                              setAiResponse(null);
                              setHasSubmittedQuestion(false);
                            }}
                            variant="outline"
                            size="sm"
                          >
                            Start Over
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {services.map((service, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription className="text-sm">{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Processing Technologies */}
          <div className="mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Advanced Processing Technologies
              </h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Explore cutting-edge food processing technologies that enhance quality, safety, and nutritional value
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {processes.map((process, index) => (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow border-0 bg-white">
                  <CardHeader>
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                      <process.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <CardTitle className="text-base">{process.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600">{process.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Featured Content */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-900">
                Food Safety & Quality Assurance
              </h2>
              <p className="text-gray-600 leading-relaxed">
                Ensure the highest standards of food safety and quality with our comprehensive 
                analysis and monitoring systems. From HACCP implementation to contamination detection, 
                we provide end-to-end solutions for food manufacturers.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center mt-1">
                    <Shield className="w-4 h-4 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">HACCP Compliance</h3>
                    <p className="text-sm text-gray-600">Implement and maintain hazard analysis critical control points</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Quality Standards</h3>
                    <p className="text-sm text-gray-600">Meet international food quality and safety standards</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center mt-1">
                    <AlertTriangle className="w-4 h-4 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">Risk Assessment</h3>
                    <p className="text-sm text-gray-600">Proactive identification and mitigation of food safety risks</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1615690055356-14dc400892d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwcHJvY2Vzc2luZyUyMHRlY2hub2xvZ3klMjBsYWJvcmF0b3J5fGVufDF8fHx8MTc1NzUxNDA0Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Food Processing Laboratory"
                className="w-full h-64 object-cover rounded-xl shadow-lg"
              />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1678080830992-867249185447?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmb29kJTIwc2FmZXR5JTIwcXVhbGl0eSUyMGNvbnRyb2x8ZW58MXx8fHwxNzU3NTE0MDUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Food Safety Quality Control"
                className="w-full h-64 object-cover rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Context-Aware ChatBot */}
      <ChatBot context="food-technology" />
    </div>
  );
}