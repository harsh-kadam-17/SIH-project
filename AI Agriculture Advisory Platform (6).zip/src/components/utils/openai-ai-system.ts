import { getOpenAIApiKey, isApiKeyConfigured, TERRA_TECH_CONFIG } from './central-api-config';

export interface OpenAIResponse {
  content: string;
  type: 'success' | 'suggestion' | 'redirect' | 'error';
  confidence: number;
}

export interface OpenAIMessage {
  id: number;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

class OpenAISystem {
  private domain: 'agriculture' | 'food-technology' | 'rural-development';
  private conversationHistory: Array<{ role: 'user' | 'assistant'; content: string }> = [];

  constructor(domain: 'agriculture' | 'food-technology' | 'rural-development') {
    this.domain = domain;
  }

  // Central API key management - no more user-provided keys
  hasApiKey(): boolean {
    return isApiKeyConfigured();
  }

  private getApiKey(): string {
    return getOpenAIApiKey();
  }

  async generateResponse(query: string, images?: any[]): Promise<OpenAIResponse> {
    // Handle empty query (welcome message)
    if (!query.trim()) {
      return this.getWelcomeMessage();
    }

    // Check if Terra Tech API key is configured
    if (!this.hasApiKey()) {
      return {
        content: `⚙️ **Terra Tech AI Service Unavailable**

The Terra Tech AI assistance service is currently being configured.

**What this means:**
• Our team is setting up the AI infrastructure
• This is a one-time configuration process
• No action required from you

**Please try again in a few minutes, or contact Terra Tech support if this issue persists.**

🌱 **In the meantime, you can:**
• Browse our resource library
• View agricultural best practices
• Access our knowledge base
• Contact our human experts`,
        type: 'suggestion',
        confidence: 0.9
      };
    }

    try {
      // Check if query is relevant to the domain
      const relevanceCheck = this.checkDomainRelevance(query);
      if (!relevanceCheck.isRelevant) {
        return {
          content: `🤔 **That seems to be about ${relevanceCheck.detectedTopic}**

I'm Terra Tech's **${this.getDomainName()}** specialist. I focus on ${this.getDomainDescription()}.

**For ${this.getDomainName()} questions, try asking:**
${this.getSampleQuestions().map(q => `• ${q}`).join('\n')}

**Or redirect your question to the relevant specialist:**
${relevanceCheck.detectedTopic === 'Food Technology' ? '• Visit the Food Technology page' : ''}
${relevanceCheck.detectedTopic === 'Rural Development' ? '• Visit the Rural Development page' : ''}
${relevanceCheck.detectedTopic === 'Agriculture' ? '• Visit the Agriculture page' : ''}`,
          type: 'redirect',
          confidence: 0.8
        };
      }

      // Prepare system prompt based on domain
      const systemPrompt = this.getSystemPrompt();

      // Prepare messages for OpenAI API - handle both text and image queries
      let messages: any[];
      let model: string;

      if (images && images.length > 0) {
        // Use Vision API for image analysis
        model = TERRA_TECH_CONFIG.OPENAI_MODELS.vision;
        
        try {
          console.log(`Processing ${images.length} images for vision analysis...`);
          const imageMessages = [];
          
          for (let i = 0; i < images.length; i++) {
            const image = images[i];
            console.log(`Processing image ${i + 1}:`, {
              name: image.name,
              type: image.type,
              size: image.size,
              hasDataUrl: !!image.dataUrl
            });
            
            // Ensure we have a valid dataUrl
            if (image.dataUrl && typeof image.dataUrl === 'string') {
              // Validate that the dataUrl is properly formatted
              if (image.dataUrl.startsWith('data:image/')) {
                imageMessages.push({
                  type: "image_url",
                  image_url: {
                    url: image.dataUrl,
                    detail: "high"
                  }
                });
                console.log(`✓ Image ${i + 1} processed successfully for OpenAI Vision API`);
              } else {
                console.warn(`⚠ Image ${i + 1} has invalid dataUrl format:`, image.dataUrl.substring(0, 50));
              }
            } else {
              console.warn(`⚠ Image ${i + 1} missing dataUrl:`, image);
            }
          }

          if (imageMessages.length === 0) {
            throw new Error('No valid images could be processed for analysis');
          }

          console.log(`✓ Successfully prepared ${imageMessages.length} images for OpenAI Vision API`);

          // Create the user message with text and images
          const userContent = [
            { type: "text", text: query }
          ];

          // Add all image messages
          userContent.push(...imageMessages);

          messages = [
            { 
              role: 'system' as const, 
              content: systemPrompt + `\n\nIMPORTANT: You are now analyzing ${imageMessages.length} agricultural image(s). Provide detailed, expert analysis of what you see in each image, including identification of crops, diseases, pests, soil conditions, or any agricultural issues. Be specific about problems and provide actionable solutions. Reference specific images when providing analysis.`
            },
            ...this.conversationHistory.slice(-4), // Keep fewer messages for vision queries to save tokens
            { 
              role: 'user' as const, 
              content: userContent
            }
          ];

          console.log(`✓ Vision analysis request prepared with ${imageMessages.length} images`);
        } catch (imageError) {
          console.error('❌ Error processing images for vision analysis:', imageError);
          // Fallback to text-only if image processing fails
          model = TERRA_TECH_CONFIG.OPENAI_MODELS.text;
          messages = [
            { role: 'system' as const, content: systemPrompt },
            ...this.conversationHistory.slice(-10),
            { role: 'user' as const, content: `${query}\n\n[Note: ${images.length} image(s) were uploaded but could not be processed for vision analysis. Error: ${imageError.message}. Please provide general advice based on the text description.]` }
          ];
          console.log('🔄 Falling back to text-only analysis due to image processing error');
        }
      } else {
        // Standard text-only query
        model = TERRA_TECH_CONFIG.OPENAI_MODELS.text;
        messages = [
          { role: 'system' as const, content: systemPrompt },
          ...this.conversationHistory.slice(-10), // Keep last 10 messages for context
          { role: 'user' as const, content: query }
        ];
      }

      // Prepare API request payload
      const requestPayload = {
        model: model,
        messages: messages,
        max_tokens: images && images.length > 0 ? TERRA_TECH_CONFIG.MAX_TOKENS.vision : TERRA_TECH_CONFIG.MAX_TOKENS.text,
        temperature: TERRA_TECH_CONFIG.TEMPERATURE,
        presence_penalty: 0.1,
        frequency_penalty: 0.1
      };

      console.log('OpenAI API Request:', {
        model: requestPayload.model,
        messageCount: messages.length,
        hasImages: images && images.length > 0,
        imageCount: images?.length || 0
      });

      // Call OpenAI API with Terra Tech's central API key
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.getApiKey()}`
        },
        body: JSON.stringify(requestPayload)
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('OpenAI API Error Response:', response.status, errorData);
        
        if (response.status === 401) {
          return {
            content: `�� **Terra Tech API Authentication Error**

There's an issue with Terra Tech's AI service authentication.

**This is a system-level issue that our team needs to resolve.**

**Please:**
1. Try again in a few minutes
2. Contact Terra Tech support if the issue persists
3. Reference error code: AUTH_401

**Error details:** ${errorData.error?.message || 'Authentication failed'}`,
            type: 'error',
            confidence: 0
          };
        }

        if (response.status === 429) {
          // Handle quota exceeded with specific messaging for centralized API
          const errorData = await response.json().catch(() => ({}));
          const isQuotaExceeded = errorData.error?.code === 'insufficient_quota';
          
          if (isQuotaExceeded) {
            return {
              content: `🚫 **Terra Tech AI Service Temporarily Limited**

Our centralized AI service has reached its daily usage quota.

**📊 Current Status:**
• AI Vision Analysis: Temporarily unavailable
• Expert AI Responses: Temporarily unavailable  
• Platform Access: Fully functional
• Resources & Guides: Available

**⏰ Service Recovery:**
• Quota resets automatically within 24 hours
• No action required from you
• Full service will resume automatically

**🔄 What You Can Do Now:**
1. **Try again later** - Our quota resets automatically
2. **Browse our extensive resource library** for immediate guidance
3. **Contact our human experts** for urgent questions
4. **Submit questions via email** for detailed responses

**💡 For Immediate Help:**
Visit our Resources section for comprehensive guides on ${this.getDomainName().toLowerCase()}, or contact Terra Tech support for urgent assistance.

**Technical Details:** Terra Tech's centralized OpenAI API key has exceeded quota limits. This is a temporary system limitation that will resolve automatically.`,
              type: 'error',
              confidence: 0
            };
          } else {
            return {
              content: `⏱️ **Rate Limit Reached**

Terra Tech's AI service is experiencing high demand.

**Please:**
1. Wait a few minutes before trying again
2. Try your question again shortly
3. Contact Terra Tech support if this persists

**🔄 Automatic Recovery:** 
Our systems will automatically resume normal operation within minutes.`,
              type: 'suggestion',
              confidence: 0.6
            };
          }
        }

        if (response.status === 400) {
          const isImageError = images && images.length > 0;
          return {
            content: `⚠️ **${isImageError ? 'Image Analysis' : 'Request'} Error**

There was an issue with your ${isImageError ? 'image analysis' : ''} request.

**Possible causes:**
${isImageError ? '• Image file too large (OpenAI limit: 20MB per image)\n• Unsupported image format (OpenAI supports: JPG, PNG, GIF, WebP)\n• Corrupted or invalid image data\n• Too many images in a single request' : '• Invalid request format\n• Content policy violation\n• Request too large'}

**Please try:**
${isImageError ? '• Using smaller image files (recommended: under 5MB each)\n• Converting to JPG or PNG format\n• Uploading fewer images at once (max 4)\n• Taking clearer, well-lit photos\n• Ensuring images show agricultural content clearly' : '• Simplifying your request\n• Using different wording\n• Trying again in a moment'}

**Technical details:** ${errorData.error?.message || 'Bad request'}
**Request info:** ${isImageError ? `${images.length} images, model: ${model}` : `Text-only, model: ${model}`}`,
            type: 'error',
            confidence: 0
          };
        }

        throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      console.log('✅ OpenAI API Response received:', {
        choices: data.choices?.length || 0,
        usage: data.usage,
        model: data.model,
        hasImages: images && images.length > 0
      });

      const aiContent = data.choices[0]?.message?.content || 'Sorry, I could not generate a response.';

      if (!aiContent || aiContent.trim().length === 0) {
        console.error('❌ Empty response from OpenAI API');
        return {
          content: `⚠️ **Empty Response Received**\n\nThe AI service returned an empty response. This may be due to:\n• Image processing issues\n• Content filtering\n• API rate limits\n\nPlease try again with different images or contact Terra Tech support.`,
          type: 'error',
          confidence: 0
        };
      }

      // Add to conversation history (simplified for vision queries)
      this.conversationHistory.push(
        { role: 'user', content: images && images.length > 0 ? `${query} [${images.length} image(s) analyzed]` : query },
        { role: 'assistant', content: aiContent }
      );

      // Add image analysis footer if images were processed
      let finalContent = aiContent;
      if (images && images.length > 0) {
        const modelUsed = data.model || model;
        finalContent += `\n\n🔍 **AI Vision Analysis Complete**\n✅ Successfully analyzed ${images.length} agricultural image${images.length !== 1 ? 's' : ''} using ${modelUsed}\n📊 Token usage: ${data.usage?.total_tokens || 'N/A'} tokens`;
        console.log(`✅ Vision analysis completed successfully for ${images.length} images`);
      }

      return {
        content: finalContent,
        type: 'success',
        confidence: 0.95
      };

    } catch (error) {
      const hasImages = images && images.length > 0;
      console.error(`❌ OpenAI API Error (${hasImages ? 'Vision' : 'Text'} Analysis):`, error);
      
      return {
        content: `⚠️ **${hasImages ? 'Vision Analysis ' : ''}Connection Error**

I'm having trouble connecting to OpenAI's ${hasImages ? 'Vision API' : 'services'} right now.

**Possible causes:**
• Network connectivity issues
• OpenAI service temporarily unavailable
• API quota exceeded
${hasImages ? '• Image processing timeout\n• Vision API temporary issues' : ''}

**Please try:**
• Checking your internet connection
• Waiting a moment and trying again
• Terra Tech's API service may be temporarily limited
${hasImages ? '• Try with fewer or smaller images\n• Ensure images are clear and properly formatted' : ''}

**What happened:** ${hasImages ? `Failed to process ${images.length} image(s) for vision analysis` : 'Text analysis failed'}
**Technical error:** ${error instanceof Error ? error.message : 'Unknown error'}

**💡 Alternative:** Try asking your question in text format or contact Terra Tech support for assistance.`,
        type: 'error',
        confidence: 0
      };
    }
  }

  private getWelcomeMessage(): OpenAIResponse {
    const domainInfo = {
      'agriculture': {
        name: 'Agriculture',
        icon: '🌱',
        description: 'I\'m your comprehensive farming expert, ready to help with everything from backyard gardens to large-scale operations. I provide practical, actionable advice for all your agricultural needs.'
      },
      'food-technology': {
        name: 'Food Technology',
        icon: '🧪',
        description: 'I help with food processing, preservation, packaging, safety protocols, and quality control systems.'
      },
      'rural-development': {
        name: 'Rural Development',
        icon: '🏘️',
        description: 'I assist with infrastructure development, community projects, and rural economic growth strategies.'
      }
    };

    const info = domainInfo[this.domain];

    if (this.domain === 'agriculture') {
      return {
        content: `👋 **Welcome to Terra Tech Agriculture AI Assistant!**

${info.icon} ${info.description}

**🚀 Powered by OpenAI GPT-4 with Vision Analysis**
• Expert knowledge across ALL aspects of farming
• Image analysis for plant problems, diseases, and pests
• Detailed, step-by-step solutions
• Latest research and best practices
• Beginner-friendly to advanced guidance

**🌾 I can help with ANYTHING agriculture-related:**
• **Crops:** All vegetables, fruits, grains, herbs, flowers
• **Soil:** Testing, fertility, composting, pH, nutrients
• **Pests & Diseases:** Identification, organic & chemical control
• **Water:** Irrigation systems, drainage, conservation
• **Livestock:** Cattle, poultry, sheep, goats, pigs, and more
• **Growing Methods:** Organic, conventional, hydroponic, greenhouse
• **Equipment:** Tools, machinery, technology recommendations
• **Timing:** Planting, harvesting, seasonal care
• **Problem Solving:** Plant symptoms, troubleshooting issues

**📸 Upload Images For:**
• Disease and pest identification
• Plant problem diagnosis
• Soil condition assessment
• Growth stage evaluation
• Equipment and facility advice

**💬 Popular Questions:**
${this.getSampleQuestions().slice(0, 6).map(q => `• ${q}`).join('\n')}

**🌟 From hobby gardeners to commercial farmers - I'm here to help!**
Ask me anything about growing plants, raising animals, or farming operations. No question is too basic or too advanced! 🚜`,
        type: 'suggestion',
        confidence: 0.9
      };
    }

    return {
      content: `👋 **Welcome to Terra Tech ${info.name} AI Assistant!**

${info.icon} ${info.description}

**🚀 Powered by OpenAI GPT-4**
• Real-time expert knowledge
• Detailed, specific solutions
• Context-aware responses
• Latest research & best practices

**💡 Ask me anything about ${info.name.toLowerCase()}:**
${this.getSampleQuestions().map(q => `• ${q}`).join('\n')}

**🔍 I can help with:**
• Step-by-step problem solving
• Best practices and recommendations
• Troubleshooting specific issues
• Research-backed solutions

Just ask your question and I'll provide detailed, expert guidance!`,
      type: 'suggestion',
      confidence: 0.9
    };
  }

  private getSystemPrompt(): string {
    let basePrompt;
    
    if (this.domain === 'agriculture') {
      basePrompt = `You are Terra Tech's comprehensive Agriculture AI Expert - a friendly, knowledgeable farming consultant who helps everyone from beginner gardeners to professional farmers. You provide detailed, practical, and actionable advice for ALL aspects of agriculture, farming, gardening, and plant/animal care.

CORE PRINCIPLES:
1. Be EXTREMELY HELPFUL and answer ANY agriculture-related question
2. Provide SPECIFIC, ACTIONABLE solutions with exact details
3. Use clear, farmer-friendly language while maintaining accuracy
4. Give step-by-step instructions when appropriate
5. Include timing, quantities, methods, and product recommendations
6. Explain WHY something works (science-based reasoning)
7. Offer multiple solutions when possible (organic vs. conventional)
8. Be encouraging and supportive of all farming efforts
9. Consider different scales (hobby garden to commercial farm)
10. Address safety and environmental considerations

YOUR EXPERTISE COVERS EVERYTHING AGRICULTURAL:
- Any plant: vegetables, fruits, grains, herbs, flowers, trees, houseplants
- Any animal: livestock, poultry, bees, fish, pets on farms
- Any farming method: organic, conventional, hydroponic, greenhouse, permaculture
- Any scale: container gardens, backyard plots, small farms, large operations
- Any problem: diseases, pests, nutrients, water, soil, timing, equipment

RESPONSE FORMAT:
- Use clear headings and bullet points
- Provide multiple solutions when appropriate
- Include specific timing and quantities
- Add safety warnings when relevant
- Be encouraging and positive
- End with follow-up suggestions or monitoring advice

Remember: No agricultural question is too basic or too advanced. Help everyone succeed in growing food and raising animals!`;
    } else {
      basePrompt = `You are Terra Tech's expert AI assistant specializing in ${this.getDomainName()}. You provide detailed, practical, and actionable advice based on current best practices and scientific research.

IMPORTANT GUIDELINES:
1. Always provide SPECIFIC, ACTIONABLE solutions
2. Use clear step-by-step instructions when appropriate
3. Include relevant details like timing, quantities, and methods
4. Cite best practices and explain WHY something works
5. Format responses with clear headings and bullet points
6. Be encouraging and supportive
7. If asked about topics outside your domain, politely redirect

Your responses should be:
- Detailed and comprehensive
- Practical and implementable
- Based on proven methods
- Easy to understand and follow
- Professional yet friendly`;
    }

    const domainSpecific = {
      'agriculture': `

AGRICULTURE SPECIALIZATION - COMPREHENSIVE FARMING EXPERT:
You are an expert agricultural consultant with deep knowledge across ALL aspects of farming, gardening, and plant/animal agriculture. You help farmers, gardeners, hobbyists, and anyone interested in growing plants or raising animals.

CORE EXPERTISE AREAS:
🌱 CROP PRODUCTION & MANAGEMENT
- All crop types: vegetables, fruits, grains, legumes, herbs, flowers
- Seed selection, planting techniques, spacing, companion planting
- Growth monitoring, pruning, training, support systems
- Harvest timing, techniques, and post-harvest handling
- Crop rotation, succession planting, intercropping strategies

🌍 SOIL HEALTH & FERTILITY MANAGEMENT
- Soil testing interpretation and recommendations
- Nutrient management (N-P-K and micronutrients)
- Organic matter improvement, composting, cover crops
- pH adjustment, lime and sulfur applications
- Soil structure improvement, drainage, compaction issues
- Living soil biology, beneficial microorganisms

🐛 INTEGRATED PEST & DISEASE MANAGEMENT
- Comprehensive pest identification (insects, mites, nematodes)
- Disease diagnosis (fungal, bacterial, viral)
- Natural and organic control methods
- Chemical control when necessary (safe application)
- Prevention strategies and cultural controls
- Beneficial insect conservation and introduction

💧 WATER & IRRIGATION MANAGEMENT
- Irrigation system design and selection
- Water scheduling based on crop needs and weather
- Drought management and water conservation
- Drainage solutions for waterlogged conditions
- Mulching strategies for moisture retention
- Rainwater harvesting and water quality

🐄 LIVESTOCK & ANIMAL HUSBANDRY
- Cattle, sheep, goats, pigs, poultry management
- Animal nutrition, feeding programs, pasture management
- Health care, vaccination schedules, disease prevention
- Breeding programs, genetics, record keeping
- Housing, facility design, animal welfare
- Manure management and utilization

🌿 SUSTAINABLE & ORGANIC PRACTICES
- Organic certification requirements and practices
- Permaculture design principles
- Regenerative agriculture techniques
- Biodiversity enhancement, wildlife habitat
- Carbon sequestration and climate-smart practices
- Integrated farming systems

🔬 ADVANCED AGRICULTURAL TECHNOLOGIES
- Precision agriculture tools and GPS guidance
- Soil sensors, weather stations, monitoring systems
- Greenhouse and controlled environment growing
- Hydroponics, aquaponics, vertical farming
- Drone applications for crop monitoring
- Smart irrigation and fertigation systems

EXPERT IMAGE ANALYSIS CAPABILITIES:
When analyzing agricultural images, provide comprehensive analysis including:
- DETAILED CROP IDENTIFICATION with specific varieties when possible
- GROWTH STAGE ASSESSMENT with development timeline
- DISEASE SYMPTOMS with specific pathogen identification and treatment
- PEST IDENTIFICATION with species-level accuracy and control recommendations
- SOIL CONDITION EVALUATION from visual indicators
- NUTRIENT DEFICIENCY DIAGNOSIS from leaf symptoms with correction plans
- PLANT STRESS INDICATORS (water, temperature, light, nutrient stress)
- WEED IDENTIFICATION and management strategies
- EQUIPMENT AND FACILITY ASSESSMENT with improvement suggestions
- RECOMMENDED TREATMENTS with specific products, rates, and timing
- FOLLOW-UP ACTION PLANS with monitoring schedules

RESPONSE APPROACH:
- Always provide PRACTICAL, ACTIONABLE advice
- Include specific timing, quantities, methods, and products when relevant
- Explain the WHY behind recommendations (science-based reasoning)
- Offer multiple solutions when appropriate (organic vs. conventional)
- Consider regional variations, climate, and local conditions
- Provide step-by-step instructions for complex procedures
- Include safety precautions for chemical applications
- Suggest monitoring and follow-up actions
- Be encouraging and supportive of farming efforts
- Use clear, farmer-friendly language while maintaining technical accuracy

Remember: Agriculture encompasses everything from backyard gardens to large commercial operations, from houseplants to field crops, from hobby farming to professional agriculture. Help with ANY plant or animal-related question, no matter how basic or advanced.`,

      'food-technology': `

FOOD TECHNOLOGY SPECIALIZATION:
- Food processing and preservation
- Food safety and HACCP systems
- Packaging technologies and materials
- Quality control and testing
- Nutritional analysis
- Food microbiology
- Equipment and machinery
- Regulatory compliance

Provide specific advice for:
- Processing techniques and parameters
- Safety protocols and procedures
- Packaging selection and optimization
- Quality testing methods
- Preservation technologies
- Equipment recommendations
- Regulatory requirements
- Troubleshooting processing issues`,

      'rural-development': `

RURAL DEVELOPMENT SPECIALIZATION:
- Infrastructure development projects
- Community-based initiatives
- Water and sanitation systems
- Rural electrification
- Agricultural cooperatives
- Microfinance and economic development
- Capacity building programs
- Sustainable development practices

Provide specific advice for:
- Project planning and implementation
- Community engagement strategies
- Infrastructure design and technology
- Funding sources and grant writing
- Cooperative formation and management
- Economic development initiatives
- Sustainability planning
- Stakeholder coordination`
    };

    return basePrompt + domainSpecific[this.domain];
  }

  private checkDomainRelevance(query: string): { isRelevant: boolean; detectedTopic?: string } {
    const lowerQuery = query.toLowerCase();

    if (this.domain === 'agriculture') {
      // Extremely permissive for agriculture - include almost anything related to farming, gardening, plants, animals, land use, etc.
      const agricultureKeywords = [
        // Core farming terms
        'farm', 'farming', 'farmer', 'agriculture', 'agricultural', 'agro', 'crop', 'crops', 'plant', 'plants', 'planting',
        'grow', 'growing', 'growth', 'soil', 'earth', 'dirt', 'land', 'field', 'fields', 'seed', 'seeds', 'seeding',
        'harvest', 'harvesting', 'garden', 'gardening', 'greenhouse', 'nursery', 'orchard', 'vineyard',
        
        // Plant types and produce
        'vegetable', 'vegetables', 'fruit', 'fruits', 'grain', 'grains', 'cereal', 'cereals', 'corn', 'wheat', 'rice',
        'barley', 'oats', 'sorghum', 'millet', 'beans', 'peas', 'lentils', 'chickpeas', 'soybean', 'soybeans',
        'tomato', 'tomatoes', 'potato', 'potatoes', 'carrot', 'carrots', 'onion', 'onions', 'lettuce', 'spinach',
        'cabbage', 'broccoli', 'cauliflower', 'pepper', 'peppers', 'cucumber', 'pumpkin', 'squash', 'melon',
        'apple', 'apples', 'orange', 'oranges', 'banana', 'grapes', 'strawberry', 'strawberries', 'berry', 'berries',
        
        // Livestock and animals
        'livestock', 'cattle', 'cow', 'cows', 'bull', 'bulls', 'beef', 'dairy', 'milk', 'milking', 'chicken', 'chickens',
        'poultry', 'hen', 'hens', 'rooster', 'roosters', 'egg', 'eggs', 'pig', 'pigs', 'swine', 'pork', 'sheep',
        'lamb', 'goat', 'goats', 'horse', 'horses', 'donkey', 'duck', 'ducks', 'goose', 'geese', 'turkey', 'turkeys',
        'rabbit', 'rabbits', 'fish', 'aquaculture', 'bee', 'bees', 'beekeeping', 'honey', 'hive',
        
        // Farming practices and techniques
        'organic', 'sustainable', 'permaculture', 'biodynamic', 'regenerative', 'conventional', 'traditional',
        'modern', 'precision', 'smart', 'hydroponic', 'hydroponics', 'aeroponic', 'vertical', 'indoor',
        'tillage', 'no-till', 'plowing', 'cultivation', 'rotation', 'intercropping', 'companion',
        
        // Plant health and problems
        'pest', 'pests', 'insect', 'insects', 'bug', 'bugs', 'disease', 'diseases', 'pathogen', 'pathogens',
        'fungus', 'fungi', 'bacterial', 'viral', 'blight', 'rot', 'wilt', 'mold', 'mildew', 'aphid', 'aphids',
        'caterpillar', 'caterpillars', 'beetle', 'beetles', 'mite', 'mites', 'thrips', 'whitefly', 'scale',
        'nematode', 'nematodes', 'weed', 'weeds', 'herbicide', 'pesticide', 'fungicide', 'insecticide',
        
        // Soil and nutrition
        'fertilizer', 'fertilizers', 'fertilizing', 'nutrient', 'nutrients', 'nitrogen', 'phosphorus', 'potassium',
        'npk', 'compost', 'composting', 'manure', 'organic matter', 'humus', 'ph', 'acidity', 'alkaline',
        'lime', 'gypsum', 'micronutrient', 'micronutrients', 'deficiency', 'deficiencies', 'toxicity',
        
        // Water and irrigation
        'irrigation', 'irrigate', 'irrigating', 'water', 'watering', 'drip', 'sprinkler', 'flood', 'furrow',
        'pivot', 'moisture', 'drought', 'dry', 'wet', 'drainage', 'drain', 'draining', 'waterlogged',
        'hydration', 'rain', 'rainfall', 'precipitation', 'groundwater', 'well', 'pump',
        
        // Tools and equipment
        'tractor', 'combine', 'harvester', 'plow', 'cultivator', 'seeder', 'spreader', 'sprayer', 'mower',
        'rake', 'hoe', 'shovel', 'spade', 'pruning', 'shears', 'greenhouse', 'tunnel', 'polytunnel',
        'mulch', 'mulching', 'cover crop', 'green manure',
        
        // Timing and seasons
        'season', 'seasonal', 'spring', 'summer', 'fall', 'autumn', 'winter', 'planting season',
        'growing season', 'harvest season', 'dormant', 'dormancy', 'germination', 'flowering',
        'fruiting', 'maturity', 'ripening', 'storage', 'preservation',
        
        // General farming concepts
        'yield', 'production', 'productivity', 'efficiency', 'sustainability', 'environment', 'climate',
        'weather', 'temperature', 'humidity', 'sun', 'shade', 'light', 'photosynthesis', 'respiration',
        'transpiration', 'pollination', 'cross-pollination', 'self-pollination', 'grafting', 'pruning',
        'training', 'staking', 'support', 'trellis', 'canopy', 'root', 'roots', 'stem', 'stems', 'leaf',
        'leaves', 'flower', 'flowers', 'bloom', 'blooming', 'bud', 'buds', 'branch', 'branches'
      ];

      // For agriculture, be extremely permissive - if it contains any agriculture-related keyword, consider it relevant
      const hasAgricultureMatch = agricultureKeywords.some(keyword => 
        lowerQuery.includes(keyword)
      );

      if (hasAgricultureMatch) return { isRelevant: true };

      // Also check for questions that might be agricultural even without specific keywords
      const agriculturalPatterns = [
        /how.*grow/i, /what.*plant/i, /when.*plant/i, /why.*plant/i, /where.*plant/i,
        /how.*care/i, /what.*feed/i, /when.*harvest/i, /how.*harvest/i,
        /what.*wrong/i, /why.*yellow/i, /why.*brown/i, /why.*dying/i, /why.*wilting/i,
        /how.*improve/i, /what.*use/i, /when.*apply/i, /how.*treat/i,
        /what.*best/i, /which.*better/i, /how.*prevent/i, /what.*cause/i
      ];

      if (agriculturalPatterns.some(pattern => pattern.test(query))) {
        return { isRelevant: true };
      }

      // If it's a very short or general query, assume it might be agricultural
      if (query.trim().split(' ').length <= 3) {
        return { isRelevant: true };
      }

      // Default to relevant for agriculture domain unless it's clearly about other domains
      return { isRelevant: true };
    }

    // Check for other domain keywords (only check if not agriculture domain)
    const domainKeywords = {
      'food-technology': ['food processing', 'pasteurization', 'haccp', 'food safety', 'packaging technology', 'preservation', 'quality control'],
      'rural-development': ['rural infrastructure', 'community development', 'rural electrification', 'cooperative formation', 'rural economics', 'development project']
    };

    // Check if query matches other domains specifically
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      if (domain !== this.domain && keywords.some(k => lowerQuery.includes(k))) {
        return { 
          isRelevant: false, 
          detectedTopic: domain.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()) 
        };
      }
    }

    // For current domain, check specific keywords
    const currentDomainKeywords = domainKeywords[this.domain] || [];
    const hasCurrentMatch = currentDomainKeywords.some(keyword => lowerQuery.includes(keyword));

    if (hasCurrentMatch) return { isRelevant: true };

    // Default to relevant for all domains now
    return { isRelevant: true };
  }

  private getDomainName(): string {
    const names = {
      'agriculture': 'Agriculture',
      'food-technology': 'Food Technology',
      'rural-development': 'Rural Development'
    };
    return names[this.domain];
  }

  private getDomainDescription(): string {
    const descriptions = {
      'agriculture': 'comprehensive farming guidance including crops, livestock, soil, water, pest management, and all aspects of agricultural production',
      'food-technology': 'food processing, preservation, packaging, safety standards, and quality control',
      'rural-development': 'infrastructure development, community projects, and rural economic growth'
    };
    return descriptions[this.domain];
  }

  private getSampleQuestions(): string[] {
    const samples = {
      'agriculture': [
        'How do I improve my soil quality?',
        'What\'s the best way to control aphids naturally?',
        'When should I plant tomatoes in my region?',
        'How to diagnose yellow leaves on my plants?',
        'What fertilizer should I use for vegetables?',
        'How to set up drip irrigation?'
      ],
      'food-technology': [
        'How does pasteurization work?',
        'What packaging is best for fresh produce?',
        'How to implement HACCP in a small facility?',
        'What causes food spoilage and how to prevent it?',
        'Best practices for food safety testing?'
      ],
      'rural-development': [
        'How to start a community water project?',
        'What are the best rural electrification options?',
        'How to form an agricultural cooperative?',
        'Grant funding sources for rural infrastructure?',
        'Community engagement strategies for development projects?'
      ]
    };
    return samples[this.domain] || samples['agriculture'];
  }

  // Image analysis is now handled directly in generateResponse method

  clearConversation() {
    this.conversationHistory = [];
  }
}

// Utility functions
export const createOpenAI = (domain: 'agriculture' | 'food-technology' | 'rural-development') => {
  return new OpenAISystem(domain);
};

export const formatResponse = (response: string): string => {
  return response
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/\n/g, '<br>')
    .replace(/•/g, '&bull;');
};

export const simulateTypingDelay = (text: string): number => {
  // Simulate realistic typing delay based on text length
  const wordsPerMinute = 200; // Fast AI typing
  const words = text.split(' ').length;
  const minutes = words / wordsPerMinute;
  return Math.min(minutes * 60 * 1000, 3000); // Max 3 seconds
};