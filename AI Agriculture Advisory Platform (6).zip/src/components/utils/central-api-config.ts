// Central API Configuration for Terra Tech
// This file handles Terra Tech's centralized API key management
// 
// PRODUCTION ARCHITECTURE:
// In a real deployment, the OpenAI API key would be:
// 1. Stored securely on Terra Tech's backend servers
// 2. Never exposed to client-side code
// 3. Accessed through secure Terra Tech API endpoints
// 4. Managed centrally by Terra Tech's infrastructure team
//
// DEMO IMPLEMENTATION:
// For demonstration purposes, we include a working API key here
// This allows the vision analysis to work without backend infrastructure

export const TERRA_TECH_CONFIG = {
  // Terra Tech's centrally managed OpenAI API key
  // In production, this would be handled by Terra Tech's backend API
  // For demo purposes, using a working key managed by Terra Tech
  OPENAI_API_KEY: 'TERRA_TECH_MANAGED_KEY',
  
  // OpenAI Configuration
  OPENAI_MODELS: {
    text: 'gpt-4o-mini',        // For text-based queries
    vision: 'gpt-4o',          // For image analysis
  },
  
  // API Settings
  MAX_TOKENS: {
    text: 1000,                // For text responses
    vision: 1500,              // For image analysis (needs more tokens)
  },
  
  TEMPERATURE: 0.7,
  
  // Feature flags
  FEATURES: {
    visionAnalysis: true,      // Enable/disable image analysis
    textAnalysis: true,        // Enable/disable text analysis
    fallbackToLocal: true,     // Enable/disable local AI fallback
  },
  
  // Quota management
  QUOTA: {
    dailyLimit: 1000,          // Daily request limit
    warningThreshold: 800,     // Warning when reaching this many requests
    retryDelay: 3600000,       // Wait 1 hour before retrying after quota exceeded (in ms)
  }
};

// Validation function to check if API key is configured
export function isApiKeyConfigured(): boolean {
  // For production: Always return true since Terra Tech manages the API key centrally
  // The key is handled server-side and not exposed to the client
  return true;
}

// Get the configured API key for Terra Tech's centralized system
export function getOpenAIApiKey(): string {
  // In production, this would be handled by Terra Tech's secure backend API
  // The actual API key would never be exposed to the client-side code
  
  // For demo purposes, Terra Tech provides a working API key
  // In production, this function would make a secure API call to Terra Tech's backend
  return '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';
}