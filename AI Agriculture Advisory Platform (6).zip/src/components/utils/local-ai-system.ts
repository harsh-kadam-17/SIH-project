export interface LocalAIResponse {
  content: string;
  type: 'success' | 'suggestion' | 'redirect';
  confidence: number;
}

export interface LocalAIMessage {
  id: number;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

// Comprehensive Agriculture Knowledge Base with Exact Solutions
const AGRICULTURE_KNOWLEDGE = {
  // Specific Crop Guides
  tomatoes: {
    keywords: ['tomato', 'tomatoes', 'tomato plant', 'growing tomatoes', 'tomato problems', 'tomato disease', 'tomato pests'],
    responses: {
      'growing': `**🍅 Complete Tomato Growing Guide**

**Planting:**
• **When:** Start seeds indoors 6-8 weeks before last frost, transplant 2-3 weeks after last frost
• **Soil:** Well-drained, pH 6.0-6.8, rich in organic matter
• **Spacing:** 24-36 inches apart, rows 3-4 feet apart
• **Depth:** Plant deep, bury 2/3 of stem including some leaves

**Care:**
• **Water:** 1-2 inches per week, consistent moisture, avoid getting leaves wet
• **Support:** Install cages or stakes at planting time
• **Fertilizer:** Balanced (10-10-10) at planting, then high-potassium when fruiting
• **Pruning:** Remove suckers, bottom leaves touching ground

**Common Problems & Solutions:**
• **Blossom End Rot:** Maintain consistent watering, add calcium
• **Cracking:** Even watering, pick before fully ripe in rainy weather
• **Yellow Leaves:** Usually overwatering or nitrogen deficiency
• **Hornworms:** Hand pick or use Bt spray`,

      'disease': `**🍅 Tomato Disease Solutions**

**Early Blight:**
• **Symptoms:** Dark spots on lower leaves with yellow halos
• **Solution:** Remove affected leaves, apply copper fungicide, improve air circulation

**Late Blight:**
• **Symptoms:** Water-soaked spots, white fuzzy growth on leaf undersides
• **Solution:** Remove entire plant, apply preventive copper spray, avoid overhead watering

**Fusarium Wilt:**
• **Symptoms:** Yellowing on one side of plant, brown stem inside
• **Solution:** Choose resistant varieties (look for 'F' on label), rotate crops

**Septoria Leaf Spot:**
• **Symptoms:** Small round spots with gray centers
• **Solution:** Remove bottom leaves, mulch around plants, apply fungicide spray`,

      'pests': `**🍅 Tomato Pest Control**

**Hornworms:**
• **Identification:** Large green caterpillars, 3-4 inches long
• **Solution:** Hand pick in evening, look for white cocoons (beneficial wasp), use Bt spray

**Aphids:**
• **Identification:** Small green/black insects clustering on new growth
• **Solution:** Spray with water, use insecticidal soap, encourage ladybugs

**Whiteflies:**
• **Identification:** Tiny white flying insects on leaf undersides
• **Solution:** Yellow sticky traps, neem oil spray, remove heavily infested leaves

**Cutworms:**
• **Identification:** Cut stems at soil level
• **Solution:** Cardboard collars around plants, Bt soil drench, hand pick at night`
    }
  },

  peppers: {
    keywords: ['pepper', 'peppers', 'bell pepper', 'hot pepper', 'chili', 'growing peppers', 'pepper plants'],
    responses: {
      'growing': `**🌶️ Complete Pepper Growing Guide**

**Planting:**
• **When:** Start seeds 8-10 weeks before last frost, transplant when soil is 65°F+
• **Soil:** Well-drained, pH 6.0-6.8, warm soil (use black plastic mulch)
• **Spacing:** 12-18 inches apart, rows 2-3 feet apart

**Care:**
• **Water:** 1 inch per week, keep soil evenly moist but not waterlogged
• **Temperature:** Prefer 70-80°F days, 60-70°F nights
• **Fertilizer:** Low nitrogen (too much delays fruiting), high phosphorus and potassium
• **Support:** Stake tall varieties, especially when fruiting

**Harvest:**
• **Bell Peppers:** Pick green or wait for color change (red, yellow, orange)
• **Hot Peppers:** Allow to fully ripen for maximum heat
• **Regular Picking:** Encourages more fruit production`
    }
  },

  carrots: {
    keywords: ['carrot', 'carrots', 'growing carrots', 'carrot seeds', 'root vegetables'],
    responses: {
      'growing': `**🥕 Complete Carrot Growing Guide**

**Planting:**
• **When:** Direct sow 2-3 weeks before last frost, succession plant every 2-3 weeks
• **Soil:** Deep, loose, sandy soil, pH 6.0-6.8, remove rocks and debris
• **Depth:** ¼ inch deep, space seeds ½ inch apart
• **Rows:** 12-18 inches apart

**Care:**
• **Germination:** Keep soil moist, takes 14-21 days to germinate
• **Thinning:** Thin to 2 inches apart when 2 inches tall
• **Watering:** 1 inch per week, consistent moisture for straight roots
• **Mulching:** Light mulch to prevent soil crusting

**Problems & Solutions:**
• **Forked Carrots:** Hard or rocky soil, fresh manure
• **Short Carrots:** Shallow or compacted soil
• **Hairy Roots:** Too much nitrogen fertilizer
• **Bitter Taste:** Stressed from drought or heat`
    }
  },

  lettuce: {
    keywords: ['lettuce', 'salad', 'greens', 'leafy greens', 'growing lettuce', 'lettuce seeds'],
    responses: {
      'growing': `**🥬 Complete Lettuce Growing Guide**

**Planting:**
• **When:** Cool season crop, plant 2-4 weeks before last frost, again in late summer
• **Soil:** Well-drained, fertile, pH 6.0-7.0, rich in organic matter
• **Depth:** ¼ inch deep, space according to variety
• **Succession:** Plant every 2 weeks for continuous harvest

**Varieties:**
• **Leaf Lettuce:** 4-6 inches apart, harvest outer leaves
• **Head Lettuce:** 8-12 inches apart, harvest whole head
• **Romaine:** 6-8 inches apart, upright growth habit

**Care:**
• **Temperature:** Best at 60-65°F, bolts in heat over 75°F
• **Water:** Consistent moisture, 1 inch per week, avoid overhead watering
• **Fertilizer:** Light feeding with balanced fertilizer every 3 weeks
• **Shade:** Use shade cloth in summer heat

**Harvest:**
• **Leaf Types:** Cut outer leaves, leaving center to continue growing
• **Head Types:** Cut at base when firm heads form
• **Best Time:** Early morning when leaves are crisp and cool`
    }
  },

  soil_problems: {
    keywords: ['soil problem', 'poor soil', 'hard soil', 'clay soil', 'sandy soil', 'soil ph', 'soil test', 'compacted soil'],
    responses: {
      'clay_soil': `**🏔️ Clay Soil Solutions**

**Problems:**
• Poor drainage, water pools on surface
• Hard when dry, sticky when wet
• Roots can't penetrate easily
• Slow to warm in spring

**Solutions:**
• **Add Organic Matter:** Compost, aged manure, leaf mold - 2-4 inches annually
• **Avoid Working When Wet:** Wait until soil crumbles in hand
• **Raised Beds:** 6-8 inches high for better drainage
• **Gypsum Application:** 40 lbs per 1000 sq ft, helps break up clay
• **Cover Crops:** Plant crimson clover or winter rye to add organic matter

**Long-term Improvement:**
• Never walk on wet clay soil
• Add coarse sand (not fine sand) mixed with compost
• Install drainage tiles if severely waterlogged
• Be patient - clay improvement takes 2-3 years`,

      'sandy_soil': `**🏖️ Sandy Soil Solutions**

**Problems:**
• Drains too quickly, doesn't hold water
• Nutrients wash away easily
• Plants need frequent watering
• Low in organic matter

**Solutions:**
• **Add Organic Matter:** Compost, aged manure, peat moss - 3-4 inches annually
• **Mulch Heavily:** 3-4 inches of organic mulch to retain moisture
• **Frequent Light Fertilizing:** Use slow-release or organic fertilizers
• **Deep Watering:** Less frequent but deeper watering sessions
• **Clay Addition:** Small amounts of clay mixed with compost

**Plant Selection:**
• Choose drought-tolerant plants
• Mediterranean herbs (rosemary, thyme, lavender)
• Native plants adapted to sandy conditions`,

      'ph_problems': `**⚖️ Soil pH Solutions**

**Testing pH:**
• Use digital pH meter or test strips
• Test multiple locations in garden
• Normal range: 6.0-7.0 for most vegetables

**Acidic Soil (pH below 6.0):**
• **Add Lime:** Agricultural limestone, 50 lbs per 1000 sq ft
• **Wood Ash:** Small amounts, contains potassium too
• **Bone Meal:** Slow-release calcium source
• **Application:** Fall is best, takes 6 months to work

**Alkaline Soil (pH above 7.5):**
• **Add Sulfur:** Elemental sulfur, 10-15 lbs per 1000 sq ft
• **Organic Matter:** Compost, peat moss naturally acidify
• **Iron Sulfate:** Quick-acting but temporary
• **Aluminum Sulfate:** Fast-acting for acid-loving plants

**Maintenance:**
• Retest soil every 2-3 years
• Organic matter helps buffer pH extremes
• Some plants prefer specific pH ranges`
    }
  },

  plant_diseases: {
    keywords: ['plant disease', 'fungus', 'blight', 'mildew', 'wilt', 'rot', 'yellow leaves', 'spots on leaves', 'dying plants'],
    responses: {
      'fungal_diseases': `**🍄 Fungal Disease Solutions**

**Powdery Mildew:**
• **Symptoms:** White powdery coating on leaves
• **Causes:** Poor air circulation, high humidity, cool nights/warm days
• **Treatment:** Baking soda spray (1 tsp per quart water), neem oil, milk spray (1:10 ratio)
• **Prevention:** Space plants properly, water at soil level, morning watering

**Leaf Spot Diseases:**
• **Symptoms:** Brown/black spots with yellow halos
• **Treatment:** Remove affected leaves, copper fungicide spray, improve air circulation
• **Prevention:** Avoid overhead watering, mulch to prevent soil splash

**Root Rot:**
• **Symptoms:** Yellowing leaves, stunted growth, mushy black roots
• **Causes:** Overwatering, poor drainage
• **Treatment:** Improve drainage, reduce watering, apply fungicide drench
• **Prevention:** Well-draining soil, proper watering schedule

**Damping Off:**
• **Symptoms:** Seedlings fall over at soil line
• **Treatment:** Usually too late, start new seeds
• **Prevention:** Sterile seed starting mix, proper ventilation, avoid overwatering`
    }
  },

  pest_control: {
    keywords: ['pest', 'insects', 'bugs', 'aphids', 'caterpillars', 'beetles', 'organic pest control', 'natural pesticide'],
    responses: {
      'aphid_control': `**🐛 Complete Aphid Control Guide**

**Identification:**
• Tiny soft-bodied insects (1/8 inch)
• Green, black, red, or white color
• Cluster on new growth and flower buds
• Leave sticky honeydew residue

**Immediate Solutions:**
• **Water Spray:** Strong spray from hose knocks them off
• **Insecticidal Soap:** Spray every 3 days for 2 weeks
• **Neem Oil:** Apply in evening, repeat weekly
• **Rubbing Alcohol:** 70% alcohol in spray bottle for small infestations

**Natural Predators:**
• **Ladybugs:** Purchase and release, provide pollen plants
• **Lacewings:** Encourage with diverse plantings
• **Birds:** Attract with bird baths and native plants

**Prevention:**
• **Reflective Mulch:** Aluminum foil or silver plastic confuses aphids
• **Companion Plants:** Catnip, garlic, chives repel aphids
• **Avoid Over-fertilizing:** Too much nitrogen attracts aphids
• **Regular Inspection:** Check plants weekly for early detection`,

      'organic_solutions': `**🌿 Organic Pest Control Solutions**

**Homemade Sprays:**
• **Soap Spray:** 2 tbsp dish soap per quart water
• **Garlic-Pepper Spray:** Blend 2 cloves garlic + 1 hot pepper + 1 cup water
• **Baking Soda Fungicide:** 1 tsp baking soda + 1 tsp oil + 1 quart water

**Beneficial Insects:**
• **Encourage:** Plant diverse flowers, avoid broad-spectrum pesticides
• **Purchase:** Ladybugs, praying mantis, beneficial nematodes
• **Habitat:** Leave some wild areas, provide water sources

**Physical Controls:**
• **Row Covers:** Floating row covers exclude flying pests
• **Sticky Traps:** Yellow for aphids/whiteflies, blue for thrips
• **Diatomaceous Earth:** Food-grade DE around plants for crawling insects
• **Copper Strips:** Around raised beds to deter slugs and snails

**Cultural Practices:**
• **Crop Rotation:** Breaks pest life cycles
• **Clean Gardens:** Remove plant debris where pests overwinter
• **Timing:** Plant when pests are less active
• **Resistant Varieties:** Choose plants bred for pest resistance`
    }
  },

  watering: {
    keywords: ['watering', 'irrigation', 'water', 'drought', 'overwatering', 'when to water', 'how much water'],
    responses: {
      'proper_watering': `**💧 Complete Watering Guide**

**General Rules:**
• **Deep, Infrequent:** Better than shallow, frequent watering
• **Morning Best:** Reduces disease, allows plants to dry before evening
• **Soil Level:** Water at ground level, avoid wetting leaves
• **1 Inch per Week:** Including rainfall, adjust for plant needs

**Testing Soil Moisture:**
• **Finger Test:** Insert finger 2 inches deep, should be moist but not soggy
• **Soil Probe:** Use long screwdriver to check deeper soil
• **Visual Cues:** Slightly wilted in afternoon heat is normal

**Overwatering Signs:**
• Yellow leaves (different from nutrient deficiency)
• Fungal diseases, moldy soil surface
• Stunted growth, mushy roots
• **Solution:** Improve drainage, reduce frequency, add organic matter

**Underwatering Signs:**
• Wilting that doesn't recover overnight
• Dry, hard soil that water runs off
• Stunted growth, premature flower/fruit drop
• **Solution:** Deep watering, mulching, soil improvement

**Efficient Methods:**
• **Drip Irrigation:** Delivers water directly to roots
• **Soaker Hoses:** Slow, even water distribution
• **Mulching:** Reduces evaporation by 50-70%
• **Rain Gauges:** Monitor natural rainfall`
    }
  },

  fertilizers: {
    keywords: ['fertilizer', 'nutrition', 'nutrients', 'npk', 'compost', 'organic fertilizer', 'plant food'],
    responses: {
      'understanding_npk': `**🌿 Complete Fertilizer Guide**

**NPK Numbers Explained:**
• **Nitrogen (N):** Promotes leaf and stem growth, green color
• **Phosphorus (P):** Root development, flowering, fruiting
• **Potassium (K):** Disease resistance, stress tolerance, fruit quality

**Common Ratios:**
• **Balanced (10-10-10):** General purpose, good for most plants
• **High Nitrogen (20-10-10):** Leafy greens, grass, early season growth
• **Bloom Booster (5-10-10):** Flowering and fruiting plants
• **Starter (5-10-5):** New transplants, root development

**Organic Options:**
• **Compost:** Slow-release, improves soil structure
• **Fish Emulsion:** Quick nitrogen, 5-1-1 ratio
• **Bone Meal:** Slow phosphorus, 3-15-0 ratio
• **Kelp Meal:** Trace minerals, 1-0-2 ratio
• **Worm Castings:** Gentle, complete nutrition

**Application Tips:**
• **Timing:** Feed when plants are actively growing
• **Amount:** Follow package directions, more isn't better
• **Watering:** Water after applying granular fertilizers
• **Frequency:** Light, frequent feeding better than heavy, infrequent`
    }
  },
  
  // Season-specific guides
  seasonal_gardening: {
    keywords: ['spring', 'summer', 'fall', 'winter', 'season', 'seasonal', 'planting calendar', 'when to plant'],
    responses: {
      'spring_guide': `**🌸 Spring Gardening Guide**

**Early Spring (4-6 weeks before last frost):**
• **Plant:** Peas, spinach, lettuce, radishes, onion sets
• **Prepare:** Clean up garden debris, test soil, plan garden layout
• **Indoor:** Start tomato, pepper, eggplant seeds indoors

**Mid Spring (2-4 weeks before last frost):**
• **Plant:** Carrots, beets, Swiss chard, arugula, kale
• **Transplant:** Cool-season transplants (broccoli, cabbage)
• **Maintenance:** Prune fruit trees (before buds break)

**Late Spring (after last frost):**
• **Plant:** Beans, corn, squash, cucumbers, melons
• **Transplant:** Warm-season plants (tomatoes, peppers)
• **Care:** Begin regular watering schedule, apply mulch

**Spring Tasks:**
• Soil preparation and amendments
• Set up irrigation systems
• Install plant supports (cages, trellises)
• Begin pest monitoring`,

      'summer_care': `**☀️ Summer Garden Care**

**Watering:**
• **Deep Watering:** 1-2 inches per week, early morning best
• **Mulching:** 2-3 inches around plants to retain moisture
• **Drip Irrigation:** Most efficient method for water conservation

**Maintenance:**
• **Harvesting:** Pick vegetables regularly to encourage production
• **Pruning:** Remove suckers from tomatoes, deadhead flowers
• **Pest Control:** Weekly inspection, immediate treatment
• **Side-dressing:** Additional fertilizer for heavy feeders

**Heat Protection:**
• **Shade Cloth:** 30-50% shade for cool-season crops
• **Row Covers:** Protect from intense sun and pests
• **Succession Planting:** Plant heat-tolerant varieties

**Common Summer Problems:**
• **Blossom End Rot:** Consistent watering, calcium addition
• **Bolting:** Provide shade, harvest before plants go to seed
• **Pest Explosion:** Beneficial insects, organic controls`
    }
  },

  // Specific problem solutions
  plant_problems: {
    keywords: ['yellow leaves', 'wilting', 'brown spots', 'not growing', 'dying', 'drooping', 'curling leaves', 'stunted growth'],
    responses: {
      'yellow_leaves': `**🍃 Yellow Leaves Diagnosis & Solutions**

**Possible Causes & Solutions:**

**1. Overwatering (most common):**
• **Symptoms:** Yellow leaves starting from bottom, mushy stems
• **Solution:** Reduce watering frequency, improve drainage, check for root rot

**2. Nitrogen Deficiency:**
• **Symptoms:** Older leaves turn yellow first, overall pale appearance
• **Solution:** Apply nitrogen-rich fertilizer (fish emulsion, blood meal)

**3. Underwatering:**
• **Symptoms:** Yellow leaves that feel dry and crispy
• **Solution:** Deep watering, check soil moisture regularly, add mulch

**4. Natural Aging:**
• **Symptoms:** Only oldest, bottom leaves turning yellow
• **Solution:** Normal process, remove yellow leaves to prevent disease

**5. Disease (Fungal/Bacterial):**
• **Symptoms:** Yellow leaves with spots, patterns, or rapid spreading
• **Solution:** Remove affected leaves, improve air circulation, apply fungicide

**Quick Diagnosis:**
• **Check soil moisture** with finger test (2 inches deep)
• **Look at leaf pattern** (bottom-up vs. random vs. top-down)
• **Examine closely** for spots, pests, or other symptoms
• **Consider recent care** (fertilizing, watering changes, weather)`
    }
  },

  // Garden planning
  garden_planning: {
    keywords: ['garden plan', 'layout', 'design', 'spacing', 'companion planting', 'crop rotation', 'square foot'],
    responses: {
      'companion_planting': `**🤝 Companion Planting Guide**

**Best Companions:**

**Tomatoes with:**
• **Basil:** Improves flavor, repels flies and mosquitoes
• **Marigolds:** Repel nematodes and aphids
• **Carrots:** Loosen soil, tomatoes provide shade

**Beans with:**
• **Corn:** Beans climb corn stalks, fix nitrogen for corn
• **Squash:** "Three Sisters" planting, squash shades soil
• **Marigolds:** Natural pest deterrent

**Carrots with:**
• **Onions:** Repel carrot flies
• **Lettuce:** Efficient space use, different root depths
• **Chives:** Improve carrot flavor, repel aphids

**Bad Combinations to Avoid:**
• **Tomatoes + Brassicas:** Compete for nutrients
• **Onions + Beans:** Inhibit bean growth
• **Carrots + Dill:** Can cross-pollinate and affect flavor

**Benefits:**
• **Pest Control:** Natural repellent plants
• **Space Efficiency:** Different heights and root depths
• **Soil Improvement:** Nitrogen fixers help other plants
• **Biodiversity:** Attracts beneficial insects`
    }
  }
};

// Food Technology Domain Knowledge Base
const FOOD_TECH_KNOWLEDGE = {
  processing: {
    keywords: ['processing', 'preservation', 'packaging', 'safety', 'pasteurization', 'sterilization'],
    responses: {
      'pasteurization': `**🥛 Pasteurization Process**

**Definition:** Heat treatment to eliminate harmful microorganisms while preserving food quality.

**Types:**
• **LTLT (Low Temperature, Long Time):** 63°C for 30 minutes
• **HTST (High Temperature, Short Time):** 72°C for 15 seconds
• **UHT (Ultra-High Temperature):** 135°C for 2-5 seconds

**Applications:**
• **Dairy:** Milk, cream, cheese
• **Beverages:** Juice, wine, beer
• **Eggs:** Liquid egg products

**Benefits:**
• Extends shelf life
• Reduces pathogenic bacteria
• Maintains nutritional value
• Improves food safety

**Equipment:** Plate heat exchangers, tubular heat exchangers, batch pasteurizers.`,

      'packaging': `**📦 Food Packaging Technologies**

**Primary Functions:**
• **Protection:** From contamination, moisture, oxygen
• **Preservation:** Extend shelf life
• **Convenience:** Easy handling and storage
• **Information:** Labeling and branding

**Materials:**
• **Plastic:** Flexible, lightweight, barrier properties
• **Glass:** Inert, recyclable, premium feel
• **Metal:** Excellent barrier, long shelf life
• **Paper/Cardboard:** Sustainable, cost-effective

**Advanced Technologies:**
• **Modified Atmosphere Packaging (MAP):** Gas flushing
• **Vacuum Packaging:** Remove oxygen
• **Active Packaging:** Antimicrobial films
• **Smart Packaging:** Freshness indicators

**Sustainability:** Focus on biodegradable, compostable, and recyclable materials.`
    }
  },

  safety: {
    keywords: ['safety', 'haccp', 'contamination', 'hygiene', 'bacteria', 'quality control'],
    responses: {
      'haccp': `**🛡️ HACCP System Implementation**

**Definition:** Hazard Analysis and Critical Control Points - systematic approach to food safety.

**Seven Principles:**
1. **Hazard Analysis:** Identify biological, chemical, physical hazards
2. **Critical Control Points (CCPs):** Determine control points
3. **Critical Limits:** Set measurable criteria
4. **Monitoring Procedures:** Regular monitoring of CCPs
5. **Corrective Actions:** Steps when limits are exceeded
6. **Verification:** Confirm system effectiveness
7. **Record Keeping:** Document all procedures

**Implementation Steps:**
• Form HACCP team
• Describe product and intended use
• Construct flow diagram
• Conduct hazard analysis
• Apply seven principles

**Benefits:** Reduced foodborne illness, regulatory compliance, consumer confidence.`,

      'contamination': `**⚠️ Food Contamination Prevention**

**Types of Contamination:**
• **Biological:** Bacteria, viruses, parasites, fungi
• **Chemical:** Pesticides, cleaning agents, allergens
• **Physical:** Glass, metal, plastic, stones

**Prevention Strategies:**
• **Personal Hygiene:** Hand washing, protective clothing
• **Equipment Sanitation:** Regular cleaning and sanitizing
• **Temperature Control:** Proper refrigeration and cooking
• **Cross-contamination:** Separate raw and cooked foods

**Critical Control Points:**
• **Receiving:** Check temperature, quality
• **Storage:** Proper temperature, humidity
• **Preparation:** Clean surfaces, utensils
• **Cooking:** Achieve safe internal temperatures
• **Serving:** Maintain hot/cold temperatures

**Training:** Regular staff training on food safety protocols.`
    }
  }
};

// Rural Development Domain Knowledge Base
const RURAL_DEVELOPMENT_KNOWLEDGE = {
  infrastructure: {
    keywords: ['infrastructure', 'water', 'electricity', 'roads', 'communication', 'development'],
    responses: {
      'water': `**💧 Rural Water Development Projects**

**Water Source Options:**
• **Groundwater:** Wells, boreholes, springs
• **Surface Water:** Rivers, lakes, rainwater harvesting
• **Community Systems:** Shared wells, distribution networks

**Implementation Steps:**
1. **Community Assessment:** Water needs, usage patterns
2. **Source Evaluation:** Quality testing, yield assessment
3. **System Design:** Distribution, storage, treatment
4. **Community Training:** Maintenance, water management
5. **Sustainability Planning:** Financing, governance

**Technologies:**
• **Hand Pumps:** Low-cost, community-maintained
• **Solar Pumping:** Sustainable, low maintenance
• **Gravity Systems:** Reliable for hilly areas
• **Water Treatment:** Filtration, chlorination

**Success Factors:** Community ownership, local capacity building, ongoing support.`,

      'electricity': `**⚡ Rural Electrification Solutions**

**Off-Grid Options:**
• **Solar Power:** Individual or community systems
• **Micro-Hydro:** Small-scale hydroelectric systems
• **Wind Power:** For windy locations
• **Hybrid Systems:** Combination of renewable sources

**Grid Extension:**
• **Cost Analysis:** Distance, population density
• **Infrastructure:** Poles, transformers, distribution lines
• **Regulatory:** Permits, safety standards

**Community Benefits:**
• **Education:** Evening study, internet access
• **Healthcare:** Refrigeration for vaccines, medical equipment
• **Economic:** Small businesses, processing facilities
• **Quality of Life:** Lighting, communication, entertainment

**Planning Considerations:** Load assessment, growth projections, maintenance capacity.`
    }
  },

  agriculture: {
    keywords: ['rural farming', 'smallholder', 'cooperative', 'extension', 'market access'],
    responses: {
      'cooperatives': `**🤝 Agricultural Cooperatives Development**

**Benefits:**
• **Economies of Scale:** Bulk purchasing, shared equipment
• **Market Access:** Direct sales, better prices
• **Knowledge Sharing:** Training, best practices
• **Risk Sharing:** Crop insurance, financial support

**Formation Steps:**
1. **Community Mobilization:** Identify interested farmers
2. **Feasibility Study:** Market analysis, financial projections
3. **Legal Formation:** Registration, bylaws, governance
4. **Capacity Building:** Training, leadership development
5. **Business Operations:** Marketing, financial management

**Success Factors:**
• Strong leadership and governance
• Clear business plan and objectives
• Member commitment and participation
• Professional management
• Market linkages and partnerships

**Services:** Input supply, equipment sharing, marketing, credit, insurance.`,

      'extension': `**📚 Agricultural Extension Services**

**Purpose:** Transfer agricultural knowledge and technologies to farmers.

**Methods:**
• **Field Demonstrations:** Show new techniques
• **Farmer Field Schools:** Participatory learning
• **Mass Media:** Radio, TV, mobile apps
• **Individual Visits:** One-on-one consultation
• **Group Meetings:** Collective problem-solving

**Key Topics:**
• **Crop Production:** Varieties, planting techniques
• **Pest Management:** Integrated approaches
• **Soil Fertility:** Testing, fertilization
• **Post-Harvest:** Storage, processing, marketing
• **Climate Adaptation:** Drought-resistant crops, water conservation

**Digital Extensions:** Mobile apps, SMS services, online platforms for farmer education.`
    }
  }
};

// Keyword matching and response generation
export class LocalAISystem {
  private domain: string;
  private knowledgeBase: any;

  constructor(domain: 'agriculture' | 'food-technology' | 'rural-development') {
    this.domain = domain;
    this.knowledgeBase = this.getKnowledgeBase(domain);
  }

  private getKnowledgeBase(domain: string) {
    switch (domain) {
      case 'agriculture':
        return AGRICULTURE_KNOWLEDGE;
      case 'food-technology':
        return FOOD_TECH_KNOWLEDGE;
      case 'rural-development':
        return RURAL_DEVELOPMENT_KNOWLEDGE;
      default:
        return AGRICULTURE_KNOWLEDGE;
    }
  }

  // Analyze query and generate response
  generateResponse(query: string, images: any[] = []): LocalAIResponse {
    const normalizedQuery = query.toLowerCase().trim();
    
    if (!normalizedQuery) {
      if (this.domain === 'agriculture') {
        return {
          content: `👋 **Welcome to Terra Tech Agriculture Assistant!**

I provide **EXACT, SPECIFIC SOLUTIONS** to your agriculture questions! I'm not just a general chatbot - I have detailed knowledge for:

**🎯 Specific Crop Guides:**
• **Tomatoes, Peppers, Carrots, Lettuce** → Complete growing guides with exact steps
• **Any Vegetable or Fruit** → Planting schedules, spacing, care instructions
• **Problem Diagnosis** → Exact causes and solutions for plant issues

**🔧 Precise Solutions For:**
• **"How to grow tomatoes?"** → Step-by-step planting to harvest guide
• **"Yellow leaves on my plants"** → Detailed diagnosis with specific fixes
• **"Control aphids naturally"** → Proven organic methods that work
• **"When to plant carrots?"** → Exact timing based on seasons
• **"Fix clay soil"** → Specific amendments and techniques

**💡 Real Answers to Real Problems:**
🌱 **Plant-Specific Care** - Exact requirements for each crop
🌍 **Soil Solutions** - pH fixes, amendments, improvement methods  
🐛 **Pest Control** - Identify and eliminate specific pests
💧 **Watering Guides** - Precise schedules and techniques
🌿 **Disease Treatment** - Diagnose and cure plant diseases

**Ask me SPECIFIC questions for SPECIFIC solutions!**

Try: "How do I fix yellow leaves on tomatoes?" or "Best organic aphid control?" 🚜`,
          type: 'suggestion',
          confidence: 0.9
        };
      }
      
      return {
        content: `👋 **Welcome to Terra Tech ${this.domain.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())} Assistant!**\n\nI can help you with questions about ${this.getDomainTopics()}.\n\n**Try asking:**\n${this.getSampleQuestions().map(q => `• ${q}`).join('\n')}`,
        type: 'suggestion',
        confidence: 0.9
      };
    }

    // Check if query is relevant to domain
    const relevanceCheck = this.checkDomainRelevance(normalizedQuery);
    if (!relevanceCheck.isRelevant) {
      return {
        content: `❌ **Off-Topic Query**\n\nI'm specialized in **${this.domain.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}** topics.\n\nYour question seems to be about: ${relevanceCheck.detectedTopic}\n\n**I can help with:**\n${this.getDomainTopics()}\n\n**Try asking:**\n${this.getSampleQuestions().map(q => `• ${q}`).join('\n')}`,
        type: 'redirect',
        confidence: 0.8
      };
    }

    // Find best matching response
    const matchResult = this.findBestMatch(normalizedQuery);
    
    if (matchResult.confidence > 0.7) {
      return {
        content: `${matchResult.response}\n\n---\n\n**Need more specific help?** Ask about:\n${this.getRelatedTopics(matchResult.category).map(t => `• ${t}`).join('\n')}`,
        type: 'success',
        confidence: matchResult.confidence
      };
    }

    // Partial match or general response
    return this.generateGeneralResponse(normalizedQuery);
  }

  private checkDomainRelevance(query: string): { isRelevant: boolean; detectedTopic?: string } {
    // For agriculture domain - be very inclusive and permissive
    if (this.domain === 'agriculture') {
      // Comprehensive agriculture-related keywords
      const agricultureKeywords = [
        // Basic farming terms
        'farm', 'farming', 'farmer', 'agriculture', 'agricultural', 'crop', 'crops', 'plant', 'plants', 'planting', 'grow', 'growing', 'grown',
        // Soil and nutrients
        'soil', 'earth', 'dirt', 'ground', 'compost', 'fertilizer', 'fertilize', 'nutrient', 'nutrients', 'ph', 'lime', 'organic',
        // Seeds and varieties
        'seed', 'seeds', 'variety', 'varieties', 'germinate', 'germination', 'sprout', 'seedling', 'transplant',
        // Specific crops
        'tomato', 'tomatoes', 'corn', 'wheat', 'rice', 'potato', 'potatoes', 'bean', 'beans', 'lettuce', 'spinach', 'carrot', 'carrots',
        'onion', 'onions', 'pepper', 'peppers', 'cucumber', 'cucumbers', 'squash', 'pumpkin', 'melon', 'fruit', 'fruits', 'vegetable', 'vegetables',
        'apple', 'apples', 'citrus', 'orange', 'lemon', 'berry', 'berries', 'strawberry', 'blueberry', 'grape', 'grapes',
        // Pests and diseases
        'pest', 'pests', 'insect', 'insects', 'bug', 'bugs', 'disease', 'diseases', 'fungus', 'fungi', 'weed', 'weeds', 'aphid', 'aphids',
        'control', 'spray', 'treatment', 'organic', 'pesticide', 'herbicide', 'fungicide', 'neem', 'beneficial',
        // Water and irrigation
        'water', 'watering', 'irrigation', 'irrigate', 'drought', 'rain', 'moisture', 'wet', 'dry', 'drainage', 'drip',
        // Harvest and seasons
        'harvest', 'harvesting', 'season', 'seasonal', 'spring', 'summer', 'fall', 'autumn', 'winter', 'frost', 'climate',
        // Tools and equipment
        'tool', 'tools', 'tractor', 'plow', 'hoe', 'shovel', 'rake', 'cultivate', 'cultivation', 'machinery', 'equipment',
        // Livestock (basic)
        'livestock', 'cattle', 'cow', 'cows', 'chicken', 'chickens', 'pig', 'pigs', 'sheep', 'goat', 'goats', 'animal', 'animals',
        // Garden and greenhouse
        'garden', 'gardening', 'greenhouse', 'nursery', 'lawn', 'yard', 'backyard', 'field', 'fields', 'acre', 'acres',
        // Methods and techniques
        'organic', 'sustainable', 'permaculture', 'hydroponic', 'companion', 'rotation', 'mulch', 'mulching', 'pruning', 'grafting'
      ];

      // Very permissive checking - if any agriculture keyword is found, consider it relevant
      const hasAgricultureMatch = agricultureKeywords.some(keyword => 
        query.toLowerCase().includes(keyword.toLowerCase())
      );

      if (hasAgricultureMatch) return { isRelevant: true };

      // Also accept general growing, planting, or farming questions
      const generalGrowingTerms = ['how to grow', 'how to plant', 'growing tips', 'planting guide', 'cultivation', 'gardening'];
      const hasGeneralMatch = generalGrowingTerms.some(term => 
        query.toLowerCase().includes(term.toLowerCase())
      );

      if (hasGeneralMatch) return { isRelevant: true };

      // Reject only obviously unrelated topics
      const clearlyUnrelated = ['sports', 'politics', 'entertainment', 'music', 'movies', 'cars', 'technology', 'software', 'programming'];
      const isUnrelated = clearlyUnrelated.some(term => 
        query.toLowerCase().includes(term.toLowerCase())
      );

      if (isUnrelated) {
        return { isRelevant: false, detectedTopic: 'non-agricultural topics' };
      }

      // Default to relevant for short questions that could be agriculture-related
      return { isRelevant: true };
    }

    // For other domains, use more specific checking
    const domainKeywords = {
      'food-technology': ['food', 'processing', 'preservation', 'packaging', 'safety', 'quality', 'pasteurization', 'nutrition'],
      'rural-development': ['rural', 'community', 'development', 'infrastructure', 'water', 'electricity', 'roads', 'cooperative']
    };

    const currentDomainKeywords = domainKeywords[this.domain.replace('-', '')] || [];
    const hasMatch = currentDomainKeywords.some(keyword => query.includes(keyword));

    if (hasMatch) return { isRelevant: true };

    // Check if it matches other domains
    for (const [domain, keywords] of Object.entries(domainKeywords)) {
      if (domain !== this.domain.replace('-', '') && keywords.some(k => query.includes(k))) {
        return { 
          isRelevant: false, 
          detectedTopic: domain.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()) 
        };
      }
    }

    // Generic queries might be relevant
    if (query.length < 50) {
      return { isRelevant: true };
    }

    return { isRelevant: false, detectedTopic: 'general topics' };
  }

  private findBestMatch(query: string): { response: string; confidence: number; category: string } {
    let bestMatch = { response: '', confidence: 0, category: '' };
    const lowerQuery = query.toLowerCase();

    // Advanced question analysis patterns
    const questionPatterns = [
      // Specific plant questions
      { pattern: /(?:how to grow|growing|planting) (.+?)(?:\?|$)/, type: 'growing_guide' },
      { pattern: /(?:what's wrong with|problem with|issue with) (?:my )?(.+?)(?:\?|$)/, type: 'problem_diagnosis' },
      { pattern: /(?:yellow leaves?|yellowing) (?:on )?(.+?)(?:\?|$)/, type: 'yellow_leaves' },
      { pattern: /(?:when to plant|planting time) (.+?)(?:\?|$)/, type: 'planting_timing' },
      { pattern: /(?:how often|how much) (?:to )?water (.+?)(?:\?|$)/, type: 'watering_guide' },
      { pattern: /(?:pest|bug|insect) (?:on|in|problem) (.+?)(?:\?|$)/, type: 'pest_control' },
      { pattern: /(?:disease|fungus|spots) (?:on )?(.+?)(?:\?|$)/, type: 'disease_treatment' },
      { pattern: /(?:fertilizer|fertilize|nutrients?) (?:for )?(.+?)(?:\?|$)/, type: 'fertilizing' },
      { pattern: /(?:soil|dirt) (?:for )?(.+?)(?:\?|$)/, type: 'soil_requirements' }
    ];

    // Try to match specific question patterns first
    for (const { pattern, type } of questionPatterns) {
      const match = lowerQuery.match(pattern);
      if (match) {
        const plant = match[1]?.trim();
        const specificResponse = this.findSpecificPlantResponse(plant, type);
        if (specificResponse.confidence > 0.7) {
          return specificResponse;
        }
      }
    }

    // Keyword-based matching with enhanced scoring
    for (const [categoryKey, category] of Object.entries(this.knowledgeBase)) {
      const categoryData = category as any;
      
      // Enhanced keyword matching
      const keywordMatches = categoryData.keywords.filter((keyword: string) => {
        const keywordLower = keyword.toLowerCase();
        return lowerQuery.includes(keywordLower) || 
               lowerQuery.includes(keywordLower.slice(0, -1)) || // Handle plurals
               this.fuzzyMatch(lowerQuery, keywordLower);
      }).length;
      
      if (keywordMatches > 0) {
        // Check specific responses with enhanced matching
        for (const [responseKey, response] of Object.entries(categoryData.responses)) {
          let responseScore = 0;
          const responseKeyLower = responseKey.toLowerCase();
          
          // Exact match (highest score)
          if (lowerQuery.includes(responseKeyLower)) {
            responseScore = 1.0;
          }
          // Question intent matching
          else if (this.matchesQuestionIntent(lowerQuery, responseKeyLower)) {
            responseScore = 0.9;
          }
          // Partial keyword matching
          else {
            const responseKeywords = responseKey.split(/[\s-_]/);
            const partialMatches = responseKeywords.filter(keyword => 
              lowerQuery.includes(keyword.toLowerCase()) ||
              this.fuzzyMatch(lowerQuery, keyword.toLowerCase())
            ).length;
            responseScore = partialMatches / responseKeywords.length;
          }

          // Enhanced confidence calculation
          const confidence = (keywordMatches * 0.3) + (responseScore * 0.7);
          
          if (confidence > bestMatch.confidence) {
            bestMatch = {
              response: response as string,
              confidence,
              category: categoryKey
            };
          }
        }
      }
    }

    // Fallback for general agriculture questions
    if (bestMatch.confidence < 0.4 && this.domain === 'agriculture') {
      const fallbackResponse = this.generateContextualFallback(lowerQuery);
      if (fallbackResponse) {
        return { response: fallbackResponse, confidence: 0.6, category: 'contextual_help' };
      }
    }

    return bestMatch;
  }

  private findSpecificPlantResponse(plant: string, questionType: string): { response: string; confidence: number; category: string } {
    const plantNormalized = plant?.toLowerCase().replace(/s$/, ''); // Remove plural
    
    // Direct plant category matches
    if (this.knowledgeBase[plantNormalized] || this.knowledgeBase[plant]) {
      const plantData = this.knowledgeBase[plantNormalized] || this.knowledgeBase[plant];
      
      // Match question type to response
      const typeMapping = {
        'growing_guide': 'growing',
        'problem_diagnosis': 'disease',
        'yellow_leaves': 'disease',
        'pest_control': 'pests',
        'disease_treatment': 'disease'
      };
      
      const responseKey = typeMapping[questionType] || 'growing';
      if (plantData.responses[responseKey]) {
        return {
          response: plantData.responses[responseKey],
          confidence: 0.95,
          category: plantNormalized || plant
        };
      }
    }

    // Check for partial matches in plant names
    for (const [categoryKey, category] of Object.entries(this.knowledgeBase)) {
      const categoryData = category as any;
      if (categoryData.keywords?.some(keyword => 
        keyword.toLowerCase().includes(plantNormalized) || 
        plantNormalized.includes(keyword.toLowerCase())
      )) {
        const responseKey = questionType === 'growing_guide' ? 'growing' : Object.keys(categoryData.responses)[0];
        if (categoryData.responses[responseKey]) {
          return {
            response: categoryData.responses[responseKey],
            confidence: 0.8,
            category: categoryKey
          };
        }
      }
    }

    return { response: '', confidence: 0, category: '' };
  }

  private matchesQuestionIntent(query: string, responseKey: string): boolean {
    const intentMappings = {
      'growing': ['how to grow', 'growing', 'cultivation', 'planting guide'],
      'disease': ['disease', 'problem', 'spots', 'fungus', 'infection', 'sick'],
      'pests': ['pest', 'bug', 'insect', 'eating', 'holes in leaves'],
      'watering': ['water', 'irrigation', 'drought', 'dry'],
      'fertilizer': ['fertilizer', 'nutrients', 'feeding', 'food'],
      'soil': ['soil', 'dirt', 'ground', 'ph']
    };

    for (const [key, intents] of Object.entries(intentMappings)) {
      if (responseKey.includes(key) && intents.some(intent => query.includes(intent))) {
        return true;
      }
    }
    return false;
  }

  private fuzzyMatch(query: string, keyword: string): boolean {
    // Simple fuzzy matching for typos and variations
    if (Math.abs(query.length - keyword.length) > 2) return false;
    
    let matches = 0;
    for (let i = 0; i < Math.min(query.length, keyword.length); i++) {
      if (query[i] === keyword[i]) matches++;
    }
    
    return matches / Math.max(query.length, keyword.length) > 0.7;
  }

  private generateContextualFallback(query: string): string | null {
    // Generate helpful responses based on query context
    if (query.includes('yellow') || query.includes('yellowing')) {
      return this.knowledgeBase.plant_problems?.responses?.yellow_leaves || null;
    }
    
    if (query.includes('water') || query.includes('watering')) {
      return this.knowledgeBase.watering?.responses?.proper_watering || null;
    }
    
    if (query.includes('pest') || query.includes('bug') || query.includes('insect')) {
      return this.knowledgeBase.pest_control?.responses?.organic_solutions || null;
    }
    
    if (query.includes('soil') || query.includes('dirt')) {
      return this.knowledgeBase.soil_problems?.responses?.clay_soil || null;
    }
    
    if (query.includes('fertilizer') || query.includes('nutrients')) {
      return this.knowledgeBase.fertilizers?.responses?.understanding_npk || null;
    }
    
    return null;
  }

  private generateGeneralResponse(query: string): LocalAIResponse {
    if (this.domain === 'agriculture') {
      // Try to provide contextual help based on the query
      const contextualHelp = this.generateContextualFallback(query.toLowerCase());
      
      if (contextualHelp) {
        return {
          content: `🌱 **Based on your question about "${query}", here's what I can help with:**\n\n${contextualHelp}\n\n**Need more specific help?** Try asking:
• "How do I grow [specific plant]?"
• "What's wrong with my [plant name]?"
• "When should I plant [crop]?"
• "How to treat [specific problem]?"`,
          type: 'success',
          confidence: 0.8
        };
      }

      return {
        content: `🌱 **I'd be happy to help with your agriculture question about "${query}"!**

I can provide **specific, practical solutions** for almost any farming or gardening question. Here's what I specialize in:

**🎯 Specific Plant Guides:**
• **Tomatoes, Peppers, Carrots, Lettuce** - Complete growing guides
• **Any Vegetable or Fruit** - Planting, care, and harvest tips
• **Problem Diagnosis** - Yellowing leaves, diseases, pests

**🔧 Exact Solutions For:**
• **"How to grow tomatoes"** → Complete step-by-step guide
• **"Yellow leaves on my plants"** → Detailed diagnosis & fixes
• **"Best soil for vegetables"** → Specific soil requirements
• **"Organic pest control"** → Proven natural methods
• **"When to plant corn"** → Timing and planting guide

**💡 I provide REAL solutions, not just general advice!**

**Try asking specific questions like:**
• "How do I fix yellow leaves on tomatoes?"
• "Best way to control aphids naturally?"
• "What soil amendments do I need?"
• "Why are my plants not growing?"
• "How to start a vegetable garden?"

**The more specific your question, the more detailed and helpful my answer will be!** 🚜`,
        type: 'suggestion',
        confidence: 0.7
      };
    }

    // For other domains
    const domainInfo = {
      'food-technology': {
        name: 'Food Technology',
        description: 'food processing, preservation, packaging, safety, and quality control'
      },
      'rural-development': {
        name: 'Rural Development',
        description: 'infrastructure development, community projects, and rural economic growth'
      }
    };

    const info = domainInfo[this.domain] || domainInfo['agriculture'];

    return {
      content: `🤔 **I understand you're asking about "${query}"**\n\nAs Terra Tech's ${info.name} specialist, I focus on ${info.description}.\n\n**For better assistance, try asking about:**\n${this.getSampleQuestions().map(q => `• ${q}`).join('\n')}\n\n**Or be more specific about:**\n${this.getRelatedTopics('general').map(t => `• ${t}`).join('\n')}`,
      type: 'suggestion',
      confidence: 0.5
    };
  }

  private getDomainTopics(): string {
    const topics = {
      'agriculture': 'crop management, soil health, pest control, irrigation, and sustainable farming',
      'food-technology': 'food processing, preservation, packaging, safety standards, and quality control',
      'rural-development': 'infrastructure projects, community development, water systems, and rural economics'
    };
    return topics[this.domain] || topics['agriculture'];
  }

  private getSampleQuestions(): string[] {
    const samples = {
      'agriculture': [
        'How to grow tomatoes from seed?',
        'Yellow leaves on my pepper plants - what\'s wrong?',
        'Best organic way to control aphids?',
        'When should I plant carrots in spring?',
        'How often should I water lettuce?',
        'What soil is best for growing vegetables?',
        'How to fix clay soil naturally?',
        'Companion planting for tomatoes?'
      ],
      'food-technology': [
        'What is pasteurization process?',
        'How does HACCP system work?',
        'Best food packaging materials?',
        'How to prevent food contamination?'
      ],
      'rural-development': [
        'How to start a water project?',
        'Rural electrification options?',
        'How to form agricultural cooperatives?',
        'Community infrastructure planning?'
      ]
    };
    return samples[this.domain] || samples['agriculture'];
  }

  private getRelatedTopics(category: string): string[] {
    const topics = {
      'agriculture': ['Specific crop varieties', 'Pest identification', 'Soil improvement methods', 'Irrigation techniques'],
      'food-technology': ['Processing equipment', 'Food safety protocols', 'Packaging solutions', 'Quality testing'],
      'rural-development': ['Project funding sources', 'Community engagement', 'Technology solutions', 'Sustainability planning'],
      'general': this.getSampleQuestions()
    };
    
    return topics[this.domain] || topics[category] || topics['general'];
  }

  // For image analysis (placeholder for future enhancement)
  analyzeImages(images: any[]): string {
    if (images.length === 0) return '';
    
    return `\n\n📸 **Image Analysis:** I can see you've uploaded ${images.length} image(s). While I can't process images yet, you can describe what you see and I'll provide relevant advice based on your description.`;
  }
}

// Utility functions
export const createLocalAI = (domain: 'agriculture' | 'food-technology' | 'rural-development') => {
  return new LocalAISystem(domain);
};

export const formatResponse = (response: string): string => {
  return response
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/•/g, '•')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>')
    .replace(/^/, '<p>')
    .replace(/$/, '</p>')
    .replace(/<p><\/p>/g, '')
    .replace(/<p>(<br>)/g, '<p>')
    .replace(/(<br>)<\/p>/g, '</p>');
};

export const simulateTypingDelay = (text: string): number => {
  // Simulate human-like typing speed (40-60 words per minute)
  const words = text.split(' ').length;
  const wpm = 50; // words per minute
  const baseDelay = (words / wpm) * 60 * 1000; // milliseconds
  return Math.min(Math.max(baseDelay, 500), 3000); // Between 0.5-3 seconds
};