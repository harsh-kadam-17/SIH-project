// OpenAI Configuration and Types
// This file contains shared types and utilities for OpenAI integration

export interface OpenAIConfig {
  apiKey: string;
  model: string;
  maxTokens: number;
  temperature: number;
}

export const DEFAULT_CONFIG: Partial<OpenAIConfig> = {
  model: 'gpt-4o-mini',
  maxTokens: 1000,
  temperature: 0.7
};

export const OPENAI_MODELS = {
  'gpt-4o-mini': 'GPT-4o Mini (Recommended)',
  'gpt-4o': 'GPT-4o (Premium)',
  'gpt-3.5-turbo': 'GPT-3.5 Turbo (Basic)'
} as const;

export type OpenAIModel = keyof typeof OPENAI_MODELS;