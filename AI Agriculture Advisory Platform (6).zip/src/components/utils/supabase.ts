import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const supabaseKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Database Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'farmer' | 'consultant' | 'admin';
  location?: string;
  farm_size?: number;
  primary_crops?: string[];
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  domain: 'agriculture' | 'food-technology' | 'rural-development';
  title: string;
  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  type: 'user' | 'bot';
  content: string;
  tokens_used?: number;
  created_at: string;
}

export interface UserPreferences {
  id: string;
  user_id: string;
  preferred_units: 'metric' | 'imperial';
  notification_settings: any;
  ai_model_preference: string;
  created_at: string;
}

// Auth Helper Functions
export const authHelpers = {
  async signUp(email: string, password: string, userData: Partial<User>) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: userData
      }
    });
    return { data, error };
  },

  async signIn(email: string, password: string) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    return { data, error };
  },

  async signOut() {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  async getCurrentUser() {
    const { data: { user } } = await supabase.auth.getUser();
    return user;
  },

  onAuthStateChange(callback: (event: string, session: any) => void) {
    return supabase.auth.onAuthStateChange(callback);
  }
};

// Database Helper Functions
export const dbHelpers = {
  // User Profile Management
  async createUserProfile(userId: string, profileData: Partial<User>) {
    const { data, error } = await supabase
      .from('users')
      .insert([{ id: userId, ...profileData }])
      .select();
    return { data, error };
  },

  async getUserProfile(userId: string) {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    return { data, error };
  },

  async updateUserProfile(userId: string, updates: Partial<User>) {
    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', userId)
      .select();
    return { data, error };
  },

  // Conversation Management
  async createConversation(userId: string, domain: string, title: string) {
    const { data, error } = await supabase
      .from('conversations')
      .insert([{ user_id: userId, domain, title }])
      .select();
    return { data, error };
  },

  async getUserConversations(userId: string) {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });
    return { data, error };
  },

  async getConversationMessages(conversationId: string) {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });
    return { data, error };
  },

  async saveMessage(conversationId: string, type: 'user' | 'bot', content: string, tokensUsed?: number) {
    const { data, error } = await supabase
      .from('messages')
      .insert([{ 
        conversation_id: conversationId, 
        type, 
        content, 
        tokens_used: tokensUsed 
      }])
      .select();
    return { data, error };
  },

  // User Preferences
  async getUserPreferences(userId: string) {
    const { data, error } = await supabase
      .from('user_preferences')
      .select('*')
      .eq('user_id', userId)
      .single();
    return { data, error };
  },

  async updateUserPreferences(userId: string, preferences: Partial<UserPreferences>) {
    const { data, error } = await supabase
      .from('user_preferences')
      .upsert([{ user_id: userId, ...preferences }])
      .select();
    return { data, error };
  },

  // Analytics
  async trackUsage(userId: string, domain: string, queryType: string, tokensUsed: number, responseTime: number) {
    const { data, error } = await supabase
      .from('usage_analytics')
      .insert([{
        user_id: userId,
        domain,
        query_type: queryType,
        tokens_used: tokensUsed,
        response_time_ms: responseTime
      }]);
    return { data, error };
  }
};