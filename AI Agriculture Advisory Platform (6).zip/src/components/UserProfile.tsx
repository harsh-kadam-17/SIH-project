import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import {
  User,
  MapPin,
  Briefcase,
  Calendar,
  TrendingUp,
  Award,
  Settings,
  Edit,
  Save,
  X,
  Tractor,
  FlaskConical,
  Users,
  MessageCircle,
  Clock,
  Star,
  Leaf
} from 'lucide-react';

interface UserProfileProps {
  user: {
    email: string;
    name: string;
    id: number;
  };
}

export function UserProfile({ user }: UserProfileProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user.name,
    email: user.email,
    location: 'California, USA',
    occupation: 'Sustainable Farmer',
    farmSize: '50 acres',
    primaryCrops: ['Tomatoes', 'Lettuce', 'Peppers'],
    experience: '8 years',
    bio: 'Passionate about sustainable farming practices and leveraging technology to improve crop yields while maintaining environmental responsibility.',
    phone: '+1 (555) 123-4567',
    farmingType: 'Organic'
  });

  // Simulate user activity data
  const activityStats = {
    consultationsTotal: 47,
    consultationsThisMonth: 12,
    avgResponseTime: '2.3 minutes',
    satisfactionRating: 4.8,
    aiInteractions: 156,
    problemsSolved: 34
  };

  const recentActivities = [
    {
      type: 'agriculture',
      title: 'Consulted about tomato blight',
      time: '2 hours ago',
      result: 'Problem solved'
    },
    {
      type: 'food-technology',
      title: 'Food preservation techniques',
      time: '1 day ago',
      result: 'Implemented solution'
    },
    {
      type: 'rural-development',
      title: 'Community irrigation project',
      time: '3 days ago',
      result: 'In progress'
    }
  ];

  const expertiseAreas = [
    { name: 'Crop Management', level: 85, color: 'bg-green-500' },
    { name: 'Soil Health', level: 92, color: 'bg-emerald-500' },
    { name: 'Pest Control', level: 78, color: 'bg-blue-500' },
    { name: 'Irrigation', level: 88, color: 'bg-cyan-500' },
    { name: 'Organic Farming', level: 95, color: 'bg-lime-500' }
  ];

  const handleSave = () => {
    // Here you would typically save to backend/database
    setIsEditing(false);
    // Show success toast
  };

  const handleCancel = () => {
    // Reset form data
    setIsEditing(false);
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'agriculture':
        return <Tractor className="w-4 h-4 text-green-600" />;
      case 'food-technology':
        return <FlaskConical className="w-4 h-4 text-blue-600" />;
      case 'rural-development':
        return <Users className="w-4 h-4 text-purple-600" />;
      default:
        return <MessageCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getResultBadge = (result: string) => {
    const variants: { [key: string]: string } = {
      'Problem solved': 'bg-green-100 text-green-800',
      'Implemented solution': 'bg-blue-100 text-blue-800',
      'In progress': 'bg-yellow-100 text-yellow-800'
    };
    
    return (
      <Badge className={`${variants[result] || 'bg-gray-100 text-gray-800'} text-xs`}>
        {result}
      </Badge>
    );
  };

  return (
    <div className="w-full max-w-7xl mx-auto p-6 space-y-6">
      {/* Profile Header */}
      <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-0 shadow-lg">
        <CardContent className="p-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center gap-6">
            <div className="flex items-center gap-6">
              <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                <AvatarFallback className="bg-green-600 text-white text-2xl font-bold">
                  {profileData.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <h1 className="text-3xl font-bold text-gray-900">{profileData.name}</h1>
                  <Badge className="bg-green-100 text-green-800">
                    <Leaf className="w-3 h-3 mr-1" />
                    Verified Farmer
                  </Badge>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-gray-600">
                  <div className="flex items-center gap-1">
                    <Briefcase className="w-4 h-4" />
                    <span>{profileData.occupation}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    <span>{profileData.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{profileData.experience} experience</span>
                  </div>
                </div>
                
                <p className="text-gray-700 max-w-2xl leading-relaxed">
                  {profileData.bio}
                </p>
              </div>
            </div>
            
            <div className="ml-auto">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    Edit Profile
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Edit Profile</DialogTitle>
                    <DialogDescription>
                      Update your profile information and farming details
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-6 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          value={profileData.location}
                          onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="farmSize">Farm Size</Label>
                        <Input
                          id="farmSize"
                          value={profileData.farmSize}
                          onChange={(e) => setProfileData({ ...profileData, farmSize: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="experience">Experience</Label>
                        <Input
                          id="experience"
                          value={profileData.experience}
                          onChange={(e) => setProfileData({ ...profileData, experience: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="farmingType">Farming Type</Label>
                        <Select value={profileData.farmingType} onValueChange={(value) => setProfileData({ ...profileData, farmingType: value })}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Organic">Organic</SelectItem>
                            <SelectItem value="Conventional">Conventional</SelectItem>
                            <SelectItem value="Sustainable">Sustainable</SelectItem>
                            <SelectItem value="Precision">Precision Agriculture</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={profileData.bio}
                        onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                        rows={3}
                      />
                    </div>
                    
                    <div className="flex justify-end gap-3">
                      <Button variant="outline" onClick={handleCancel}>
                        <X className="w-4 h-4 mr-2" />
                        Cancel
                      </Button>
                      <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                        <Save className="w-4 h-4 mr-2" />
                        Save Changes
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Consultations</p>
                <p className="text-2xl font-bold text-gray-900">{activityStats.consultationsTotal}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-green-600">+{activityStats.consultationsThisMonth} this month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Response Time</p>
                <p className="text-2xl font-bold text-gray-900">{activityStats.avgResponseTime}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-blue-600">Lightning fast support</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Satisfaction Rating</p>
                <p className="text-2xl font-bold text-gray-900">{activityStats.satisfactionRating}/5</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Star className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-yellow-600">Excellent service</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Problems Solved</p>
                <p className="text-2xl font-bold text-gray-900">{activityStats.problemsSolved}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Award className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-2">
              <span className="text-sm text-purple-600">Success rate: 97%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Farm Information */}
        <Card className="lg:col-span-1 border-0 shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tractor className="w-5 h-5 text-green-600" />
              Farm Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-600">Farm Size</p>
                <p className="font-semibold">{profileData.farmSize}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Farming Type</p>
                <p className="font-semibold">{profileData.farmingType}</p>
              </div>
            </div>
            
            <Separator />
            
            <div>
              <p className="text-sm text-gray-600 mb-2">Primary Crops</p>
              <div className="flex flex-wrap gap-2">
                {profileData.primaryCrops.map((crop, index) => (
                  <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                    {crop}
                  </Badge>
                ))}
              </div>
            </div>
            
            <Separator />
            
            <div>
              <p className="text-sm text-gray-600 mb-3">Expertise Levels</p>
              <div className="space-y-3">
                {expertiseAreas.map((area, index) => (
                  <div key={index}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-700">{area.name}</span>
                      <span className="text-gray-500">{area.level}%</span>
                    </div>
                    <Progress value={area.level} className="h-2" />
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="lg:col-span-2 border-0 shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {getActivityIcon(activity.type)}
                    <div>
                      <p className="font-medium text-gray-900">{activity.title}</p>
                      <p className="text-sm text-gray-600">{activity.time}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {getResultBadge(activity.result)}
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Performance Insights</h4>
                  <p className="text-sm text-gray-600">
                    Your consultation success rate has improved by 15% this month. Keep up the great work!
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}