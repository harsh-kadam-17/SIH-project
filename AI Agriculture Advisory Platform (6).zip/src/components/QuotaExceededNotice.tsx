import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  AlertTriangle, 
  CreditCard, 
  RefreshCw, 
  Phone, 
  Mail, 
  Clock,
  CheckCircle,
  ExternalLink
} from 'lucide-react';

interface QuotaExceededNoticeProps {
  onRetry?: () => void;
  isRetrying?: boolean;
  context?: 'agriculture' | 'food-technology' | 'rural-development';
}

export function QuotaExceededNotice({ 
  onRetry, 
  isRetrying = false, 
  context = 'agriculture' 
}: QuotaExceededNoticeProps) {
  const contextInfo = {
    'agriculture': {
      name: 'Agriculture',
      icon: '🌱',
      description: 'crop diagnosis, farming advice, and agricultural solutions'
    },
    'food-technology': {
      name: 'Food Technology',
      icon: '🧪',
      description: 'food processing, safety, and quality control guidance'
    },
    'rural-development': {
      name: 'Rural Development',
      icon: '🏘️',
      description: 'community development and infrastructure planning'
    }
  };

  const info = contextInfo[context];

  return (
    <Card className="border-orange-200 bg-gradient-to-r from-orange-50 to-yellow-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-800">
          <AlertTriangle className="w-6 h-6" />
          AI Service Temporarily Limited
          <Badge variant="secondary" className="bg-orange-100 text-orange-800">
            Quota Exceeded
          </Badge>
        </CardTitle>
        <CardDescription>
          Terra Tech's AI service has reached its daily usage limit. Here's what you can do:
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Current Status
            </h4>
            <div className="text-sm space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span>AI Vision Analysis: Limited</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <span>Expert AI Responses: Limited</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Basic Resources: Available</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <RefreshCw className="w-5 h-5 text-green-600" />
              Expected Resolution
            </h4>
            <div className="text-sm space-y-2">
              <p>• Service will automatically resume</p>
              <p>• Usually within 1-24 hours</p>
              <p>• No action required from you</p>
            </div>
          </div>
        </div>

        {/* Alternative Solutions */}
        <div className="border-t pt-6">
          <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            What You Can Do Right Now
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                  <span className="text-blue-600 font-bold text-sm">1</span>
                </div>
                <div>
                  <h5 className="font-semibold text-blue-900">Try Again Later</h5>
                  <p className="text-sm text-blue-700">Our quota resets automatically. Try your question again in a few hours.</p>
                  {onRetry && (
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="mt-2 border-blue-300 text-blue-700 hover:bg-blue-100"
                      onClick={onRetry}
                      disabled={isRetrying}
                    >
                      {isRetrying ? (
                        <>
                          <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                          Checking...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-3 h-3 mr-1" />
                          Try Again Now
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mt-1">
                  <span className="text-green-600 font-bold text-sm">2</span>
                </div>
                <div>
                  <h5 className="font-semibold text-green-900">Browse Resources</h5>
                  <p className="text-sm text-green-700">Access our extensive library of {info.description} guides and articles.</p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="mt-2 border-green-300 text-green-700 hover:bg-green-100"
                  >
                    <ExternalLink className="w-3 h-3 mr-1" />
                    View Resources
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mt-1">
                  <span className="text-purple-600 font-bold text-sm">3</span>
                </div>
                <div>
                  <h5 className="font-semibold text-purple-900">Contact Expert Support</h5>
                  <p className="text-sm text-purple-700">Speak directly with our human {info.name.toLowerCase()} experts.</p>
                  <div className="flex gap-2 mt-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-purple-300 text-purple-700 hover:bg-purple-100"
                    >
                      <Phone className="w-3 h-3 mr-1" />
                      Call
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-purple-300 text-purple-700 hover:bg-purple-100"
                    >
                      <Mail className="w-3 h-3 mr-1" />
                      Email
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 bg-yellow-50 rounded-lg">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center mt-1">
                  <span className="text-yellow-600 font-bold text-sm">4</span>
                </div>
                <div>
                  <h5 className="font-semibold text-yellow-900">Submit Your Question</h5>
                  <p className="text-sm text-yellow-700">Email your question and get a detailed response within 24 hours.</p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="mt-2 border-yellow-300 text-yellow-700 hover:bg-yellow-100"
                  >
                    <Mail className="w-3 h-3 mr-1" />
                    Submit Question
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Details */}
        <div className="border-t pt-6">
          <details className="group">
            <summary className="flex items-center gap-2 cursor-pointer text-sm font-medium text-gray-600 hover:text-gray-900">
              <div className="transform group-open:rotate-90 transition-transform">▶</div>
              Technical Details
            </summary>
            <div className="mt-3 pl-6 text-sm text-gray-600 space-y-2">
              <p><strong>Error Type:</strong> OpenAI API Quota Exceeded (HTTP 429)</p>
              <p><strong>Service:</strong> Terra Tech Centralized AI System</p>
              <p><strong>Impact:</strong> Temporary limitation on AI-powered responses</p>
              <p><strong>Resolution:</strong> Automatic quota reset (typically within 24 hours)</p>
              <p><strong>Reference:</strong> <a href="https://platform.openai.com/docs/guides/error-codes" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">OpenAI Error Codes Documentation</a></p>
            </div>
          </details>
        </div>

        {/* Assurance Message */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-600 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-green-800 mb-1">Terra Tech Commitment</h4>
              <p className="text-sm text-green-700">
                We're committed to providing you with the best {info.description}. This temporary limitation 
                doesn't affect your access to our platform, resources, or expert support. Our AI service will 
                resume automatically, and we're working to prevent future interruptions.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}