import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Key, Eye, EyeOff, ExternalLink, Shield, Check, X, AlertCircle } from 'lucide-react';

interface ApiKeyManagerProps {
  onApiKeyChange?: (hasKey: boolean) => void;
}

export function ApiKeyManager({ onApiKeyChange }: ApiKeyManagerProps) {
  const [apiKey, setApiKey] = useState('');
  const [storedKey, setStoredKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<'valid' | 'invalid' | null>(null);

  useEffect(() => {
    const savedKey = localStorage.getItem('openai_api_key');
    if (savedKey) {
      setStoredKey(savedKey);
      setApiKey(savedKey);
      onApiKeyChange?.(true);
    }
  }, [onApiKeyChange]);

  const validateApiKey = async (key: string): Promise<boolean> => {
    if (!key.trim()) return false;
    
    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${key}`,
        },
      });
      
      return response.ok;
    } catch (error) {
      return false;
    }
  };

  const handleSaveKey = async () => {
    if (!apiKey.trim()) return;
    
    setIsValidating(true);
    setValidationResult(null);
    
    const isValid = await validateApiKey(apiKey);
    
    if (isValid) {
      localStorage.setItem('openai_api_key', apiKey);
      setStoredKey(apiKey);
      setValidationResult('valid');
      onApiKeyChange?.(true);
      
      setTimeout(() => {
        setIsOpen(false);
        setValidationResult(null);
      }, 1500);
    } else {
      setValidationResult('invalid');
    }
    
    setIsValidating(false);
  };

  const handleRemoveKey = () => {
    localStorage.removeItem('openai_api_key');
    setStoredKey('');
    setApiKey('');
    setValidationResult(null);
    onApiKeyChange?.(false);
    setIsOpen(false);
  };

  const maskedKey = storedKey ? `sk-...${storedKey.slice(-4)}` : '';

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="flex items-center gap-2"
        >
          <Key className="w-4 h-4" />
          {storedKey ? (
            <>
              <Check className="w-3 h-3 text-green-500" />
              <span className="hidden sm:inline">API Key Set</span>
              <span className="sm:hidden">Key Set</span>
            </>
          ) : (
            <>
              <span className="hidden sm:inline">Set API Key</span>
              <span className="sm:hidden">API Key</span>
            </>
          )}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="w-5 h-5" />
            OpenAI API Key
          </DialogTitle>
          <DialogDescription>
            Configure your OpenAI API key to enable AI assistance
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Current Status */}
          {storedKey && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">Current Key</p>
                    <p className="text-xs text-muted-foreground">{maskedKey}</p>
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-700">
                    <Check className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* API Key Input */}
          <div className="space-y-2">
            <Label htmlFor="api-key">OpenAI API Key</Label>
            <div className="relative">
              <Input
                id="api-key"
                type={showKey ? "text" : "password"}
                placeholder="sk-..."
                value={apiKey}
                onChange={(e) => {
                  setApiKey(e.target.value);
                  setValidationResult(null);
                }}
                className="pr-10"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3"
                onClick={() => setShowKey(!showKey)}
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Validation Result */}
          {validationResult === 'valid' && (
            <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg border border-green-200">
              <Check className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-700">Valid API key! Saving...</span>
            </div>
          )}
          
          {validationResult === 'invalid' && (
            <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg border border-red-200">
              <X className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-700">Invalid API key. Please check and try again.</span>
            </div>
          )}

          {/* Instructions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Shield className="w-4 h-4" />
                How to get your API key
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              <div className="text-sm space-y-2">
                <p><strong>1.</strong> Go to OpenAI Platform</p>
                <p><strong>2.</strong> Sign in or create account</p>
                <p><strong>3.</strong> Navigate to API Keys</p>
                <p><strong>4.</strong> Create new secret key</p>
                <p><strong>5.</strong> Copy and paste here</p>
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => window.open('https://platform.openai.com/api-keys', '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open OpenAI Platform
              </Button>
            </CardContent>
          </Card>

          {/* Privacy Notice */}
          <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-700">
              <strong>Privacy:</strong> Your API key is stored locally in your browser and never sent to Terra Tech servers.
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button 
              onClick={handleSaveKey}
              disabled={!apiKey.trim() || isValidating}
              className="flex-1"
            >
              {isValidating ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Validating...
                </div>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  {storedKey ? 'Update Key' : 'Save Key'}
                </>
              )}
            </Button>
            
            {storedKey && (
              <Button 
                variant="destructive" 
                onClick={handleRemoveKey}
                className="flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}