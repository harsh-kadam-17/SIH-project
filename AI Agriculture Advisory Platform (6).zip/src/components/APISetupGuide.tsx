// DEPRECATED: This component is no longer needed
// The chatbot now uses a local AI system instead of OpenAI API
// No setup required - everything works offline and instantly

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { CheckCircle, Zap } from 'lucide-react';

export function APISetupGuide() {
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-green-600" />
          <CardTitle>Setup Complete!</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-2 text-green-600">
          <CheckCircle className="w-4 h-4" />
          <p>Terra Tech now uses a local AI system - no API key needed!</p>
        </div>
        <p className="text-sm text-gray-600 mt-2">
          The chatbot works instantly without any external dependencies.
        </p>
      </CardContent>
    </Card>
  );
}