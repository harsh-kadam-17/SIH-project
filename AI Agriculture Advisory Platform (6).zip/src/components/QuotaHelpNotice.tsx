import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { ExternalLink, CreditCard, Brain, CheckCircle, AlertTriangle } from 'lucide-react';

interface QuotaHelpNoticeProps {
  onClose: () => void;
}

export function QuotaHelpNotice({ onClose }: QuotaHelpNoticeProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="max-w-md w-full max-h-[90vh] overflow-y-auto">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            OpenAI Quota Exceeded
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <Alert>
            <Brain className="w-4 h-4" />
            <AlertDescription>
              <strong>Good news!</strong> Terra Tech automatically switched to our local knowledge base. 
              You can continue getting agricultural advice right now.
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <h3 className="font-medium flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              To restore full OpenAI capabilities:
            </h3>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <strong>Upgrade your OpenAI plan:</strong> Add billing details and credits at OpenAI Platform
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <strong>Wait for reset:</strong> Free tier quotas reset monthly
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <div>
                  <strong>Use different API key:</strong> If you have another OpenAI account
                </div>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 p-3 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">What you get with local mode:</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Comprehensive agricultural knowledge base</li>
              <li>• Specific, actionable farming solutions</li>
              <li>• Expert advice for crops, soil, pests, and more</li>
              <li>• Works completely offline</li>
            </ul>
          </div>

          <div className="bg-amber-50 p-3 rounded-lg">
            <h4 className="font-medium text-amber-900 mb-2">OpenAI features not available:</h4>
            <ul className="text-sm text-amber-800 space-y-1">
              <li>• Image analysis and plant disease identification</li>
              <li>• Conversational AI responses</li>
              <li>• Latest research and dynamic updates</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={() => window.open('https://platform.openai.com/settings/billing', '_blank')}
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              OpenAI Billing
            </Button>
            <Button variant="outline" onClick={onClose} className="flex-1">
              Continue with Local AI
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}