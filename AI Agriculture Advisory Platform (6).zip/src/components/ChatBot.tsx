import React, { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";
// API key is now managed centrally by Terra Tech
import { 
  createOpenAI, 
  formatResponse, 
  simulateTypingDelay,
  type OpenAIMessage,
  type OpenAIResponse 
} from "./utils/openai-ai-system";
import { LocalAISystem } from "./utils/local-ai-system";
import {
  MessageCircle,
  X,
  Send,
  Upload,
  Loader2,
  Bot,
  User,
  AlertCircle,
  Zap,
  CheckCircle,
  ImageIcon,
  Brain
} from "lucide-react";

interface ChatBotProps {
  context: 'agriculture' | 'food-technology' | 'rural-development';
}

export function ChatBot({ context }: ChatBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<OpenAIMessage[]>([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImages, setSelectedImages] = useState<Array<{ dataUrl: string; name: string }>>([]);
  const [usingLocalAI, setUsingLocalAI] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const openAI = useRef(createOpenAI(context));
  const localAI = useRef(new LocalAISystem(context));

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  // API key is now centrally managed by Terra Tech - no user setup required

  // Initialize with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      const initializeWelcome = async () => {
        let welcomeResponse;
        if (openAI.current.hasApiKey()) {
          try {
            welcomeResponse = await openAI.current.generateResponse("");
          } catch (error) {
            welcomeResponse = localAI.current.generateResponse("");
            setUsingLocalAI(true);
          }
        } else {
          welcomeResponse = localAI.current.generateResponse("");
          setUsingLocalAI(true);
        }
        
        const welcomeMessage: OpenAIMessage = {
          id: Date.now(),
          type: "bot",
          content: welcomeResponse.content,
          timestamp: new Date(),
        };
        setMessages([welcomeMessage]);
      };
      initializeWelcome();
    }
  }, [messages.length]);

  // API key management is now handled centrally by Terra Tech

  const handleSendMessage = async () => {
    if (!inputText.trim() && selectedImages.length === 0) return;

    // Add user message
    const userMessage: OpenAIMessage = {
      id: Date.now(),
      type: "user",
      content: inputText || "📸 Uploaded images for analysis",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Show immediate typing feedback
    await new Promise(resolve => setTimeout(resolve, 300));

    try {
      let aiResponse: OpenAIResponse;
      let finalContent: string;
      let usedFallback = false;

      // Try Terra Tech AI first if available
      if (openAI.current.hasApiKey() && !usingLocalAI) {
        try {
          aiResponse = await openAI.current.generateResponse(inputText, selectedImages);
          
          // Check if this was a quota exceeded response
          if (aiResponse.content.includes("Quota Exceeded") || aiResponse.content.includes("insufficient_quota")) {
            // Switch to local AI for this and future requests
            setUsingLocalAI(true);
            aiResponse = localAI.current.generateResponse(inputText, selectedImages);
            usedFallback = true;
          }
          
          finalContent = aiResponse.content;
          
          // Add image analysis if images were uploaded and OpenAI was used successfully
          if (selectedImages.length > 0 && !usedFallback) {
            finalContent += openAI.current.analyzeImages(selectedImages);
          }
        } catch (error) {
          // If OpenAI fails, try local AI as fallback
          console.log('OpenAI failed, using local AI fallback:', error);
          aiResponse = localAI.current.generateResponse(inputText, selectedImages);
          finalContent = aiResponse.content;
          usedFallback = true;
          setUsingLocalAI(true);
        }
      } else {
        // Use local AI system
        aiResponse = localAI.current.generateResponse(inputText, selectedImages);
        finalContent = aiResponse.content;
        usedFallback = true;
      }

      // Add local AI notice if using fallback
      if (usedFallback && !finalContent.includes("Local Knowledge Base")) {
        finalContent += `\n\n🔄 **Powered by Terra Tech Local Knowledge Base**\nFor full AI capabilities including image analysis, please upgrade your OpenAI plan.`;
      }

      // Simulate realistic response time for better UX
      const typingDelay = simulateTypingDelay(finalContent);
      await new Promise(resolve => setTimeout(resolve, Math.min(typingDelay, 2000)));

      const botMessage: OpenAIMessage = {
        id: Date.now() + 1,
        type: "bot",
        content: finalContent,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      
    } catch (error) {
      console.error('AI Response Error:', error);
      const errorMessage: OpenAIMessage = {
        id: Date.now() + 1,
        type: "bot",
        content: `⚠️ **Error Processing Request**\n\nI encountered an issue processing your request. This could be due to:\n\n• Network connectivity problems\n• OpenAI API service issues\n• Invalid or expired API key\n\n**Please try:**\n• Checking your internet connection\n• Verifying your API key is valid\n• Trying again in a moment\n\nI apologize for the inconvenience!`,
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
      setInputText("");
      setSelectedImages([]);
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const dataUrl = e.target?.result as string;
          setSelectedImages(prev => [...prev, { dataUrl, name: file.name }]);
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const clearChat = async () => {
    setMessages([]);
    setUsingLocalAI(false); // Reset to try OpenAI again
    openAI.current.clearConversation();
    
    // Re-initialize with welcome message
    let welcomeResponse;
    if (hasApiKey) {
      welcomeResponse = await openAI.current.generateResponse("");
    } else {
      welcomeResponse = localAI.current.generateResponse("");
      setUsingLocalAI(true);
    }
    
    const welcomeMessage: OpenAIMessage = {
      id: Date.now(),
      type: "bot",
      content: welcomeResponse.content,
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
  };

  const getContextInfo = () => {
    const contexts = {
      'agriculture': { name: 'Agriculture', icon: '🌱', color: 'bg-green-600' },
      'food-technology': { name: 'Food Technology', icon: '🧪', color: 'bg-blue-600' },
      'rural-development': { name: 'Rural Development', icon: '🏘️', color: 'bg-purple-600' }
    };
    return contexts[context] || contexts['agriculture'];
  };

  const contextInfo = getContextInfo();

  if (!isOpen) {
    return (
      <div className="fixed bottom-4 right-4 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className={`${contextInfo.color} hover:opacity-90 text-white shadow-lg rounded-full w-14 h-14 p-0`}
          title={`${contextInfo.name} AI Assistant`}
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 w-96 max-w-[calc(100vw-2rem)]">
      <Card className="shadow-2xl border-0 h-[500px] flex flex-col overflow-hidden">
        <CardHeader className={`${contextInfo.color} text-white rounded-t-lg p-3 flex-shrink-0`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-lg">{contextInfo.icon}</span>
              <div>
                <CardTitle className="text-sm">Terra Tech AI</CardTitle>
                <p className="text-xs opacity-90">{contextInfo.name} Assistant</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-white/20 text-white border-0">
                <Brain className="w-3 h-3 mr-1" />
                {usingLocalAI ? "Local AI" : "OpenAI"}
              </Badge>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20 h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 min-h-0 overflow-hidden">
          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-2 ${
                  message.type === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.type === "bot" && (
                  <div className={`${contextInfo.color} rounded-full p-1.5 text-white flex-shrink-0 h-8 w-8 flex items-center justify-center`}>
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                
                <div
                  className={`max-w-[85%] rounded-lg p-3 overflow-hidden ${
                    message.type === "user"
                      ? "bg-gray-100 text-gray-900"
                      : "bg-white border border-gray-200"
                  }`}
                >
                  <div 
                    className="text-sm break-words overflow-wrap-anywhere max-w-none [&>strong]:font-semibold [&>strong]:text-gray-900 [&>em]:italic [&>em]:text-gray-700 [&>ul]:list-disc [&>ul]:ml-4 [&>li]:mb-1 [&>p]:mb-2 [&>p:last-child]:mb-0 [&>br]:block"
                    dangerouslySetInnerHTML={{ 
                      __html: formatResponse(message.content) 
                    }}
                  />
                  <div className="text-xs text-gray-400 mt-1">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
                
                {message.type === "user" && (
                  <div className="bg-gray-600 rounded-full p-1.5 text-white flex-shrink-0 h-8 w-8 flex items-center justify-center">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-2 justify-start">
                <div className={`${contextInfo.color} rounded-full p-1.5 text-white flex-shrink-0 h-8 w-8 flex items-center justify-center`}>
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-white border border-gray-200 rounded-lg p-3">
                  <div className="flex items-center gap-1">
                    <Loader2 className="w-4 h-4 animate-spin text-gray-500" />
                    <span className="text-sm text-gray-500">AI is thinking...</span>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {/* Image Preview Area */}
          {selectedImages.length > 0 && (
            <div className="border-t p-2 bg-gray-50 flex-shrink-0">
              <div className="flex flex-wrap gap-2 overflow-x-auto">
                {selectedImages.map((image, index) => (
                  <div key={index} className="relative flex-shrink-0">
                    <img
                      src={image.dataUrl}
                      alt={image.name}
                      className="w-16 h-16 object-cover rounded border"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute -top-1 -right-1 h-5 w-5 p-0 rounded-full"
                      onClick={() => removeImage(index)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Input Area */}
          <div className="border-t p-3 bg-white flex-shrink-0">
            <div className="flex gap-2">
              <div className="flex-1">
                <Textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Ask about ${contextInfo.name.toLowerCase()}...`}
                  className="min-h-[40px] max-h-[120px] resize-none border-gray-200 w-full"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                />
              </div>
              <div className="flex flex-col gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-8 w-8 p-0"
                  title="Upload images"
                >
                  <ImageIcon className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputText.trim() && selectedImages.length === 0}
                  className={`${contextInfo.color} hover:opacity-90 h-8 w-8 p-0`}
                  title="Send message"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
              <div className="flex items-center gap-2">
                {usingLocalAI ? (
                  <>
                    <Brain className="w-3 h-3 text-blue-500" />
                    <span>Local Knowledge Base • Offline AI</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-3 h-3 text-green-500" />
                    <span>Terra Tech AI • OpenAI GPT-4</span>
                  </>
                )}
              </div>
              <div className="flex items-center gap-2">
                {usingLocalAI && openAI.current.hasApiKey() && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setUsingLocalAI(false);
                      clearChat();
                    }}
                    className="text-xs h-6 px-2"
                    title="Try Terra Tech AI again"
                  >
                    <Zap className="w-3 h-3 mr-1" />
                    Retry OpenAI
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearChat}
                  className="text-xs h-6 px-2"
                >
                  Clear Chat
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleImageUpload}
        className="hidden"
      />
    </div>
  );
}