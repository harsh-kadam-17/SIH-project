import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  ExternalLink, 
  CreditCard, 
  CheckCircle, 
  AlertTriangle, 
  DollarSign,
  Clock,
  Key,
  Zap
} from 'lucide-react';

export function APIKeyUpgradeGuide() {
  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <Card className="border-2 border-amber-200 bg-amber-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-900">
            <AlertTriangle className="w-5 h-5" />
            OpenAI API Quota Exceeded
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <CheckCircle className="w-4 h-4 text-green-600" />
            <AlertDescription className="text-green-800">
              <strong>Terra Tech is still working!</strong> We've automatically switched to our local knowledge base 
              so you can continue getting agricultural advice right now.
            </AlertDescription>
          </Alert>

          <div className="bg-white/70 rounded-lg p-4">
            <h3 className="font-semibold mb-3 flex items-center gap-2 text-gray-900">
              <Zap className="w-4 h-4" />
              How to Restore Full AI Capabilities
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-1">
                  <CreditCard className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">1. Upgrade Your OpenAI Plan</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Add billing details and purchase credits at OpenAI Platform. 
                    Plans start at $5 for 1M tokens.
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => window.open('https://platform.openai.com/settings/billing', '_blank')}
                  >
                    <ExternalLink className="w-3 h-3 mr-1" />
                    Open OpenAI Billing
                  </Button>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <Clock className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">2. Wait for Monthly Reset</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    Free tier users get $5 worth of credits each month. 
                    Your quota resets on your account anniversary date.
                  </p>
                  <Badge variant="secondary" className="mt-2">
                    <Clock className="w-3 h-3 mr-1" />
                    Free tier resets monthly
                  </Badge>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-full p-1 mt-1">
                  <Key className="w-4 h-4 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">3. Use Different API Key</h4>
                  <p className="text-sm text-gray-600 mt-1">
                    If you have another OpenAI account with available credits, 
                    you can update your API key in Terra Tech.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-medium text-green-900 mb-2 flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Local Mode Features
              </h4>
              <ul className="text-sm text-green-800 space-y-1">
                <li>• Comprehensive agricultural database</li>
                <li>• Specific farming solutions</li>
                <li>• Crop, soil, and pest guidance</li>
                <li>• Weather and seasonal advice</li>
                <li>• Works offline</li>
              </ul>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <h4 className="font-medium text-amber-900 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                Missing in Local Mode
              </h4>
              <ul className="text-sm text-amber-800 space-y-1">
                <li>• Image analysis & plant ID</li>
                <li>• Disease identification from photos</li>
                <li>• Conversational AI responses</li>
                <li>• Latest research updates</li>
                <li>• Dynamic problem solving</li>
              </ul>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              OpenAI Pricing Guide
            </h4>
            <div className="text-sm text-blue-800 space-y-1">
              <p><strong>GPT-4o:</strong> $5.00 per 1M input tokens, $15.00 per 1M output tokens</p>
              <p><strong>GPT-4o Mini:</strong> $0.15 per 1M input tokens, $0.60 per 1M output tokens</p>
              <p><strong>Typical Usage:</strong> $5-10/month covers hundreds of agricultural consultations</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}