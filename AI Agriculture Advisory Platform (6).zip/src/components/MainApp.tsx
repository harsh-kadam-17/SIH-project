import React, { useState } from 'react';
import { Header } from './Header';
import { HomePage } from './pages/HomePage';
import { AgriculturePage } from './pages/AgriculturePage';
import { FoodTechnologyPage } from './pages/FoodTechnologyPage';
import { RuralDevelopmentPage } from './pages/RuralDevelopmentPage';
import { ResourcesPage } from './pages/ResourcesPage';
import { FAQPage } from './pages/FAQPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { ProfilePage } from './pages/ProfilePage';

interface User {
  email: string;
  name: string;
  id: number;
}

interface MainAppProps {
  user: User;
  onLogout: () => void;
}

export function MainApp({ user, onLogout }: MainAppProps) {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'agriculture':
        return <AgriculturePage />;
      case 'food-technology':
        return <FoodTechnologyPage />;
      case 'rural-development':
        return <RuralDevelopmentPage />;
      case 'resources':
        return <ResourcesPage />;
      case 'faq':
        return <FAQPage onNavigate={setCurrentPage} />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'profile':
        return <ProfilePage user={user} onNavigate={setCurrentPage} />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        user={user} 
        onLogout={onLogout} 
        currentPage={currentPage} 
        onNavigate={setCurrentPage} 
      />
      <main className="pt-16">
        {renderPage()}
      </main>
    </div>
  );
}