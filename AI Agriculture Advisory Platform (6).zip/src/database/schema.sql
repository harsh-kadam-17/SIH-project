-- Terra Tech Database Schema for Supabase
-- Run this in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table (extends Supabase auth.users)
CREATE TABLE public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  role TEXT DEFAULT 'farmer' CHECK (role IN ('farmer', 'consultant', 'admin')),
  location TEXT,
  farm_size DECIMAL,
  primary_crops TEXT[],
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Conversations table
CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  domain TEXT NOT NULL CHECK (domain IN ('agriculture', 'food-technology', 'rural-development')),
  title TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Messages table
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('user', 'bot')),
  content TEXT NOT NULL,
  tokens_used INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User preferences table
CREATE TABLE public.user_preferences (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
  preferred_units TEXT DEFAULT 'metric' CHECK (preferred_units IN ('metric', 'imperial')),
  notification_settings JSONB DEFAULT '{}',
  ai_model_preference TEXT DEFAULT 'gpt-4o-mini',
  theme_preference TEXT DEFAULT 'light' CHECK (theme_preference IN ('light', 'dark', 'system')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Agricultural images table
CREATE TABLE public.agricultural_images (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
  filename TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  mime_type TEXT,
  analysis_results JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Usage analytics table
CREATE TABLE public.usage_analytics (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  domain TEXT NOT NULL,
  query_type TEXT,
  response_quality_rating INTEGER CHECK (response_quality_rating BETWEEN 1 AND 5),
  tokens_used INTEGER,
  response_time_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Crops reference table (for agricultural guidance)
CREATE TABLE public.crops (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL UNIQUE,
  scientific_name TEXT,
  category TEXT NOT NULL,
  growing_season TEXT,
  water_requirements TEXT,
  soil_type TEXT[],
  common_pests TEXT[],
  common_diseases TEXT[],
  planting_depth_cm DECIMAL,
  spacing_cm DECIMAL,
  days_to_maturity INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_conversations_user_id ON public.conversations(user_id);
CREATE INDEX idx_conversations_domain ON public.conversations(domain);
CREATE INDEX idx_messages_conversation_id ON public.messages(conversation_id);
CREATE INDEX idx_messages_created_at ON public.messages(created_at);
CREATE INDEX idx_usage_analytics_user_id ON public.usage_analytics(user_id);
CREATE INDEX idx_usage_analytics_domain ON public.usage_analytics(domain);
CREATE INDEX idx_agricultural_images_user_id ON public.agricultural_images(user_id);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON public.user_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Row Level Security (RLS) Policies
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agricultural_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.usage_analytics ENABLE ROW LEVEL SECURITY;

-- Users can only see and edit their own data
CREATE POLICY "Users can view own profile" ON public.users
  FOR ALL USING (auth.uid() = id);

CREATE POLICY "Users can view own conversations" ON public.conversations
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view messages from own conversations" ON public.messages
  FOR ALL USING (
    conversation_id IN (
      SELECT id FROM public.conversations WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can view own preferences" ON public.user_preferences
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own images" ON public.agricultural_images
  FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own analytics" ON public.usage_analytics
  FOR ALL USING (auth.uid() = user_id);

-- Public read access for crops reference data
CREATE POLICY "Anyone can view crops" ON public.crops
  FOR SELECT USING (true);

-- Insert some sample crop data
INSERT INTO public.crops (name, scientific_name, category, growing_season, water_requirements, soil_type, common_pests, common_diseases, planting_depth_cm, spacing_cm, days_to_maturity) VALUES
('Tomato', 'Solanum lycopersicum', 'Vegetable', 'Spring-Summer', 'Regular watering, avoid overwatering', ARRAY['Well-drained', 'Loamy'], ARRAY['Aphids', 'Whiteflies', 'Hornworms'], ARRAY['Blight', 'Fusarium wilt', 'Mosaic virus'], 1.5, 60, 75),
('Corn', 'Zea mays', 'Grain', 'Spring-Summer', 'Regular watering, especially during pollination', ARRAY['Well-drained', 'Rich soil'], ARRAY['Corn borers', 'Rootworms', 'Aphids'], ARRAY['Rust', 'Smut', 'Leaf blight'], 5, 30, 90),
('Wheat', 'Triticum aestivum', 'Grain', 'Fall-Spring', 'Moderate water requirements', ARRAY['Well-drained', 'Clay loam'], ARRAY['Aphids', 'Hessian fly', 'Armyworms'], ARRAY['Rust', 'Powdery mildew', 'Septoria'], 3, 15, 120),
('Rice', 'Oryza sativa', 'Grain', 'Spring-Summer', 'Flooded fields, high water requirements', ARRAY['Clay', 'Flooded soil'], ARRAY['Stem borers', 'Brown planthoppers'], ARRAY['Blast', 'Bacterial blight'], 2, 20, 110),
('Lettuce', 'Lactuca sativa', 'Vegetable', 'Spring-Fall', 'Consistent moisture, light watering', ARRAY['Well-drained', 'Rich organic matter'], ARRAY['Aphids', 'Slugs', 'Cutworms'], ARRAY['Downy mildew', 'Lettuce drop'], 1, 25, 45);

-- Function to create user profile after signup
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)));
  
  INSERT INTO public.user_preferences (user_id)
  VALUES (NEW.id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create user profile
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();