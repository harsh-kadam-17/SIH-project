
  # AI Agriculture Advisory Platform

  This is a code bundle for AI Agriculture Advisory Platform. The original project is available at https://www.figma.com/design/tFN5lEEHDPJ3LTfeIr7Jyh/AI-Agriculture-Advisory-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  